<?php
namespace Home\Controller;
use Think\Controller;
class JssdkController extends Controller {

	private $appId;
	private $appSecret;
  
    /*
	 * 文章分享
	*/
	public function qCode(){
		$this->appId = 'wx6463f5918d23e8b8';
		$this->appSecret = '14b9c5419bc75358bbf8510a22d8e967';
		$signPackage = $this->getSignPackage();
	    return $signPackage;
	}

	public function getSignPackage(){
		$jsapiTicket = $this->getJsApiTicket();
		$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";
		$signature = sha1($string);
		$signPackage = array(
		  "appId"     => $this->appId.trim(),
		  "nonceStr"  => $nonceStr,
		  "timestamp" => $timestamp,
		  "url"       => $url,
		  "signature" => $signature,
		  "rawString" => $string
		);
		return $signPackage; 
	}



	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}


	private function getJsApiTicket() {
		$data=$this->getAccessToken();
		$url ='https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$data.'&type=jsapi';
		$res = json_decode($this->httpGet($url),true);
		$ticket = $res['ticket'];
		return $ticket;
    }

    public function getAccessToken() {
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$this->appId."&secret=".$this->appSecret;
		$res = json_decode($this->httpGet($url),true);
		$data=$res['access_token'];
	    return $data;
    }

	function httpGet($url)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}




    
  
    
  




    
}