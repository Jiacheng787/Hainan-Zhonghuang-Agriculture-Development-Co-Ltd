<?php
return array(
	//'配置项'=>'配置值'

        'MODULE_ALLOW_LIST' => array('home'),
        'DEFAULT_MODULE'     => '', //默认模块
        'URL_MODEL'          => '2', //URL模式
        'SESSION_AUTO_START' => true, //是否开启session

        /* 'TMPL_PARSE_STRING'  =>array(
            '__JS__' => '/ningbo/Public/Home/Js',
            '__CSS__' => '/ningbo/Public/Home/Css',
            '__IMAGES__' => '/ningbo/Public/Home/Images',
            '__UPLOADS__' => '/ningbo/Public/Home/Uploads',
            '__UEDITOR__' => '/ningbo/Public/Home/Ueditor',
            '__SWF__' => '/ningbo/Public/Home/Swf',
            '__LHG__' => '/ningbo/Public/Home/lhgcalendar',
        ), */
    'TMPL_PARSE_STRING'  =>array(
        '__JS__' => '/Public/Home/Js',
        '__CSS__' => '/Public/Home/Css',
        '__IMAGES__' => '/Public/Home/Images',
        '__UPLOADS__' => '/Public/Home/Uploads',
        '__UEDITOR__' => '/Public/Home/Ueditor',
        '__SWF__' => '/Public/Home/Swf',
        '__LHG__' => '/Public/Home/lhgcalendar',
    ),

    );
