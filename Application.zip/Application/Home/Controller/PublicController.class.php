<?php
namespace Home\Controller;
use Think\Controller;
class PublicController extends Controller {
    public function _initialize(){
        $controller = CONTROLLER_NAME;
        $action = ACTION_NAME;	
		$auth_module_list = M('auth_module')->order('id asc')->select();
		$this->assign('auth_module_list',$auth_module_list);
    }
}