<?php
namespace Home\Controller;
use Think\Controller;
class EuserController extends Controller {

    private $access_role = array(
                        "money"
                       
                    );
    private $user_id     = '';
    private $user_info   = '';
	private $auth_module_list   = '';


     /**
     * 检测用户登录的模块
     * 关键字：$_SESSION['EHOME']["userid"]
     */
    public function _initialize(){
       
		$auth_module_list = M('auth_module')->order('id asc')->select();
		$this->assign('auth_module_list',$auth_module_list);
        if($_SESSION['EUSER']["userid"]>0){
            $this->user_id   = $_SESSION['EUSER']["userid"];
            $res = M("shenfenz")->where(array("id"=>$this->user_id))->find();
            if($res){
                $this->user_info = $res;
                unset($this->user_info['password']);
                $this->assign("company_info",$this->user_info);
            }else{
                // 不合法的登陆者
                $this->redirect("Home/Euser/login");die;
            }
        }
    }





    /**
     * 登录页
    */
	 
	public function login(){
		
		if(IS_AJAX){
			
			if($this->auth_module_list[4]["is_show"] == 4){
				$arrys = array(
					"status" => 0,
					"info" => '功能维护中',
				);
				echo json_encode($arrys);exit;	
			}

			$card = I("post.card");
            $password = I("post.password"); 
            if(!$card || !$password){
                $this->ajaxReturn(array("status"=>0,"info"=>"请填写正确的格式"));
            }
			
			$cardname = M('shenfenz')->where(array('card'=>$card))->find();
			$action = 'FindIdentityNo';

			if(!$cardname){
				$zhuantai = sqlserver($action,$card,'','','','');
                
			    if($zhuantai){
					$i = 0;
				  
					foreach($zhuantai as $key=>$val){
						$list[$i] = yang_gbk2utf8($val);
                        $i++;						
					}

					$data['name'] = $list[2];
					$data['position'] = $list[3];
					$data['school'] = $list[4];
					$data['education'] = $list[5];
					$data['major'] = $list[6];
					$data['mobile'] = $list[7];
					$data['startime'] = $list[8];
					$data['endtime'] = $list[9];
					$data['danwei'] = $list[10];
					$password = md5(substr($card,-6));
					$data['card'] = $card;
					$data['password'] = $password;
					
					$res = M('shenfenz')->add($data);
		
					if($res){
						$data1['userid'] = $res;
						$data1['addtime'] = date('Y-m-d H:i:s',time());
						$data1['ip'] = $_SERVER['REMOTE_ADDR'];//获取当前ip
						M('shenfenz_log')->add($data1);
						$_SESSION['EUSER']["userid"] = $res;
					    $this->ajaxReturn(array("status"=>1,"info"=>"登录成功","url"=>U('Home/Euser/money')));
					}
				
				}else{
					$arrys = array(
                        "status" => 0,
                        "info" => '账号不存在',
                    );
					echo json_encode($arrys);exit;
					
				}

			}else{
			
				$password = md5($password);
				$res = M("shenfenz")->where(array("card"=>$card,"password"=>$password))->find();
			
				if(!$res){
					$this->ajaxReturn(array("status"=>0,"info"=>"用户名或密码错误"));exit;
				}else{

					if(!$data['name']){
					    $zhuantai = sqlserver($action,$card,'','','','');
					    if($zhuantai){

					    	$i = 0;
							foreach($zhuantai as $key=>$val){
								$list[$i] = yang_gbk2utf8($val);
		                        $i++;						
							}

							$data['name'] = $list[2];
							$data['position'] = $list[3];
							$data['school'] = $list[4];
							$data['education'] = $list[5];
							$data['major'] = $list[6];
							$data['mobile'] = $list[7];
							$data['startime'] = $list[8];
							$data['endtime'] = $list[9];
							$data['danwei'] = $list[10];
						    $update = M('shenfenz')->where(array("id"=>$res['id']))->save($data);
					    }


					}
                   
					$data1['userid'] = $res['id'];
					$data1['addtime'] = date('Y-m-d H:i:s',time());
					$data1['ip'] = $_SERVER['REMOTE_ADDR'];//获取当前ip
					
					M('shenfenz_log')->add($data1);
					
					$_SESSION['EUSER']["userid"] = $res['id'];
					$this->ajaxReturn(array("status"=>1,"info"=>"登录成功","url"=>U('Home/Euser/money')));
				}

			}
			
	
		}
		 
		
		if(($_SESSION['EUSER']['userid'])>0){
            $this->redirect("Home/Euser/money");
        }
		
		$this->display();
		 
	}
	 
	

    /**
     * 工资查询
     */
    public function money(){
		print_r($auth_module_list);
		header('content-type:text/html;charset=utf-8;');
		$user = $this->user_info;
		$info =  sqlserver('all',$user['card'],'','','',$DWName);
		$companyname = $info[0]['DWName'];
	    $year = date('Y',time());
		$month = date('m',time());
		$return =  sqlserver('money',$user['card'],'',$year,$month,$companyname);
		$date = M('time')->find();
		if($date['time'] != "0000-00-00 00:00:00"){
			$time = date('Y年m月d日',strtotime($date['time']));
			$this->assign('datetime',$time);
			
		}else{
			$this->assign('datetime',date('Y年m月d日'),time());
		}
		
		for($i=2017;$i<=$year;$i++){
			$yearArr[] = $i;
		}
		$this->assign('yearArr',$yearArr);
		$this->assign('year',$year);
		$this->assign('user',$user);
		$this->assign('month',$month);
		$this->assign('companyname',$companyname);
        $this->assign('data',$return);
        $this->display();

    }
	
	
	public function moneyget(){

		if(IS_AJAX){
			
			if($auth_module_list[4]["is_show"] == 4){
				$arrys = array(
					"status" => 0,
					"info" => '功能维护中',
				);
				echo json_encode($arrys);exit;	
			}
			
			$DWName = I('post.DWName');
	        $iMon = intval(I('post.iMon'));
			$iZDYear = intval(I('post.iZDYear'));
			$card = I('post.card');
		    $return =  sqlserver('money',$card,'',$iZDYear,$iMon,$DWName);
			
			/* 获取工资所有字段对应名称 */
			$return1 =  sqlserver('money_getField','','',$iZDYear,$iMon,$DWName);

			$html .= '<div class="e_money_lis">';
			$html .= '<ul id="show"><li style="text-align:center">查询信息请以实际发放为准</li>';
			if($return&&$return1){
				foreach($return as $key=>$val){
					if($return1[$key]!='id')
					$html .= '<li>'.$return1[$key].'：<div class="mon_num gjjcash">'.$val.'</div></li>';
			    }
				$html .= '</ul>';
			    $html .= '</div>';

				$arr['status'] = 1;
				$arr['info'] = $html;
			}else{
				$arr['status'] = 0;	
			}
			
			
			echo json_encode($arr);exit;



			

			
		}
	}

  
   
    /**
    * 忘记密码
    */
    public function editpassword(){
        if(IS_AJAX){
            $card = I("post.card");
            $oldpass  = I("post.oldpass");
            $newpass1 = I("post.newpass1");
            $newpass2 = I("post.newpass2");
            if(!$card || !$oldpass || !$newpass1 || !$newpass2){
                $this->ajaxReturn(array("status"=>0,"info"=>"请填写完整"));
            }
            if($newpass1 != $newpass2){
                $this->ajaxReturn(array("status"=>0,"info"=>"两次密码不一样"));
            }
            $oldpass = md5($oldpass);
            $res = M("shenfenz")->where(array("card"=>$card,"password"=>$oldpass))->find();
            if($res){
                // 用户名密码正确，修改密码
                $data = array(
                        "password" => md5($newpass1),
                    );
                $res2 = M("shenfenz")->where(array("id"=>$res['id']))->save($data);
                if($res2){
                    
                    $this->ajaxReturn(array("status"=>1,"info"=>"修改密码成功！请妥善保管好密码！","url"=>U('Home/Euser/login')));
                }else{
                    $this->ajaxReturn(array("status"=>0,"info"=>"修改密码失败！"));
                }
            }else{
                $this->ajaxReturn(array("status"=>0,"info"=>"用户名或密码错误"));
            }
        }
        $this->display();
    }







    
 
    
    
   
   

  
  
   
    
}