<?php
namespace Home\Controller;
use Think\Controller;
class NewsController extends Controller {
    /**
     * 资讯
     */
    public function index(){
		
		$menberID = session('member_id');
        $id = intval(I('id'));
		$news = M('News');
        $where['id'] = $id;
		$info = $news->where($where)->find();

        $piclist = '';
        if($info['pic1']){
            $piclist=explode(',', $info['pic1']);
        }
      
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
		
        $url = "http://".$_SERVER['HTTP_HOST'];
        $this->assign('url',$url);
		
		
        
        /* 附件 */


        if($info['fujian']!=''){
            $file = explode(',',$info['fujian']);
            $file = array_filter($file);
            $filename = explode(',',$info['filename']);
            $filename = array_filter($filename);

            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $files[$key]['file'] = $str[$length-1];
                $files[$key]['fujian'] = $val ;

            } 

            foreach ($filename as $key => $vo) {
                $files[$key]['filename'] = $vo;
            } 
        }




        $this->assign('info',$info);
        $this->assign('files',$files);
		$this->assign('piclist',$piclist);

		/* 阅读记录 */
		$readnums = $info['readnums'];  //阅读量
		$M_News_rcount = M('News_rcount');
		$where1['newsID'] = $id;
        $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip
        $where1['ip'] = $ip;
        $where1['typeid'] = 1;

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>1))->find();


        $this->assign('hit',$hit);
		

		$News_rcount_One = $M_News_rcount->where($where1)->find();
		if(empty($News_rcount_One)){
			$where1['addTime'] = date('Y-m-d H:i:s',time());
			$where1['lastTime'] = date('Y-m-d H:i:s',time());
			$readnums = $where['readnums'] = $info['readnums']+1;
			$M_News_rcount->add($where1);
			$news->where(array('id'=>$id))->setField('readnums',$readnums);
		}else{
			$where1['id'] = $News_rcount_One['id'];
			$where1['lastTime'] = date('Y-m-d H:i:s',time());
			$M_News_rcount->save($where1);
		}


        $signPackage = R('Jssdk/qCode');
		
        $this->assign('signPackage',$signPackage);
        $this->assign('id',$id);
		$this->assign('readnums',$readnums);
        $this->display();
		
    }


    public function slide(){

        $menberID = session('member_id');
        $id = intval(I('id'));
    
        $news = M('gonggao');
        $where['id'] = $id;
        $where['is_tui'] = 1;
        $info = $news->where($where)->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        $this->assign('info',$info);
        

        /* 阅读记录 */
        $readnums = $info['readnums'];  //阅读量
        $M_News_rcount = M('News_rcount');
        $where1['newsID'] = $id;
        $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip
        $where1['ip'] = $ip;
        $where1['typeid'] = 5;

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>5))->find();


        $this->assign('hit',$hit);

        $News_rcount_One = $M_News_rcount->where($where1)->find();
        if(empty($News_rcount_One)){
            $where1['addTime'] = date('Y-m-d H:i:s',time());
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $readnums = $where['readnums'] = $info['readnums']+1;
            $M_News_rcount->add($where1);
            $news->where(array('id'=>$id))->setField('readnums',$readnums);
        }else{
            $where1['id'] = $News_rcount_One['id'];
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $M_News_rcount->save($where1);
        }
        $this->assign('readnums',$readnums);
        
        
        
        $this->display();


    }









    
    
    /**
     * 资讯
    */
    public function testView(){
        $menberID = session('member_id');
        $id = intval(I('id'));
    
        $news = M('News');
        $where['id'] = $id;
        $info = $news->where($where)->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        $fujian = $info['fujian'];
        $path=parse_url($fujian);
        $str=explode('/',$path['path']);
        $length = sizeof($str);
        $info['fujian'] = $str[$length-1];
        $this->assign('info',$info);
        $this->assign('readnums',$readnums);
        $this->display("index");
    }
    


    //下载附件
    public function downfujian(){
        $id = I('id');
        $where['id'] = $id;
        $fujian = M('news');
        $res = $fujian->field('fujian')->where($where)->select();
        $fujianpath = $res[0]['fujian'];
        //echo $fujianpath;
        //if(!$fujianpath) header("http://aokesi.unohacha.com: /");
        if(!$fujianpath) header("localhost/");
        if(!isset($fujianpath)){
            echo '500';
        }
        if(!file_exists($fujianpath)){ //检查文件是否存在
    
            echo '404';
        }
        $file_name=basename($fujianpath);
        $file_type=explode('.',$fujianpath);
        $file_type=$file_type[count($file_type)-1];
        $file_type=fopen($fujianpath,'r'); //打开文件
        //输入文件标签
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".filesize($fujianpath));
        header("Content-Disposition: attachment; filename=".$file_name);
        //输出文件内容
        echo fread($file_type,filesize($fujianpath));
        fclose($file_type);
    
    }
    
    /**
     * 热点信息
     */
    public function hot(){
        $this->display();
    }
    
    /**
     * 东方课堂
     */
    public function lesson(){
        $this->display();
    }


    /*
    * 文章点赞
    */

    public function addhit(){
        if(IS_AJAX){
            $id = I('post.id');
            $where['newsID'] = $id;
            $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip

            $where['ip'] = $ip;
            $where['typeid'] = 1;
            $readnums = M('news')->where(array('id'=>$id))->getField('hit');

            $info  = M('hit')->where($where)->find();
            if(empty($info)){
                $where['addtime'] = date('Y-m-d H:i:s',time());
                $res = M('hit')->add($where);
                $hit = $readnums + 1;
                $save = M('news')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>1
                );

               echo json_encode($result);exit;
            }else{

                $res = M('hit')->delete($info['id']);
                if($readnums>0){
                    $hit = $readnums - 1;
                }
               
                $save = M('news')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>2
                );

               echo json_encode($result);exit;



            }

            
        }
    }


    /*
    * 幻灯片新闻点赞
    */
    public function addslidehit(){
        if(IS_AJAX){
            $id = I('post.id');
            $where['newsID'] = $id;
            $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip

            $where['ip'] = $ip;
            $where['typeid'] = 5;
            $readnums = M('gonggao')->where(array('id'=>$id))->getField('hit');

            $info  = M('hit')->where($where)->find();
            if(empty($info)){
                $where['addtime'] = date('Y-m-d H:i:s',time());
                $res = M('hit')->add($where);
                $hit = $readnums + 1;
                $save = M('gonggao')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>1
                );

               echo json_encode($result);exit;
            }else{

                $res = M('hit')->delete($info['id']);
                if($readnums>0){
                    $hit = $readnums - 1;
                }
               
                $save = M('gonggao')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>2
                );

               echo json_encode($result);exit;



            }

            
        }
    }










}