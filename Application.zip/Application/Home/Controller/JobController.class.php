<?php
namespace Home\Controller;
//use Home\Controller\CommonController;
// class JobController extends CommonController {
//namespace Home\Controller;
use Think\Controller;
class JobController extends Controller { 
    /**
     * 岗位详情
     */
    public function jobdetails(){
        $id = intval(I('id'));
		$memberID = session('member_id')?session('member_id'):'';
        $where['id'] = $id;
        if($memberID!=''){
            $memberInfo = M('Member')->where('id='.$memberID)->find();
            $newsnum = M('notice')->where(array('memberID'=>$memberID,'status'=>0))->count();
            $this->assign('newsnum',$newsnum);
            $this->assign('memberInfo',$memberInfo);
            $this->assign('uid',$memberID);
        }
       
		$M_Collection = M('Collection');
		$M_Resume_cast = M('Resume_cast');
 
 
        $collectionCount = $M_Collection->where( array('userid'=>$memberID,'recru_id'=>$id) )->count();
        $collection  = $M_Collection->where( array('userid'=>$memberID,'recru_id'=>$id) )->find();

        $resume_castCount = $M_Resume_cast->where( array('userid'=>$memberID,'recru_id'=>$id) )->count();
        $resume = $M_Resume_cast->where( array('userid'=>$memberID,'recru_id'=>$id) )->find();
      
  
	
        $zp = M('recruitment');
        if($id!=''){
            $zpinfo = $zp->where($where)->find();
            $zpinfo['addtime'] = date('Y-m-d',strtotime($zpinfo['addtime']));
            $zp->where($where)->setInc("visit_nums", 1);
            $zpinfo['company'] = M('company')->where(array('id'=>$zpinfo['company_id']))->getField('company_name');
        }


       
         
        $url = "http://".$_SERVER['HTTP_HOST'];
        $this->assign('url',$url);
		
		/* 附件 */


        if($zpinfo['fujian']!=''){
            $file = explode(',',$zpinfo['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$zpinfo['filename']);
            $filename = array_filter($filename);

            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $info[$key]['file'] = $str[$length-1];
                $info[$key]['fujian'] = $val ;

            } 

            
            foreach ($filename as $key => $vo) {
                $info[$key]['filename'] = $vo;
            } 




        }


		/* 附件 */
		$this->assign('collection',$collection);
        $this->assign('info',$info);
        $this->assign('resume',$resume);
        $this->assign('zpinfo',$zpinfo);
		$this->assign('collectionCount',$collectionCount);
		$this->assign('resume_castCount',$resume_castCount);
       
        $this->display();
    }
    
    /**
     * 企业详情
     */
    public function jobdot(){
        $id = intval(I('id'));
		$memberID = session('member_id');
        
        if($memberID!=''){
            $memberInfo = M('Member')->where('id='.$memberID)->find();
            $newsnum = M('notice')->where(array('memberID'=>$memberID,'status'=>0))->count();
            $this->assign('newsnum',$newsnum);
            $this->assign('memberInfo',$memberInfo);
        }
        

        $where['id'] = $id;
        $com = M('company');

        if($id!=''){
            $res = $com->where($where)->find();
            $res['type'] = M('company_class')->where(array('id'=>$res['type']))->getField('classname');
            $this->assign('res',$res);
            $zp = M('recruitment');
            $map['company_id'] = $id;
            $map['isdel'] = 0;
            $map['status'] = 1;
            $currnttime = date('Y-m-d',time());
            $map['endtime'] = array('egt',$currnttime);
            $zpinfo = $zp->where($map)->select();
            $M_Collection = M('Collection');
            $M_Resume_cast = M('Resume_cast');
            foreach ($zpinfo as $k=>$v){
                $zpinfo[$k]['count'] = $M_Collection->where( array('userid'=>$memberID,'recru_id'=>$v['id']) )->count();
                $zpinfo[$k]['resume_castCount'] = $M_Resume_cast->where( array('userid'=>$memberID,'recru_id'=>$v['id']) )->count();
                $zpinfo[$k]['addtime'] = date( 'Y-m-d ',strtotime($v['addtime']));
                $zpinfo[$k]['company'] = M('company')->where(array('id'=>$v['company_id']))->getField('company_name');
            }

        }
       
        $this->assign('info',$zpinfo);
        $this->display();
    }


    
     /**
     * 招聘信息
     */
    public function jobinfo(){
        
        $zp = M('recruitment');
        $M_Collection = M('Collection');
        $M_Resume_cast = M('Resume_cast');
        $M_Member = M('Member');
        $userid = session('member_id');
        
        /* 会员信息 */
        if($userid!=''){
            $memberInfo = $M_Member->where('id='.$userid)->find();
            $newsnum = M('notice')->where(array('memberID'=>$userid,'status'=>0))->count();
            $this->assign('newsnum',$newsnum);
        }


        
        $where['isdel']  = 0;
        $where['status'] = 1;
        $keyword = I('get.keyword');
        if($keyword){
            $search = array('like','%'.$keyword ."%");
            $where['position'] = $search;
        }


    
        $zpinfo = $zp->where($where)->select();
        if($zpinfo){
            foreach ($zpinfo as $k=>$v){
                $zpinfo[$k]['collectionCount'] = $M_Collection->where( array('userid'=>$userid,'recru_id'=>$v['id']) )->count();
                $zpinfo[$k]['resume_castCount'] = $M_Resume_cast->where( array('userid'=>$userid,'recru_id'=>$v['id']) )->count();
                $zpinfo[$k]['addtime'] = date( 'Y-m-d ',strtotime($v['addtime']));
                $zpinfo[$k]['company'] = M('company')->where(array('id'=>$v['company_id']))->getField('company_name');
            }

        }
        
        $this->assign('zpinfo',$zpinfo);
        $this->assign('memberInfo',$memberInfo);
        $this->display();
    }
   



    /**
     * 收藏职位
     */
    public function scjob(){
        $coll = M('collection');
        $zp = M('recruitment');
		$M_Member = M('Member');
		$M_Resume_cast = M('Resume_cast');
        $userid = session('member_id');
        
		/* 会员信息 */

        if($userid!=''){
            $memberInfo = $M_Member->where('id='.$userid)->find();
            $newsnum = M('notice')->where(array('memberID'=>$memberID,'status'=>0))->count();
            $this->assign('newsnum',$newsnum);

            $where['userid'] = $userid;
            $res = $coll->where($where)->select();
            foreach ($res as $k=>$v){
                $zps[$k] = $zp->where(array('id'=>$v['recru_id']))->find();
                $zps[$k]['count'] = $M_Resume_cast->where( array('userid'=>$userid,'recru_id'=>$zps[$k]['id']) )->count();
                $zps[$k]['addtime'] = date( 'Y-m-d ',strtotime($zps[$k]['addtime']));
                $zps[$k]['company'] = M('company')->where(array('id'=>$zps[$k]['company_id']))->getField('company_name');
                $zps[$k]['colId'] =$v['id'];
            }
            /* 收藏职位列表信息 */
            
            $this->assign('memberInfo',$memberInfo);
            $this->assign('res',$zps);
            

        }
		
		
		
		/* 收藏职位列表信息 */
       
        $this->display();
    }
	
	
    /**
     * 求职记录
     */
    public function jobrecord(){
		
        $M_Resume_cast = M('Resume_cast'); //简历投放表
        $M_Recruitment = M('recruitment'); //招聘表
		$M_Member = M('Member');          
		$M_Collection = M('Collection');		
        $userid = session('member_id');
        
		/* 会员信息 */
        if($userid!=''){
            $memberInfo = $M_Member->where('id='.$userid)->find();
            $newsnum = M('notice')->where(array('memberID'=>$memberID,'status'=>0))->count();
            $this->assign('newsnum',$newsnum);
            /* 求职记录列表信息 */
            $where['userid'] = $userid;
            $res = $M_Resume_cast->where($where)->select();
            foreach ($res as $k=>$v){
                $zps[$k] = $M_Recruitment->where(array('id'=>$v['recru_id']))->find();
                $zps[$k]['count'] = $M_Collection->where( array('userid'=>$userid,'recru_id'=>$zps[$k]['id']) )->count();
                $zps[$k]['addtime'] = date( 'Y-m-d ',strtotime($zps[$k]['addtime']));
                $zps[$k]['castid'] = $v['id'];
                $zps[$k]['company'] = M('company')->where(array('id'=>$zps[$k]['company_id']))->getField('company_name');
            }

        }




	
		
		/* 收藏职位列表信息 */
        $this->assign('memberInfo',$memberInfo);
		$this->assign('res',$zps);
		
        $this->display();
    }
	
	
    /**
     * 下载附件
     */
    public function downfujian(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $fujian = M('recruitment');
        if($id!=''){
            $res = $fujian->field('fujian')->where($where)->select();
            $fujianpath = $res[0]['fujian'];
            if(!$fujianpath) header("localhost/");
            if(!isset($fujianpath)){
                echo '500';
            }
            if(!file_exists($fujianpath)){ //检查文件是否存在
        
                echo '404';
            }
            $file_name=basename($fujianpath);
            $file_type=explode('.',$fujianpath);
            $file_type=$file_type[count($file_type)-1];
            $file_type=fopen($fujianpath,'r'); //打开文件
            //输入文件标签
            header("Content-type: application/octet-stream");
            header("Accept-Ranges: bytes");
            header("Accept-Length: ".filesize($fujianpath));
            header("Content-Disposition: attachment; filename=".$file_name);
            //输出文件内容
            echo fread($file_type,filesize($fujianpath));
            fclose($file_type);

        }
        
    
    }
    
    /**
     * 搜藏职位
     */
    public function collection(){
        $id = intval(I('id'));
        $coll = M('collection');
        //用户id
        $host_url = C('HOST_URL');
        $userid = session('member_id');
      
        $_SESSION['surl']=$host_url.'/Home/Job/jobdetails/id/'.$id;
        if(empty($userid)){
            $result = array(
                    'status'=>3
            );
            echo json_encode($result);exit;
        }
        $where['userid'] = $userid;
        $where['recru_id'] = $id;

        if($id!=''){
            $rep = $coll->where($where)->select();
            if($rep){
                $result = array(
                        'status'=>2
                );
                echo json_encode($result);exit;
            }else{
                $data['recru_id'] = $id;
                $data['userid'] = $userid;
                $data['addtime'] = date( 'Y-m-d H:i:s ',time());

                $res = M('collection')->where(array('userid'=>$userid))->count();
                if($res>=10){
                    $result = array(
                        'status'=>4
                    );
                    echo json_encode($result);exit;

                }
                $res = $coll->add($data);
                if($res){
                    $result = array(
                        'status'=>1
                    );
                    echo json_encode($result);exit;
                }else{
                    $result = array(
                        'status'=>0
                    );
                    echo json_encode($result);exit;
                }
            }

        }
     
    }

     /*
    *取消收藏
    */

    public function delcollection(){
        if(IS_AJAX){
            $id = intval(I('id'));
            $res = M('collection')->delete($id);
            if($res){
                $result = array(
                    'status'=>1,
                    'info'=>'取消成功'
                    );

            echo json_encode($result);exit;

            }
        }
    }





      /**
     * 投递简历
    */

    public function hand(){
        $recru_id= intval(I('post.recru_id'));

        $host_url = C('HOST_URL');

        $userid = session('member_id');

        $_SESSION['surl']=$host_url.'/Home/Job/jobdetails/id/'.$recru_id;
  
      
        if(empty($userid)){
          
            $result = array(
                'status'=>'0',
                );
            echo json_encode($result);exit;
        }
     

        $resumeID = M('myresume')->where(array('memberID'=>$userid))->getField('id');

        if(!$resumeID){
             $result = array(
                'status'=>'4',
                );
            echo json_encode($result);exit;
        }


        if($recru_id!=''){
            $position =  M('resume_cast')->where(array('userid'=>$userid,'recru_id'=>$recru_id))->select();
            if($position){
                $result = array(
                    'status'=>'1',
                    'info'=>'已投申请过该职位'
                    ); 
                echo json_encode($result);exit;

            }

            $data['userid'] = $userid;
            $data['resumeID'] = $resumeID;
            $data['recru_id'] = $recru_id;
            $data['addtime'] = date('Y-m-d,H:i:s',time());

            $num = M('resume_cast')->where(array('userid'=>$userid))->count();

            if($num>=10){
                $result = array(
                    'status'=>'3',
                    'info'=>'最多可申请10个职位,可以在个人中心内删除'
                ); 
                echo json_encode($result);exit;
            }
            
            $rs = M('resume_cast')->add($data);
            if($rs){
                $result = array(
                    'status'=>'2',
                    'info'=>'投递成功'
                ); 
                echo json_encode($result);exit;
            }else{

                $result = array(
                    'status'=>'3',
                    'info'=>'投递失败'
                );
                echo json_encode($result);exit; 

            }


        }
    

    }

    /*
    *取消申请
    */

     public function delhand(){
        if(IS_AJAX){
            $id = intval(I('id'));
            if($id!=''){
                $res = M('resume_cast')->delete($id);
                if($res){
                    $result = array(
                        'status'=>1,
                        'info'=>'取消成功'
                        );

                    echo json_encode($result);exit;
                }

            }
          
        }
    }

    
    /**
     * 投递简历
     */
    public function toudi(){
        $id = I('id');
        //$userid = session('member_id');
        $userid = 13;
        $resum = M('resume');
        if(empty($userid)){
            echo 3;exit;
        }
        $where['userid'] = $userid;
        $where['recru_id'] = $id;
        $rep = $resum->where($where)->select();
        if($rep){
            echo 2;exit;
        }else{
            $data['recru_id'] = $id;
            $data['userid'] = $userid;
            $data['addtime'] = date( 'Y-m-d ',time());
            $res = $resum->add($data);
            if($res){
                echo 1;
            }else{
                echo 0;
            }
        }
        
    }
}