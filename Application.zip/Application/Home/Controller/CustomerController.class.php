<?php
namespace Home\Controller;
use Think\Controller;
class CustomerController extends Controller {

    private $access_role = array(
                        "login",
                        "editpassword",
                        "hotdetailview",
                    );
    private $user_id     = '';
    private $user_info   = '';


    /**
     * 检测用户登录的模块
     * 关键字：$_SESSION['EHOME']["userid"]
     */
    public function _initialize(){
     
        $autoLogin = json_decode(I("cookie.autoLogin"),true);
        $this->assign('autoLogin',$autoLogin);
        $access_role = $this->access_role;
        $action_name = strtolower(ACTION_NAME);
        if(!in_array($action_name, $access_role) && !($_SESSION['EHOME']["userid"]>0)){
            if($autoLogin){
                $auto_res = M("Company")->where(array("username"=>$autoLogin['username'],"password"=>$autoLogin['password']))->find();
                if($auto_res){
                    $_SESSION["EHOME"]['userid'] = $auto_res['id'];
                }else{
                    $this->redirect("Home/Customer/login");die;
                }
            }else{
                $this->redirect("Home/Customer/login");die;
            }
        }
        if($_SESSION['EHOME']["userid"]>0){
            $this->user_id   = $_SESSION['EHOME']["userid"];
            $res = M("Company")->where(array("id"=>$this->user_id))->find();
            if($res){
                $this->user_info = $res;
                unset($this->user_info['password']);
                $this->assign("company_info",$this->user_info);
            }else{
                // 不合法的登陆者
                $this->redirect("Home/Customer/login");die;
            }
        }
		$auth_module_list = M('auth_module')->order('id asc')->select();
		$this->assign('auth_module_list',$auth_module_list);
		
		
    }

    /**
     * 东方e家
     *      登录模块
     *      登录的用户名和密码由后台提供
     */
    public function login(){
        if(IS_AJAX){
            $username = I("post.username");
            $password = I("post.password");
            if(!$username || !$password){
                $this->ajaxReturn(array("status"=>0,"info"=>"请填写正确的格式"));
            }	
			
            $password = md5($password);
            $res = M("Company")->where(array("username"=>$username,"password"=>$password))->find();
        
            if(!$res){
                $this->ajaxReturn(array("status"=>0,"info"=>"用户名或密码错误"));
            }else{
                $arr = array(
                        "username" => $username,
                        "password" => $password,
                    );
               
                $_SESSION['EHOME']["userid"] = $res['id'];
                $this->ajaxReturn(array("status"=>1,"info"=>"登录成功","url"=>U('Home/Customer/server')));
            }
        }
        
        if($_SESSION['EHOME']['userid']>0){
            $this->redirect("Home/Customer/server");
        }
        $this->display();
    }




     /**
     * 热点信息
     */
    public function testView(){
        $menberID = session('member_id');
        $id = intval(I('id'));
    
        $news = M('hotnews');
        $where['id'] = $id;
        $info = $news->where($where)->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>2))->find();
        $this->assign('hit',$hit);

        $fujian = $info['fujian'];
        $path=parse_url($fujian);
        $str=explode('/',$path['path']);
        $length = sizeof($str);
        $info['fujian'] = $str[$length-1];
        $this->assign('info',$info);
        $this->assign('readnums',$readnums);
        $this->display("hotdetail");
    }
    






    /**
    * 忘记密码
    */
    public function editpassword(){
        if(IS_AJAX){
            $username = I("post.username");
            $oldpass  = I("post.oldpass");
            $newpass1 = I("post.newpass1");
            $newpass2 = I("post.newpass2");
            if(!$username || !$oldpass || !$newpass1 || !$newpass2){
                $this->ajaxReturn(array("status"=>0,"info"=>"请填写完整"));
            }
            if($newpass1 != $newpass2){
                $this->ajaxReturn(array("status"=>0,"info"=>"两次密码不一样"));
            }
            $oldpass = md5($oldpass);
            $res = M("Company")->where(array("username"=>$username,"password"=>$oldpass))->find();
            if($res){
                // 用户名密码正确，修改密码
                $data = array(
                        "password" => md5($newpass1),
                    );
                $res2 = M("Company")->where(array("id"=>$res['id']))->save($data);
                if($res2){
                    $_SESSION['EHOME']["userid"] = $res['id'];
                    $this->ajaxReturn(array("status"=>1,"info"=>"修改密码成功！请妥善保管好密码！","url"=>U('Home/Customer/server')));
                }else{
                    $this->ajaxReturn(array("status"=>0,"info"=>"修改密码失败！"));
                }
            }else{
                $this->ajaxReturn(array("status"=>0,"info"=>"用户名或密码错误"));
            }
        }
        $this->display();
    }




    public  function server(){
        

        $this->display();
    }



    /**
     * 招聘需求
     */
    public  function needs(){
        $map = array(
                "company_id" => $this->user_id,
                "isdel"      => 0,
            );
        $res = M("Recruitment")->where($map)->field("id,position,pay,place,addtime")->order("addtime desc")->select();
        $this->assign("cache",$res);
        $this->display();
    }


    /**
     * 报表查询
     */
    public  function baobiao(){
		header('content-type:text/html;charset=utf-8;');
		$year = date('Y',time());
		$month = date('m',time());
		$info = $this->user_info;
		
		$time = M('time')->find();
		if($time['time']){
			$time = date('Y年m月d日',strtotime($time['time']));	
		}
		
		for($i=2016;$i<=$year;$i++){
			$yearArr[] = $i;
		}

		$this->assign('yearArr',$yearArr);
		$this->assign('year',$year);
		$this->assign('month',$month);
		$this->assign('info',$info);
		$this->assign('datetime',date('Y年m月d日'),time());
		$this->assign('time',$time);
		$this->display();
    }
	
    public  function baobiaoGet(){
	    $DWName = I('post.DWName');
	    $iMon = intval(I('post.iMon'));
		$iZDYear = intval(I('post.iZDYear'));
	    $return =  sqlserver('baobiao','','',$iZDYear,$iMon,$DWName);
	    $this->ajaxReturn($return);
    }
	
	


    /**
     * 员工数据分析
     */
    public  function data(){
		header('content-type:text/html;charset=utf-8;');
		$info = $this->user_info;
		$action = 'age';
		$DWName = $info['company_name'];
		//$DWName = '奉化市农村电力公司';
		$ages =  sqlserver($action,'','','','',$DWName);
		
		unset($ages['DWName']);
		
		$allcount = 0;
		if($ages){
			$i = 0;
			$list = array();
			foreach($ages as $key=>$val){
				$allcount+=$val;
				$list[$i] = $val;
				$i++;
			}	
		}
		
		/* 总人数 */
		$this->assign('allnums',$allcount);
		/* 总人数 */
		
		$sex =  sqlserver('sex','','','','',$DWName);
		
	    unset($sex['DWName']);
		$allmen = 0;
		$j = 0;
		foreach($sex as $k=>$v){
			$allmen += $v;
			$sexs[$j] = $v;
			$j++;
		}
		
		
		$men = $sexs['0']?$sexs['0']:0;
        $women = $sexs['1']?$sexs['1']:0;
		$percentmen = number_format($men/$allmen, 2, '.', '') * 100;
		$percentwomen = number_format($women/$allmen, 2, '.', '') * 100;
		if($percentwomen!=0){
			$percentwomen = 100 - $percentmen;
		}
  		
		
        $this->assign('sex',$sexs);
		$this->assign('percentmen',$percentmen);
		$this->assign('percentwomen',$percentwomen);
		
		$education = sqlserver('education','','','','',$DWName);
		
		unset($education['DWName']);
		$alledution  = 0;
		$b = 0;
		foreach($education as $k1=>$vo){
			$alledution+=$vo;
			$edu[$b] = $vo;
			$b++;
		}
		
		
		$edupercent1 = (number_format($edu[0]/$alledution, 2, '.', ''))*100;
		$edupercent2 = (number_format($edu[1]/$alledution, 2, '.', ''))*100;
		$edupercent3 = (number_format($edu[2]/$alledution, 2, '.', ''))*100;
		$edupercent4 = (number_format($edu[3]/$alledution, 2, '.', ''))*100;
		$edupercent5 = (number_format($edu[4]/$alledution, 2, '.', ''))*100;
		
		if($edupercent5!=0){
			$edupercent5 = 100 - ( $edupercent1 + $edupercent2 + $edupercent3 + $edupercent4 );
		}elseif($edupercent4!=0){
			$edupercent4 = 100 - ( $edupercent1 + $edupercent2 + $edupercent3 );
		}elseif($edupercent3!=0){
			$edupercent3 = 100 - ( $edupercent1 + $edupercent2 );
		}elseif($edupercent2!=0){
			$edupercent2 = 100 - ( $edupercent1 );
		}
		
		$this->assign('edupercent1',$edupercent1);
		$this->assign('edupercent2',$edupercent2);
		$this->assign('edupercent3',$edupercent3);
		$this->assign('edupercent4',$edupercent4);
		$this->assign('edupercent5',$edupercent5);
		$this->assign('edu',$edu);
		
		
	    $count1 = $list[0]?$list[0]:0;
		$count2 = $list[1]?$list[1]:0;
		$count3 = $list[2]?$list[2]:0;
		$count4 = $list[3]?$list[3]:0;
	
	    
		$percent1 = number_format($count1/$allcount, 2, '.', '') * 100;

		$percent2 = number_format($count2/$allcount, 2, '.', '') * 100;
		
		$percent3 = number_format($count3/$allcount, 2, '.', '') * 100;
		
		$percent4 = number_format($count4/$allcount, 2, '.', '') * 100;
		
		if($percent4!=0){
			$percent4 = 100 - ( $percent1 + $percent2 + $percent3 );
		}elseif($percent3!=0){
			$percent3 = 100 - ( $percent1 + $percent2 );
		}elseif($percent2!=0){
			$percent2 = 100 - ( $percent1 );
		}

        $this->assign('percent1',$percent1);
		$this->assign('percent2',$percent2);
		$this->assign('percent3',$percent3);
		$this->assign('percent4',$percent4);
	    $this->assign('list',$list);
        $this->assign('info',$info);
        $this->display();


    }
	
	
	
	public function search1(){
		header('content-type:text/html;charset=utf-8;');
		$key = I('get.key');
		//$key = '曹文明';
		//echo $key;
		
		if($key!=''){
			$userinfo = $this->user_info;
			$DWName = $userinfo['company_name'];
			$info =  sqlserver('all',$key,'','','',$DWName);
			foreach($info as $key=>$val){
				$i = 0;
				foreach($val as $k=>$v){
					$arrys[$i] = yang_gbk2utf8($v);
					//$arrys[$i] = $v;
					$i++;
				}
				$data[$key][] = $arrys;
			}
			$all = $data;
		}

		$list = array();
	  
		if(is_array($all)){
			foreach ($all as $val){ 
                foreach($val as $key=>$vo){
					$snameFirstChar = getFirstCharter($vo[2]); 
				    $list[$snameFirstChar]['child'][] = $vo;
				}			
		    }
			
		}
	   
		ksort($list); 
	  
		$this->assign('list',$list);
        $this->assign('userinfo',$userinfo);
        $this->display('search');
		
	}
    


    /**
     * 员工信息查询
     */
    public  function search(){
		header('content-type:text/html;charset=utf-8;');
		
		$userinfo = $this->user_info;
		
		$DWName = $userinfo['company_name'];
		
		$result =  sqlserver('danwei','','','','',$DWName);
		
	    foreach($result as $key=>$val){
			$i = 0;
			foreach($val as $k=>$v){
				$arrys[$i] = yang_gbk2utf8($v);
				//$arrys[$i] = $v;
			    $i++;
			}
			$data[$key][] = $arrys;
		
          
	    }
		$all = $data;
		
	

       
		$list = array();
		if(is_array($all)){
			foreach ($all as $val){ 
                foreach($val as $key=>$vo){
					$snameFirstChar = getFirstCharter($vo[2]); 
				    $list[$snameFirstChar]['child'][] = $vo;
				}			
		    }
			
		}
	   
		ksort($list); 
	  
		$this->assign('list',$list);
        $this->assign('userinfo',$userinfo);
        $this->display('search');
    }
	
	
	 /**
     * 热点查询
     */
    public function searchhot(){
		header('content-type:text/html;charset=utf-8;');
		$card = I('get.card');
		if($card!=''){
			$userinfo = $this->user_info;
			$DWName = $userinfo['company_name'];
			$info =  sqlserver('all',$card,'','','',$DWName);
			$i=0;
			foreach($info[0] as $key=>$val){
				$arr[$i] = yang_gbk2utf8($val);
				//$arr[$i] = $val;
				$i++; 
			}	
		}else{
			header("Location:/Home/Customer/search"); 
			exit;
		}
	
       $this->assign('user',$arr);
       $this->display();


    }
	
	
	
	 


    /**
     * 热点信息
     */
    public  function hot(){

        $gg = M('gonggao');
        
        $zx['type'] = 7;
        $zx['is_tui'] = 1;
        $gonggao = $gg->where($zx)->order('list asc,id asc')->select();
    
        $i = 0;
        foreach ($gonggao as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);



        $class = M("hotnews")->where(array("status"=>1))->field("id,gaiyao,is_slide,pic,title")->order("addtime desc,id desc")->limit('5')->select();

        $count=M("hotnews")->where(array("status"=>1))->count();
        $this->assign('count',$count);


        $banner = array();
        foreach($class as $k=>$v){
            $banner[] = $v['is_slide']?array('pic'=>$v['pic'],"title"=>$v['title']):"";
        }
        $banner = array_filter($banner);
        $this->assign("banner",$banner);
        $this->assign("gonggao",$gonggao);
        $this->assign("cache",$class);
        $this->display();
    }


    /**
     * 热点信息详情
     */
    public  function hotdetail(){
        $id = intval(I("id"));
        $res = M("hotnews")->where(array("id"=>$id))->find();
        $piclist = '';
        if($res['pic1']){
            $piclist=explode(',', $res['pic1']);
        }

        $this->assign('piclist',$piclist);


         if($res['fujian']!=''){
            $file = explode(',',$res['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$res['filename']);
            $filename = array_filter($filename);

            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $files[$key]['file'] = $str[$length-1];
                $files[$key]['fujian'] = $val ;

            } 


            foreach ($filename as $key => $vo) {
                $files[$key]['filename'] = $vo;
            } 



        }

        $this->assign('files',$files);
          /* 阅读记录 */
        $readnums = $res['readnums'];  //阅读量
        $M_News_rcount = M('News_rcount');
        $where1['newsID'] = $id;
        $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip
        $where1['ip'] = $ip;
        $where1['typeid'] = 4;

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>4))->find();


        $this->assign('hit',$hit);

        $News_rcount_One = $M_News_rcount->where($where1)->find();
        if(empty($News_rcount_One)){
            $where1['addTime'] = date('Y-m-d H:i:s',time());
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $readnums = $where['readnums'] = $info['readnums']+1;
            $M_News_rcount->add($where1);
            M("hotnews")->where(array('id'=>$id))->setField('readnums',$readnums);
        }else{
            $where1['id'] = $News_rcount_One['id'];
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $M_News_rcount->save($where1);
        }

        $signPackage = R('Jssdk/qCode');
        $this->assign('signPackage',$signPackage);
        $this->assign('id',$id);

        $this->assign('readnums',$readnums);
        $this->assign("info",$res);
        $this->display();
    }



      /*
     * 加载更多
    */
    
    public function loadmord(){

        $num=intval(I('post.num'));
        
        $new= M('hotnews');
        
        $where['status'] = 1;
        
        $i=5;
        $st = $num+$i;
        
        $list=$new->where($where)->order('addtime desc,id desc')->limit($i,$st)->select();
        $count=$new->where($where)->count();
        $con='';



        if($list){
            foreach ($list as $k=>$v){

                if($v['pic']){

                    $con.='<div class="main_body_lis">
                    <a href="/Home/customer/hotDetail?id='.$v['id'].'">
                        <div class="main_body_lis_l">
                            <div class="head_ico">
                                <img src="'.$v['pic'].'">
                            </div>
                        </div>
                        <div class="main_body_lis_r">
                            <div class="tab1_txt">
                                <h3>'.$v['title'].'</h3>
                                <p class="css1">'.htmlspecialchars_decode(stripslashes($v['gaiyao'])).'</p>
                            </div>
                        </div>
                        
                        <div class="clear"></div>
                    </a>
                </div>';

                }else{
                    $con.='<div class="main_body_lis">
                    <a href="/Home/customer/hotDetail?id='.$v['id'].'">
                        <div class="main_body_lis_l">
                            <div class="head_ico">
                                <img src="/Public/Home/Images/hot_logo.jpg">
                            </div>
                        </div>
                        <div class="main_body_lis_r">
                            <div class="tab1_txt">
                                <h3>'.$v['title'].'</h3>
                                <p class="css1">'.htmlspecialchars_decode(stripslashes($v['gaiyao'])).'</p>
                            </div>
                        </div>
                        
                        <div class="clear"></div>
                    </a>
                </div>';

                }
            }
        }
        

        $n=$st+$i;
         
        if($n >= $count){
            $data['t']="1";
    
        }else{
    
            $data['t']="";
    
        }
         
        $data['st']=$st;
        $data['con']=$con;
        $this->ajaxReturn($data);
        exit();
    
    }





     /*
    * 文章点赞
    */

    public function addhit(){
        if(IS_AJAX){
            $id = intval(I('post.id'));
            $where['newsID'] = $id;
            $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip

            $where['ip'] = $ip;
            $where['typeid'] = 4;
            $readnums = M('hotnews')->where(array('id'=>$id))->getField('hit');

            $info  = M('hit')->where($where)->find();
            if(empty($info)){
                $where['addtime'] = date('Y-m-d H:i:s',time());
                $res = M('hit')->add($where);
                $hit = $readnums + 1;
                $save = M('hotnews')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>1
                );

               echo json_encode($result);exit;
            }else{

                $res = M('hit')->delete($info['id']);
                if($readnums>0){
                    $hit = $readnums - 1;
                }
               
                $save = M('hotnews')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>2
                );

               echo json_encode($result);exit;



            }

            
        }
    }





    /**
     * 热点信息详情
     */
    public  function hotDetailView(){
        $id = intval(I("id"));
        $res = M("hotnews")->where(array("id"=>$id))->find();
        $this->assign("info",$res);
        $this->display("hotDetail");
    }


    /**
     * 编辑职位
     * @param id 简历的id
     * 提交后将变成重新审核
     */
    public  function needs_edit(){
        $id = intval(I("id"));
        if(IS_AJAX){
            $data = I("post.");
            $id   = $data['id'];
            unset($data['id']);
            if(!$id){
                $data['status']     = 0;
                $data['company_id'] = $this->user_id;
                $data['addtime']    = date("Y-m-d H:i:s", time());
                $res = M("recruitment")->add($data);
                if($res){
                    $this->ajaxReturn(array("status"=>1, "info"=> "新增成功，等待通过审核！", "url"=>U('Home/Customer/needs_edit',array("id"=>$res))));
                }else{
                    $this->ajaxReturn(array("status"=>1, "info"=> "新增失败！"));
                }
            }else{
                $data['status'] = 0;
                $data['addtime']    = date("Y-m-d H:i:s", time());
                $res = M("recruitment")->where(array('id'=>$id,"company_id"=>$this->user_id))->save($data);
                if($res){
                    $this->ajaxReturn(array("status"=>1, "info"=> "修改成功，等待通过审核！"));
                }else{
                    $this->ajaxReturn(array("status"=>1, "info"=> "修改失败！"));
                }
            }
        }
        $map = array(
                "company_id" => $this->user_id,
                "id"         => $id
            );
        $res = M("recruitment")->where($map)->find();
        $this->assign("title","编辑职位");
        if($id && !$res){
            $res = "";
        }elseif(!$id){
            $res = array();
            $this->assign("title","发布职位");
        }
        $this->assign("cache",$res);
        $this->display();
    }


    /**
     * 职位介绍
     * 需求中不存在该页面：已注释
     */
    public function job_introduction(){
        die;
        $id = intval(I("id"));
        $map = array(
                "company_id" => $this->user_id,
                "id"         => $id
            );
        $res = M("recruitment")->where($map)->find();
        $this->assign("cache",$res);
        $this->display();
    }


   
}