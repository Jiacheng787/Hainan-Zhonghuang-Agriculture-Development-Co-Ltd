<?php
namespace Home\Controller;
use Home\Controller;
class GuideController extends PublicController {
    /**
     * 服务指南
     */
    public function index(){
    	$class = M("service_class")->where(array("isdel"=>0))->order("sequence desc")->select();
    	$m = M("service");
    	foreach($class as $k=>$v){
    		$class[$k]['data'] = $m->where(array("cate_id"=>$v['id'],"status"=>1))->order("addtime desc")->field("id,title")->select();
    	}
    	$this->assign("cache",$class);
        $this->display();
    }


    /**
     * 详情
     */
    public function detail(){
    	$id = intval(I("id"));
    	$res = M("service")->find($id);


        /* 阅读记录 */
        $readnums = $res['readnums'];  //阅读量
        $M_News_rcount = M('News_rcount');
        $where1['newsID'] = $id;
        $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip
        $where1['ip'] = $ip;
        $where1['typeid'] = 3;

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>3))->find();


        $this->assign('hit',$hit);

        $News_rcount_One = $M_News_rcount->where($where1)->find();
        if(empty($News_rcount_One)){
            $where1['addTime'] = date('Y-m-d H:i:s',time());
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $readnums = $where['readnums'] = $info['readnums']+1;
            $M_News_rcount->add($where1);
            M("service")->where(array('id'=>$id))->setField('readnums',$readnums);
        }else{
            $where1['id'] = $News_rcount_One['id'];
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $M_News_rcount->save($where1);
        }
        $this->assign('readnums',$readnums);
    	$this->assign("info",$res);
    	$this->display();
    }




     /*
    * 文章点赞
    */

    public function addhit(){
        if(IS_AJAX){
            $id = intval(I('post.id'));
            $where['newsID'] = $id;
            $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip

            $where['ip'] = $ip;
            $where['typeid'] = 3;
            $readnums = M('service')->where(array('id'=>$id))->getField('hit');

            $info  = M('hit')->where($where)->find();
            if(empty($info)){
                $where['addtime'] = date('Y-m-d H:i:s',time());
                $res = M('hit')->add($where);
                $hit = $readnums + 1;
                $save = M('service')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>1
                );

               echo json_encode($result);exit;
            }else{

                $res = M('hit')->delete($info['id']);
                if($readnums>0){
                    $hit = $readnums - 1;
                }
               
                $save = M('service')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>2
                );

               echo json_encode($result);exit;



            }

            
        }
    }






}