<?php
namespace Home\Controller;
use Home\Controller;
class IndexController extends PublicController {
    /**
     * 首页
     */
    public function index(){
		        
        //类型头部
        $gg = M('gonggao');
        $zx['type'] = 1;//资讯
        $zx['is_tui'] = 1;//资讯
        $gonggao = $gg->where($zx)->order('list asc,id asc')->select();
        $i = 0;
        foreach ($gonggao as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);

     
		$memberID = session('member_id');

		
		//资讯
        $new= M('news');
        $where['status'] = 1;
        $zx = $new->where($where)->order("addtime desc,id desc")->limit('5')->select();
        $count=$new->where($where)->count();
        $this->assign('count',$count);
        $this->assign('zixun',$zx);
        
       
    
        //分公司
        $com = M('company');
        $companys = $com->select();
        $this->assign('companys',$companys);
        
        $this->assign('gonggao',$gonggao);
        $this->assign('jiejian',$jiejian);
        $this->assign('zp',$zp);
        $this->assign('wm',$wm);
        $this->display();
    }
    
    /*
     * 加载更多
    */
    
    public function loadmord(){

    	$num=intval(I('post.num'));
    	
    	$new= M('news');
    	
    	$where['status'] = 1;
    	
    	$i=5*$num;
    	$st = 5;


    	$count=$new->where($where)->count();
        $list=$new->where($where)->order('addtime desc,id desc')->limit($i,$st)->select();
       
    	$con='';
        $offet = $num;
        if($list){
            foreach ($list as $k=>$v){
                $con.='<div class="main_body_lis">
                    <a href="/Home/news/index?id='.$v['id'].'">
                        <div class="main_body_lis_l">
                            <div class="head_ico">
                                <img src="'.$v['pic'].'">
                            </div>
                        </div>
                        <div class="main_body_lis_r">
                            <div class="tab1_txt">
                                <h3>'.$v['title'].'</h3>
                                <p class="css1">'.htmlspecialchars_decode(stripslashes($v['gaiyao'])).'</p>
                            </div>
                        </div>
                        
                        <div class="clear"></div>
                    </a>
                </div>';
            }
            $offet = $offet+1;
        }
    
        
    	$n=$i;
    	 
    	if($n+1 >=$count){
    		$data['t']="1";
    
    	}else{
    
    		$data['t']="";
    
    	}


    	
    	$data['con']=$con;
        $data['k']=$offet;
    	$this->ajaxReturn($data);
    	exit();
    
    }
    
	
	
    /**
     * 首页
     */
    public function indexcs(){
        
        //类型头部
        
        $gg = M('gonggao');
        $zx['type'] = 1;//资讯
        $gonggao = $gg->where($zx)->select();
       // dump($gonggao);
      
        
        $jj['type'] = 2;//简介
        $jiejian = $gg->where($jj)->select();

        $zp['type'] = 3;  //招聘
        $zp = $gg->where($zp)->select();
    
        $wm['type'] = 4;
        $wm = $gg->where($wm)->select();

    
		$memberID = session('member_id');

		
		//资讯
        $new= M('news');
        $where['is_tui'] = 1;
        $more = I('get.more')?I('get.more'):'';
        if(!empty($more)){
            $zx = $new->where($where)->select();
        }else{
            $zx = $new->where($where)->limit('5')->select();
        }
        $this->assign('zixun',$zx);
        
       
        
        
        
        //分公司
        $com = M('company');
        $companys = $com->select();
        $this->assign('companys',$companys);
        
        $this->assign('gonggao',$gonggao);
        $this->assign('jiejian',$jiejian);
        $this->assign('zp',$zp);
        $this->assign('wm',$wm);
        $this->display();
    }


	public function getauto(){
		$news= M('news');
		$page = intval($_GET['page']);  //获取请求的页数
		$start = $page*5;
		$data = $news->where('is_tui=1')->limit($start,5)->select();
		$this->ajaxReturn($data);
		exit;
	}


    //资讯
    public function  introduction(){
           //类型头部
        
        $gg = M('gonggao');
        $zx['type'] = 1;//资讯
        $gonggao = $gg->where($zx)->select();
  
        $jj['type'] = 2;//简介

        $jj['is_tui'] = 1;//简介
        $jiejian = $gg->where($jj)->order('list asc,id asc')->select();

        $i = 0;
        foreach ($jiejian as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);
        $memberID = session('member_id');


        $introduction = M('introdution')->find();
        $introduction['content'] = str_ireplace('\"','"',htmlspecialchars_decode($introduction['content']));

        
        //资讯
        $new= M('news');
        $where['is_tui'] = 1;

        $zx = $new->where($where)->select();
        $this->assign('zixun',$zx);
        
     
        $aboutServer = M("content")->where(array('type'=>1))->order('id asc')->select();

        $this->assign("content1", $aboutServer);
     
        $aboutServer2 = M("content")->where(array('type'=>2))->order('id asc')->select();

        $this->assign("content2", $aboutServer2);

        //@我们
        $con = M('contact');
        $res = $con->select();
        $this->assign('res',$res[0]);
        
        //分公司
        $com = M('company');
        $companys = $com->select();
        $this->assign('companys',$companys);
        $this->assign('introduction',$introduction);
        
        $this->assign('gonggao',$gonggao);
        $this->assign('jiejian',$jiejian);
        $this->assign('zp',$zp);
        $this->assign('wm',$wm);
        $this->display();
    }

    public function about(){
        $id = intval(I("id"));
        $res = M("content")->where(array("id"=>$id))->find();
        $res['content'] = stripslashes(htmlspecialchars_decode($res['content']));
        $this->assign("cache", $res);
        $this->display();
    }
    
    //招聘

    public function recruit(){
         //类型头部
        
        $gg = M('gonggao');
        $zx['type'] = 1;//资讯
        $gonggao = $gg->where($zx)->select();

        $jj['type'] = 2;//简介
        $jiejian = $gg->where($jj)->select();
 
        $zppin['type'] = 3;  //招聘
        $zppin['is_tui'] = 1;  //招聘

        $zppin = $gg->where($zppin)->order('list asc,id asc')->select();

        $i = 0;
        foreach ($zppin as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);
        


  
        $wm['type'] = 4;
        $wm = $gg->where($wm)->select();

    
        $memberID = session('member_id');

        if($memberID!=''){
            $memberInfo = M('member')->where(array('id'=>$memberID))->find();
            $this->assign('memberInfo',$memberInfo);

        }
		
        //招聘
        $zp = M('recruitment');
        $M_Collection    = M('Collection');
        $M_Resume_cast   = M('Resume_cast');
        $where['isdel']  = 0;
        $where['status'] = 1;
		
        $currnttime = date('Y-m-d',time());
        $where['endtime'] = array('egt',$currnttime);
        $zpinfo = $zp->where($where)->order('addtime desc,id desc')->limit('8')->select();

        $count = $zp->where($where)->count();

        foreach ($zpinfo as $k=>$v){
            
            $zpinfo[$k]['collectionCount'] = $M_Collection->where( array('userid'=>$memberID,'recru_id'=>$v['id']) )->count();
            $zpinfo[$k]['resume_castCount'] = $M_Resume_cast->where( array('userid'=>$memberID,'recru_id'=>$v['id']) )->count();
            $zpinfo[$k]['addtime'] = date( 'Y-m-d ',strtotime($v['addtime']));
            $zpinfo[$k]['endtime'] = date( 'Y-m-d ',strtotime($v['endtime']));
            $zpinfo[$k]['company'] = M('company')->where(array('id'=>$v['company_id']))->getField('company_name');
        }
  
        $this->assign('zpinfo',$zpinfo);
        
      
        $this->assign('gonggao',$gonggao);
        $this->assign('jiejian',$jiejian);
        $this->assign('zppin',$zppin);
        $this->assign('count',$count);
        $this->assign('zp',$zp);
        $this->assign('wm',$wm);
        $this->display();

    }


    //@我们
    public function us(){
          //类型头部
        
        $gg = M('gonggao');
        $zx['type'] = 1;//资讯
        $gonggao = $gg->where($zx)->select();
   
        $jj['type'] = 2;//简介
        $jiejian = $gg->where($jj)->select();
        //dump($jiejian);
        $zp['type'] = 3;  //招聘
        $zp = $gg->where($zp)->select();

        $wm['type'] = 4;
        $wm['is_tui'] = 1;
        $wm = $gg->where($wm)->order('list asc,id asc')->select();

        $i = 0;
        foreach ($wm as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);

    
        $memberID = session('member_id');


        //@我们
        $con = M('contact');
        $res = $con->select();
        $this->assign('res',$res[0]);
		
		
		//服务电话
		$fuwu_tel = M('Introdution')->where(array("classid"=>2))->order("id asc")->select();
        $this->assign('fuwu_tel',$fuwu_tel);
        //分公司
        $com = M('company');
        $companys = $com->where(array('cate'=>1,'isdel'=>0))->order('id asc')->select();
        $this->assign('companys',$companys);
        
        $this->assign('gonggao',$gonggao);
        $this->assign('jiejian',$jiejian);
        $this->assign('zp',$zp);
        $this->assign('wm',$wm);
        $this->display();

    }




    
/**
     * 公告
     */
    public function gonggao(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $news = M('gonggao');
        $info = $news->where($where)->select();
        $this->assign('info',$info[0]);
        $this->display();
    }
    
    
    /**
     * 简介
     */
    public function jianjie(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $news = M('gonggao');
        $info = $news->where($where)->select();
        $this->assign('info',$info[0]);
        $this->display();
    }
    
    /**
     * 招聘
     */
    
    public function zp(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $news = M('gonggao');
        $info = $news->where($where)->select();
        $this->assign('info',$info[0]);
        $this->display();
    }
    
    /**
     * 我们
     */
    public function wm(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $news = M('gonggao');
        $info = $news->where($where)->select();
        $this->assign('info',$info[0]);
        $this->display();
    }


    /**
     * 地图选择
    */

    public function map(){
        



       $this->display();
    }









}