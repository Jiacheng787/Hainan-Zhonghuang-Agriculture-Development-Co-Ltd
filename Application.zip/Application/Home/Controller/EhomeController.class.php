<?php
namespace Home\Controller;
use Think\Controller;
class EhomeController extends Controller {
    /**
     * 
     */
    public function index(){
        $this->display();
    }




    
  
    
  




    
}