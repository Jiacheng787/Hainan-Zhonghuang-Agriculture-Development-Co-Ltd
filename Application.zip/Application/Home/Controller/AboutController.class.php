<?php
namespace Home\Controller;
use Think\Controller;
class AboutController extends Controller {
    /**
     * 人力资源外包
     */
    public function about1(){
        $res = M("aboutServer")->where(array('classid'=>"2"))->order('id asc')->select();
        $this->assign("content1", $res);
        $this->assign("about", 3);
        $this->display();
    }
    /**
     * 人才派遣
     */
    public function about2(){
        $res = M("aboutServer")->where(array("classid"=>"5"))->order('id asc')->select();
        $this->assign("cache", $res);
        $this->assign("about", 3);
        $this->display();
    }
    /**
     * 管理咨询
     */
    public function about3(){
        $res = M("aboutServer")->where(array('classid'=>"6"))->order('id asc')->select();
        $this->assign("content1", $res);
        $this->assign("about", 3);
        $this->display();
    }
    /**
     * 增值业务
     */
    public function about4(){
        $res = M("aboutServer")->where(array("classid"=>"1"))->order('id asc')->select();
        $this->assign("cache", $res);
        $this->assign("about", 3);
        $this->display();

       
    }
    /**
     * 弹性福利
     */
    public function about5(){
        $res = M("aboutServer")->where(array("classid"=>"4"))->order('id asc')->select();
        $this->assign("content1", $res);
        $this->assign("about", 3);
        $this->display();
    }
    /**
     * 特色服务
     */
    public function about6(){
        $res = M("aboutServer")->where(array("classid"=>"3"))->order('id asc')->select();
        $this->assign("cache", $res);
        $this->assign("about", 3);
        $this->display();
    }

}