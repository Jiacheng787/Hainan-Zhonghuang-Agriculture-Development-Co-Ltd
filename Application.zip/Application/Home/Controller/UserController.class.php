<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    /**
     * 首页
     */
    public function index(){
        $this->display();
    }


    /*
    *修改密码
    */
    public function editpassword(){
        $this->display();
    }
    
    //员工登录
    public function elogin(){
        $this->display();
    }
    
    /**
     * 微信登录
     */
    public function weixinlogin(){
        $this->display();
    }
    
    /**
     * 我的消息
     */
    public function my_message(){
        $this->display();
    }
    
    /**
     * 消息详情
     */
    public function my_messagedot(){
        $this->display();
    }
    
    /**
     * 企业修改密码
     */
    public function password(){
        $this->display();
    }
    /**
     * 员工修改密码
     */
    public function password2(){
        
        $this->display();
    }
    
    /**
     * 报表
     */
    public function baobiao(){
        $this->display();
    }
    
    /**
     * 简历中心
     */
    public function resume(){
        $memberID = session('member_id');
        $M = M('myexperience');
        $member = M('member')->find($memberID);

        $resume = M('myresume')->where(array('memberID'=>$memberID))->find();
        
        if($resume){
            $can = 1;
        }else{
            $can = 0;
        }
        
        $this->assign('can',$can);

        $education =$M->where(array('resumeID'=>$resume['id'],'memberID'=>$memberID,'typeID'=>'1'))->select();
        $experience = $M->where(array('resumeID'=>$resume['id'],'memberID'=>$memberID,'typeID'=>'2'))->select();
        if(!empty($resume['birth'])){
            $birth =  strtotime($resume['birth']);
            $resume['birth'] = date('Y-m',$birth);
        }
        
        foreach ($education as $k => $v) {
            $time1 =  strtotime($v['starttime']);
            $time2 =  strtotime($v['endtime']);
            $education[$k]['starttime'] = date('Y-m',$time1); 
            $education[$k]['endtime'] = date('Y-m',$time2);

        }

        foreach ($experience as $key => $val) {
            $start =  strtotime($val['starttime']);
            $end =  strtotime($val['endtime']);
            $experience[$key]['starttime'] = date('Y-m',$start); 
            $experience[$key]['endtime'] = date('Y-m',$end);
        }

        $this->assign('member',$member);
        $this->assign('resume',$resume);
        $this->assign('education',$education);
        $this->assign('experience',$experience);
        $this->display();
    }
    /**
     * 编辑简历
     */
    public function addresume(){
        if(IS_AJAX){
            $memberID = session('member_id');
            if($memberID==''){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少必要参数'
                    );
                echo json_encode($result);exit;

            }

            if($memberID!=''){
                $resumeID = M('myresume')->where(array('memberID'=>$memberID))->getField('id');

                $data['username'] = I('post.username');
                $data['sex'] = I('post.sex');
                $data['birth'] = I('post.birth');
                $data['mobile'] = I('post.mobile');
                $data['email'] = I('post.email');
                $data['qq'] = I('post.qq');
                $data['memberID'] = $memberID;
                $teach = I('post.myeducation');
                $work = I('post.myexperience');
			
				$data_member['type'] = mobile($data['mobile']);
				
				M('Member')->where(array('id'=>$memberID))->save($data_member);
				

                if($resumeID){
					
                    $save = M('myresume')->where(array('id'=>$resumeID))->save($data);
                    $info = M('myresume')->where(array('id'=>$resumeID))->find();
                    if($teach!=''){
                        $res = M('myexperience')->where(array('resumeID'=>$resumeID,'memberID'=>$memberID,'type'=>1))->delete();
                    }

                    if($work!=''){
                        $res1 = M('myexperience')->where(array('resumeID'=>$resumeID,'memberID'=>$memberID,'type'=>2))->delete();
                    }
                  
                    $jianliId = $resumeID;
                    if($save||$res||$res1||$info){
                        $education_arr = explode(',', $teach);
                        $education_arr1 = array_filter($education_arr);
                        foreach ($education_arr1 as $k => $val) {
                            $education =explode('_', $val);
                            $arr['starttime'] =  $education[0];
                            $arr['endtime'] =  $education[1];
                            $arr['school'] =  $education[2];
                            $arr['major'] =  $education[3];
                            $arr['education'] =  $education[4];
                            $arr['eduid'] =  $education[5];
                            $arr['resumeID'] =  $jianliId;
                            $arr['memberID'] =  $memberID;
                            $arr['typeID'] = '1';
                            $education_res = M('myexperience')->add($arr);
                        }

                        $gongzuo = explode(',', $work);
                        $gongzuo1 = array_filter($gongzuo);

                        foreach ($gongzuo1 as $k => $v) {
                            $experience =explode('_', $v);
                            $arrys['starttime'] = $experience[0];
                            $arrys['endtime'] =  $experience[1];
                            $arrys['company'] =  $experience[2];
                            $arrys['position'] =  $experience[3];
                            $arrys['resumeID'] =  $jianliId;
                            $arrys['memberID'] =  $memberID;
                            $arrys['typeID'] = '2';
                            $experience_res = M('myexperience')->add($arrys);
                        }

                        if($education_res||$experience_res||$save){
                            $result = array(
                                'status'=>'1',
                                'info'=>'编辑成功'
                                );
                            echo json_encode($result);exit;
                        }else{
                            $result = array(
                                'status'=>'0',
                                'info'=>'编辑失败'
                            );
                            echo json_encode($result);exit;
                        }

                    }
      
                }else{
                    $res = M('myresume')->add($data);
                    $jianliId = $res;
                    if($res){
                        $education_arr = explode(',', $teach);
                        $education_arr1 = array_filter($education_arr);
                        foreach ($education_arr1 as $k => $val) {
                            $education =explode('_', $val);
                            $arr['starttime'] =  $education[0];
                            $arr['endtime'] =  $education[1];
                            $arr['school'] =  $education[2];
                            $arr['major'] =  $education[3];
                            $arr['education'] =  $education[4];
                            $arr['eduid'] =  $education[5];
                            $arr['resumeID'] =  $jianliId;
                            $arr['memberID'] =  $memberID;
                            $arr['typeID'] = '1';
                            $education_res = M('myexperience')->add($arr);
                        }

                        $gongzuo = explode(',', $work);
                        $gongzuo1 = array_filter($gongzuo);

                        foreach ($gongzuo1 as $k => $v) {
                            $experience =explode('_', $v);
                            $arrys['starttime'] = $experience[0];
                            $arrys['endtime'] =  $experience[1];
                            $arrys['company'] =  $experience[2];
                            $arrys['position'] =  $experience[3];
                            $arrys['resumeID'] =  $jianliId;
                            $arrys['memberID'] =  $memberID;
                            $arrys['typeID'] = '2';
                            $experience_res = M('myexperience')->add($arrys);
                        }

                        if($education_res||$experience_res||$res){
                            $result = array(
                                'status'=>'1',
                                'info'=>'添加成功'
                                );
                            echo json_encode($result);exit;
                        }else{
                            $result = array(
                                'status'=>'0',
                                'info'=>'添加失败'
                            );
                            echo json_encode($result);exit;
                        }

                    }else{
                        $result = array(
                                'status'=>'0',
                                'info'=>'添加失败'
                            );
                        echo json_encode($result);exit;
                    }
                } 

            }

               
        }

    }


/**
     * 添加简历
    */

/*     public function addresume(){
        if(IS_AJAX){
            $memberID = session('member_id');
            if($memberID==''){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少必要参数'
                    );
                echo json_encode($result);exit;

            }

            if($memberID!=''){
                $resumeID = M('myresume')->where(array('memberID'=>$memberID))->getField('id');

                $data['username'] = I('post.username');
                $data['sex'] = I('post.sex');
                $data['birth'] = I('post.birth');
                $data['mobile'] = I('post.mobile');
                $data['email'] = I('post.email');
                $data['qq'] = I('post.qq');
                $data['memberID'] = $memberID;
                $teach = I('post.myeducation');
                $work = I('post.myexperience');
             
            
                if($resumeID){
                    $save = M('myresume')->where(array('id'=>$resumeID))->save($data);
                    $info = M('myresume')->where(array('id'=>$resumeID))->find();
                    if($teach!=''){
                        $res = M('myexperience')->where(array('resumeID'=>$resumeID,'memberID'=>$memberID,'type'=>1))->delete();
                    }

                    if($work!=''){
                        $res1 = M('myexperience')->where(array('resumeID'=>$resumeID,'memberID'=>$memberID,'type'=>2))->delete();
                    }
                  
                    $jianliId = $resumeID;
                    if($save||$res||$res1||$info){
                        $education_arr = explode(',', $teach);
                        $education_arr1 = array_filter($education_arr);
                        foreach ($education_arr1 as $k => $val) {
                            $education =explode('_', $val);
                            $arr['starttime'] =  $education[0];
                            $arr['endtime'] =  $education[1];
                            $arr['school'] =  $education[2];
                            $arr['major'] =  $education[3];
                            $arr['education'] =  $education[4];
                            $arr['eduid'] =  $education[5];
                            $arr['resumeID'] =  $jianliId;
                            $arr['memberID'] =  $memberID;
                            $arr['typeID'] = '1';
                            $education_res = M('myexperience')->add($arr);
                        }

                        $gongzuo = explode(',', $work);
                        $gongzuo1 = array_filter($gongzuo);

                        foreach ($gongzuo1 as $k => $v) {
                            $experience =explode('_', $v);
                            $arrys['starttime'] = $experience[0];
                            $arrys['endtime'] =  $experience[1];
                            $arrys['company'] =  $experience[2];
                            $arrys['position'] =  $experience[3];
                            $arrys['resumeID'] =  $jianliId;
                            $arrys['memberID'] =  $memberID;
                            $arrys['typeID'] = '2';
                            $experience_res = M('myexperience')->add($arrys);
                        }

                        if($education_res||$experience_res||$save){
                            $result = array(
                                'status'=>'1',
                                'info'=>'编辑成功'
                                );
                            echo json_encode($result);exit;
                        }else{
                            $result = array(
                                'status'=>'0',
                                'info'=>'编辑失败'
                            );
                            echo json_encode($result);exit;
                        }

                    }
      
                }else{
                    $res = M('myresume')->add($data);
                    $jianliId = $res;
                    if($res){
                        $education_arr = explode(',', $teach);
                        $education_arr1 = array_filter($education_arr);
                        foreach ($education_arr1 as $k => $val) {
                            $education =explode('_', $val);
                            $arr['starttime'] =  $education[0];
                            $arr['endtime'] =  $education[1];
                            $arr['school'] =  $education[2];
                            $arr['major'] =  $education[3];
                            $arr['education'] =  $education[4];
                            $arr['eduid'] =  $education[5];
                            $arr['resumeID'] =  $jianliId;
                            $arr['memberID'] =  $memberID;
                            $arr['typeID'] = '1';
                            $education_res = M('myexperience')->add($arr);
                        }

                        $gongzuo = explode(',', $work);
                        $gongzuo1 = array_filter($gongzuo);

                        foreach ($gongzuo1 as $k => $v) {
                            $experience =explode('_', $v);
                            $arrys['starttime'] = $experience[0];
                            $arrys['endtime'] =  $experience[1];
                            $arrys['company'] =  $experience[2];
                            $arrys['position'] =  $experience[3];
                            $arrys['resumeID'] =  $jianliId;
                            $arrys['memberID'] =  $memberID;
                            $arrys['typeID'] = '2';
                            $experience_res = M('myexperience')->add($arrys);
                        }

                        if($education_res||$experience_res||$res){
                            $result = array(
                                'status'=>'1',
                                'info'=>'添加成功'
                                );
                            echo json_encode($result);exit;
                        }else{
                            $result = array(
                                'status'=>'0',
                                'info'=>'添加失败'
                            );
                            echo json_encode($result);exit;
                        }

                    }else{
                        $result = array(
                                'status'=>'0',
                                'info'=>'添加失败'
                            );
                        echo json_encode($result);exit;
                    }
                } 

            }

               
        }

    }
 */

    /**
     * 服务指南
     */
    public function guide(){
        $this->display();
    }
    
    /**
     * 薪资
     */
    public function money(){
        $this->display();
    }
    
    /**
     * 我的消息
     */
    
    public function message(){
        $memberID = session('member_id');
        $where['memberID'] = $memberID;
        $member = M('member')->find($memberID);
        $message = M('notice')->where($where)->select();
        $this->assign('member',$member);
        $this->assign('message',$message);
        $this->display();
    }


    /**
     * 删除消息
    */
    public function delmessage(){
        if(IS_AJAX){
            $id = intval(I('post.id'));
            if($id!=""){
                $del = M('notice')->delete($id);
                if($del){
                    $result = array(
                        'status'=>1,
                        'info'=>'删除成功'
                        );
                    echo json_encode($result);exit;
                }
            }
        }
    }






    
    /**
     * 消息详情
     */
    public function messagedetail(){
        $id = I('get.id');
        $detalil = M('notice')->find($id); 

        if($detalil['fujian']!=''){
            $file = explode(',',$detalil['fujian']);
            $file = array_filter($file);
   
            $filename = explode(',',$detalil['filename']);
            $filename = array_filter($filename);


            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $files[$key]['file'] = $str[$length-1];
                $files[$key]['fujian'] = $val ;
            }


            foreach ($filename as $key => $vo) {
                $files[$key]['filename'] = $vo;
            } 

        }

        $this->assign('files',$files);
        $this->assign('detalil',$detalil);
        $this->display();
    }
    
    /**
     * 员工信息查询
     */
    public function search(){
        $this->display();
    }
    
    /**
     * 客服服务
     */
    public function server(){
        $this->display();
    }
    
    /**
     * 社保
     */
    public function shebao(){
        $this->display();
    }
    
    /**
     * 员工信息
     */
    public function staffinfo(){
        $this->display();
    }
    
}