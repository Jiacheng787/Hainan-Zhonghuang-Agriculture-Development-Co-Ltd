<?php
namespace Home\Controller;
use Home\Controller;
class LessonController extends PublicController {
    /**
     * 东方课堂
     * 
     */
    public function index(){


        $gg = M('gonggao');
        $zx['type'] = 5;
        $zx['is_tui'] = 1;
        $gonggao = $gg->where($zx)->order('list asc,id asc')->select();
    
        $i = 0;
        foreach ($gonggao as $key => $vo) {
            if($vo['pic']){
                $i++;
            }
        }

        $this->assign('num',$i);

    	$class = M("classnews")->where(array("status"=>1))->field("id,gaiyao,is_slide,pic,title")->order("addtime desc,id desc")->limit('5')->select();
    	$banner = array();
    	foreach($class as $k=>$v){
    		$banner[] = $v['is_slide']?array('pic'=>$v['pic'],"title"=>$v['title']):"";
    	}

        $count=M("classnews")->where(array("status"=>1))->count();
        $this->assign('count',$count);



    	$banner = array_filter($banner);
    	$this->assign("banner",$banner);
        $this->assign("gonggao",$gonggao);
    	$this->assign("cache",$class);
        $this->display();
    } 



     /*
     * 加载更多
    */
    
    public function loadmord(){

        $num=intval(I('post.num'));
        
        $new= M('classnews');
        
        $where['status'] = 1;
        
        $i=5;
        $st = $num+$i;
        
        $list=$new->where($where)->order('addtime desc,id desc')->limit($i,$st)->select();
        $count=$new->where($where)->count();
        $con='';

        if($list){
            foreach ($list as $k=>$v){
                $con.='<div class="main_body_lis">
                    <a href="/Home/lesson/detail?id='.$v['id'].'">
                        <div class="main_body_lis_l">
                            <div class="head_ico">
                                <img src="'.$v['pic'].'">
                            </div>
                        </div>
                        <div class="main_body_lis_r">
                            <div class="tab1_txt">
                                <h3>'.$v['title'].'</h3>
                                <p class="css1">'.htmlspecialchars_decode(stripslashes($v['gaiyao'])).'</p>
                            </div>
                        </div>
                        
                        <div class="clear"></div>
                    </a>
                </div>';

            }
        }
        

        $n=$st+$i;
         
        if($n >= $count){
            $data['t']="1";
    
        }else{
    
            $data['t']="";
    
        }
         
        $data['st']=$st;
        $data['con']=$con;
        $this->ajaxReturn($data);
        exit();
    
    }







    /**
     * 详情
     */
    public function detail(){
    	$id = intval(I("id"));
    	$res = M("classnews")->where(array("id"=>$id))->find();

        $piclist = '';
        if($res['pic1']){
            $piclist=explode(',', $res['pic1']);
        }
        
        $this->assign('piclist',$piclist);

        if($res['fujian']!=''){
            $file = explode(',',$res['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$res['filename']);
            $filename = array_filter($filename);


            foreach ($file as $key => $val) {
                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $files[$key]['file'] = $str[$length-1];
                $files[$key]['fujian'] = $val ;
            } 

            foreach ($filename as $key => $vo) {
                $files[$key]['filename'] = $vo;
            } 
        }

        $this->assign('files',$files);

        /* 阅读记录 */
        $readnums = $res['readnums'];  //阅读量
        $M_News_rcount = M('News_rcount');
        $where1['newsID'] = $id;
        $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip
        $where1['ip'] = $ip;
        $where1['typeid'] = 2;

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>2))->find();
        $this->assign('hit',$hit);

        $News_rcount_One = $M_News_rcount->where($where1)->find();
        if(empty($News_rcount_One)){
            $where1['addTime'] = date('Y-m-d H:i:s',time());
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $readnums = $where['readnums'] = $info['readnums']+1;
            $M_News_rcount->add($where1);
            M("classnews")->where(array('id'=>$id))->setField('readnums',$readnums);
        }else{
            $where1['id'] = $News_rcount_One['id'];
            $where1['lastTime'] = date('Y-m-d H:i:s',time());
            $M_News_rcount->save($where1);
        }


        $signPackage = R('Jssdk/qCode');
        $this->assign('signPackage',$signPackage);
        $this->assign('id',$id);
        $this->assign('readnums',$readnums);
    	$this->assign("info",$res);
    	$this->display();
    }


     /**
     * 东方课堂
     */
    public function testView(){
        $menberID = session('member_id');
        $id = intval(I('id'));
    
        $news = M('classnews');
        $where['id'] = $id;
        $info = $news->where($where)->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));

        $hit = M('hit')->where(array('newsID'=>$id,'ip'=>$ip,'typeid'=>2))->find();
        $this->assign('hit',$hit);

        $fujian = $info['fujian'];
        $path=parse_url($fujian);
        $str=explode('/',$path['path']);
        $length = sizeof($str);
        $info['fujian'] = $str[$length-1];
        $this->assign('info',$info);
        $this->assign('readnums',$readnums);
        $this->display("detail");
    }
    


     /*
    * 文章点赞
    */

    public function addhit(){
        if(IS_AJAX){
            $id = I('post.id');
            $where['newsID'] = $id;
            $ip = $_SERVER['REMOTE_ADDR'];//获取当前ip

            $where['ip'] = $ip;
            $where['typeid'] = 2;
            $readnums = M('classnews')->where(array('id'=>$id))->getField('hit');

            $info  = M('hit')->where($where)->find();
            if(empty($info)){
                $where['addtime'] = date('Y-m-d H:i:s',time());
                $res = M('hit')->add($where);
                $hit = $readnums + 1;
                $save = M('classnews')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>1
                );

               echo json_encode($result);exit;
            }else{

                $res = M('hit')->delete($info['id']);
                if($readnums>0){
                    $hit = $readnums - 1;
                }
               
                $save = M('classnews')->where(array('id'=>$id))->setField('hit',$hit);
                $result = array(
                'status'=>'1',
                'hit'=>$hit,
                'type'=>2
                );

               echo json_encode($result);exit;



            }

            
        }
    }























}