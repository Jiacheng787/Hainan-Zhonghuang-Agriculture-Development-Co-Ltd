<?php
namespace Home\Controller;
use Think\Controller;
class CommonController extends Controller {
    public function _initialize(){
		
		$host_url = C('HOST_URL');
        //判断用户是否已经登录
	
        $uid = $_SESSION['member_id'];
		
        if(!$uid){
			if(!empty($cookie_member_id)){
				session('member_id',$cookie_member_id);
			}else{
				$_SESSION['surl']=$host_url.$_SERVER['REQUEST_URI'];
				$this->redirect($host_url."/Login/weixin/"); //直接跳转，不带计时后跳转
			}
        } 
	     
	   

		
    }
}