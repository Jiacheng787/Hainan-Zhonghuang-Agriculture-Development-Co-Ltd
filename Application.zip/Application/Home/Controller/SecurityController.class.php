<?php
namespace Home\Controller;
use Home\Controller;
class SecurityController extends PublicController {

    /*
     * 社保查询
     */
    public function index(){

        $action = M('research');
        $where = array();
        $where['type'] = 1;
        $list = $action->where($where)->order("id asc")->select();
        foreach ($list as $key => $val) {
            $list[$key]['classname'] =  M('research_address')->where(array("id"=>$val['addressid']))->getField('classname');	
        }
        $this->assign('list',$list);
		//print_r($list);
        $this->display();
    }

 
    
}