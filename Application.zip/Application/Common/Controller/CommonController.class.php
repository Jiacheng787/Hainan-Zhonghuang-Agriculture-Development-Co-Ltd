<?php
namespace Common\Controller;
use Think\Controller;
class CommonController extends Controller {
    public function _initialize(){
        //判断用户是否已经登录
        header('content-type:text/html;charset=utf-8;');
        $uid =$_SESSION['admin_id'] ;
        if(!$uid){
            $this->redirect('/Admin/User/login');
        }
		
		
		$access =array();
        $p_id = I('get.p_id');
        session('pid',$p_id);

        $model = MODULE_NAME;
        $controller = CONTROLLER_NAME;
        $action = ACTION_NAME;

        if($username!='admin'){
            $active = $model.'/'.$controller.'/'.$action;
            $node_id = M('node')->where(array('name'=>$active))->getField('id');
           
            if($node_id){
                $rid = M('auth_group_access')->where(array('uid'=>$uid))->getField('group_id');
                $access=M('access')->where(array('role_id'=>$rid))->order('sort asc,node_id asc')->getField('node_id',true);
                if(!(in_array($node_id, $access))){
					$access1=M('access')->where(array('role_id'=>$rid,'level'=>1))->order('sort asc,node_id asc')->getField('node_id',true);
				
					if($access1){
						session('pid',$access[0]);
						$url = M('node')->where(array('id'=>$access[0]))->getField('name');
				
						$this->redirect($url); //直接跳转，不带计时后跳转
					}else{
						redirect(U('Admin/User/login' ,'' ,'') ,2 ,'没有权限......' );
					   
					}

                }

            }
        }
		
		 if(session('pid')==''){
            $rid = M('auth_group_access')->where(array('uid'=>$uid))->getField('group_id');
            $access=M('access')->where(array('role_id'=>$rid,'level'=>1))->order('sort asc,node_id asc')->getField('node_id',true);

            if($access){
                session('pid',$access[0]);
              
            }

        }
       

		
		
		
		
    }
    public function  checkMemberlogin(){

        $uid = $_SESSION['member_id'] ;
            if(!$uid){
                $this->redirect("Member/login"); //直接跳转，不带计时后跳转

//                $this->error("请先登录",U('Member/login'));
            }

    }


    public function uploadImg() {

        $upload = new \Think\UploadFile;
//        $upload = new upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg','svg','xls','xlsx');// 设置附件上传类型
        $savepath='./Uploads/Picture/uploads/'.date('Ymd').'/';
        if (!file_exists($savepath)){
            mkdir($savepath);
        }
        $upload->savePath =  $savepath;// 设置附件上传目录
        if(!$upload->upload()) {// 上传错误提示错误信息
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
            $info =  $upload->getUploadFileInfo();

        
        }
        return $info;
    }


    public function uploadImg1() {

        $upload = new \Think\UploadFile;
//        $upload = new upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg','svg');// 设置附件上传类型
        $savepath='./Uploads/Picture/uploads/'.date('Ymd').'/';
        if (!file_exists($savepath)){
            mkdir($savepath);
        }
        $upload->savePath =  $savepath;// 设置附件上传目录
        if(!$upload->upload()) {// 上传错误提示错误信息
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
            $info =  $upload->getUploadFileInfo();
        }
        return $info;
    }


        public function uploadImg2() {

			$upload = new \Think\UploadFile;//实例化上传类
			$upload->maxSize  = 3145728 ;// 设置附件上传大小
			$upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg','svg');// 设置附件上传类型
			$savepath='./Uploads/Picture/uploads/'.date('Ymd').'/';
			if (!file_exists($savepath)){
				mkdir($savepath);
			}
			$upload->savePath =  $savepath;// 设置附件上传目录
			if(!$upload->upload()) {// 上传错误提示错误信息
				$this->error($upload->getErrorMsg());
			}else{// 上传成功 获取上传文件信息
				$info =  $upload->getUploadFileInfo();

				
				$image = new \Think\Image();
				$smallpath =  $savepath.$info[0]['savename'];
			
				$image->open($smallpath);
				//将图片裁剪为300x300并保存
				$image->thumb(300, 300,\Think\Image::IMAGE_THUMB_FIXED)->save($smallpath);



			}
			return $info;
        }










     public function uploadFile() {

        $upload = new \Think\UploadFile;
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('doc', 'docx', 'pdf');// 设置附件上传类型
        $savepath='./Uploads/upfiles/'.date('Ymd').'/';

        $time = time();

        if (!file_exists($savepath)){
            mkdir($savepath);
        }
        $upload->savePath =  $savepath;// 设置附件上传目录
        if(!$upload->upload()) {// 上传错误提示错误信息
            ///$this->error($upload->getErrorMsg());
            $msg = $upload->getErrorMsg();
            $result = array(
                'status'=>'1',
                'time'=>$time,
                'info'=>$msg
                );
            return $result;

        }else{// 上传成功 获取上传文件信息
            $info =  $upload->getUploadFileInfo();
          
            $info[0]['time'] = $time;


            return $info;
        }

    }





    public function del() {
        $src=str_replace(__ROOT__.'/', '', str_replace('//', '/', $_GET['src']));
        if (file_exists($src)){
            unlink($src);
        }
        print_r($_GET['src']);
        exit();
    }
    public function  GetInfo($id){
        $action=D('Member');
        $returninfo=$action->GetInfomation($id);
        return $returninfo;
    }

}