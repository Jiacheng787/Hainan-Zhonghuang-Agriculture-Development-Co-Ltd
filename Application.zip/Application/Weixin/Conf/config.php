<?php
return array(
	//'配置项'=>'配置值'

        'MODULE_ALLOW_LIST' => array('Weixin'),
        'DEFAULT_MODULE'     => '', //默认模块
        'URL_MODEL'          => '2', //URL模式
        'SESSION_AUTO_START' => true, //是否开启session

        'TMPL_PARSE_STRING'  =>array(
            '__JS__' => '/Public/Weixin/Js',
            '__CSS__' => '/Public/Weixin/Css',
            '__IMAGES__' => '/Public/Weixin/Images',
            '__UPLOADS__' => '/Public/Weixin/Uploads',
            '__UEDITOR__' => '/Public/Weixin/Ueditor',
            '__SWF__' => '/Public/Weixin/Swf',
            '__LHG__' => '/Public/Weixin/lhgcalendar',
        ),

    );
