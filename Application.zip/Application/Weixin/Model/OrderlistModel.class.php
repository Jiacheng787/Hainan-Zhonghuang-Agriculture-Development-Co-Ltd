<?php
namespace Home\Model;
use Think\Model;
class OrderlistModel extends Model{
		function addorderlist($data){

            $rs=$this->add($data);
            return $rs;
		}
//获取所有订单
        function getAllorder($userid='',$state='',$orderno=''){

            if($userid!=''){

                $data['userid']=$userid;
            }
            if($state!=''){
                $data['orderstate']=$state;
            }
            if($orderno!=''){
                $data['orderno']=$orderno;
            }
            $data['is_delete']=0;
            $rs=$this->where($data)->order('addtime desc')->select();
            for($i=0;$i<count($rs);$i++){
                $orderid=$rs[$i]['id'];

                $actiond=D('orderdetail');

                $rsd=$actiond->getorderdetail($orderid);
                $rs[$i]['orderlist']=$rsd;
            }
			
            return $rs;
		}

    //活动订单数量
        function getordercount($userid='',$state=''){

            if($userid!=''){
                $data['userid']=$userid;
            }
            if($state!=''){
                $data['orderstate']=$state;
            }
            $data['is_delete']=0;
            $rs=$this->where($data)->count();
//            echo $action->_sql();exit;

            return $rs;
		}


//更新订单信息
            function updateOrderState($orderno,$state){

//                $data['orderno']=$orderno;
                $data['orderstate']=$state;

            $rs=$this->where("id=$orderno")->save($data);
//            echo $action->_sql();exit;

            return $rs;
		}

    function  getoneorderdetail($orderid){
        $data['id']=$orderid;
       $orderone= $this->where($data)->select();

        $m=D('Orderdetail');
        $rs=$m->getorderdetail($orderid);

        $orderone['detail']=$rs;
        return $orderone;

    }
		
		
		//获取订单详情
        function getOneorder($orderid){

            
            $rs=$this->where('id='.$orderid)->find();
			$actiond=D('orderdetail');
			$order_det=$actiond->where('orderid='.$orderid)->select();
			
			foreach($order_det as $k=>$v){
				$rs['orderdet'][$k]=$v;
				}
			
            return $rs;
		}
		
		//获取需要核验订单
        function getHeyanorder($memberid){

            $rs=$this->where('orderstate=3 and is_delivery=1 and (is_groupbuy=0 or is_groupbuy=1 and groupbuy_ok=1) and online_order_fid!="" and is_refund=0 and userid='.$memberid)->order('addtime desc')->select();
            for($i=0;$i<count($rs);$i++){
                $orderid=$rs[$i]['id'];

                $actiond=D('orderdetail');

                $rsd=$actiond->getorderdetail($orderid);
                $rs[$i]['orderlist']=$rsd;
            }
			
            return $rs;
		}
		

		
		//获取某个产品在某个地区的库存
        function getgoodscount($storeid=0,$goodsid=0){


			$num = $this->where("goods_id=".$goodsid." and storeid=".$storeid." and orderstate = 2 and ((is_groupbuy = 1 and groupbuy_ok = 1) or (is_groupbuy = 0))")->count();//待发货配送
			
			$num1 = $this->where("goods_id=".$goodsid." and storeid=".$storeid." and orderstate=3 and is_groupbuy=1 and groupbuy_ok=0")->count();//待发货(团购中)
			
			$num2 = $this->where("goods_id=".$goodsid." and storeid=".$storeid." and orderstate=3 and is_groupbuy=1 and groupbuy_ok=1")->count();//待发货(团购成功)
			
			$num3 = $this->where("goods_id=".$goodsid." and storeid=".$storeid." and orderstate=3 and is_groupbuy=0")->count();//待发货(单买)
			
			$num4 = $this->where('goods_id='.$goodsid." and storeid=".$storeid." and (is_delivery=0 and orderstate in(3,4) or is_delivery=1 and orderstate=4)")->count();//已出货
			
			$allnum = $num + $num1 + $num2 + $num3 + $num4; 
			
			$stock = M('Goods_store')->where('goods_id='.$goodsid.' and store_id='.$storeid)->getField('stock');
			
			$returnnum = $stock - $allnum;
		
            return $returnnum;
		}
		
		

	}
 ?>