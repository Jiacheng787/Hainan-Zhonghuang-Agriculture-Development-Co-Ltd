<?php
namespace Weixin\Model;
use Think\Model;
class OrderaddressModel extends Model{
		
		function getOneaddress($memberid){
            $action=M("orderaddress");
            $rs=$action->where("id=$memberid")->find();
            return $rs;
		}
		
    	function editaddress($data){
            $action=M("orderaddress");
            $rs=$action->save($data);
            return $rs;
		}
		
	    function addaddress($data){
            $action=M("orderaddress");
            $rs=$action->add($data);
            return $rs;
		}

	    function addresscount($memberid){
			$conut = $this->where('userid='.$memberid)->count();
            return $conut;
		}

		function add_order(){
			
			$urls = session('addresserror');
			$uid = getLoginID();
			
			
			$arr['consignee'] = I('post.consignee');
			$arr['telephone'] = I('post.telephone');
			$arr['province'] = I('post.province');
			$arr['city'] = I('post.city');
			$arr['country'] = I('post.county');
			$arr['xiangqing'] = I('post.xiangqing');
			$arr['userid']=$uid;
			$arr['addtime']=Gettime();
			$arr['add_type']=$_POST['address_type'];
			$arr['is_default'] = intval(I('post.is_default'));
			
			$count = $this->where('userid='.$uid)->count();
			if($count){
				$this->where('is_default=1 and userid='.$uid)->save(array('is_default'=>0));
			}
			
			$rs=$this->add($arr);
			
			if($rs){
				$data['info']=1;
				$data['content']='添加成功！';
				$data['url']=$urls;
			}else{
				$data['info']=0;
				$data['content']='添加失败！';
				$data['url']=$urls;
			}
			return $data;
		}
		
		

	}
 ?>