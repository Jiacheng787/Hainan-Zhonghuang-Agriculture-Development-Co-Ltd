<?php
namespace Home\Model;
use Think\Model;
class ActivityModel extends Model{
		function getList($type){

            $arr = $this->where('classid='.$type.' and is_show=1')->order('sequence asc')->select();
			
/*			foreach($arr as $key=>$value)
			{
				$m=M('Goods');
				$goodsone = $m->where('id='.$value['goodsid'])->find();
				$arr[$key]['goodsname']
			}*/
            return $arr;
		}
		
		function getList2($type){
			
			$where['classid']=array('eq',$type);
			$where['is_show']=array('eq',1);
			//var_dump(session('posId'));exit;
			if(session('posId')){
				$where['dealer_id']=array('eq',session('posId'));
			}

            $arr = $this->where($where)->order('sequence asc')->select();
			//print_r($arr);exit;
            return $arr;
		}



	}
 ?>