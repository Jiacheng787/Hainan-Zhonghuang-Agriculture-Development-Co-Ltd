<?php
namespace Home\Model;
use Think\Model;
class PicModel extends Model{



		function urls_name($arr){
			foreach($arr as $k=>$v){
				$v['tuantypeid'] = M('Goods')->where('id='.$v['goodsid'])->getField('tuantypeid');
				if($v['is_urls_type']!=0){
					if($v['is_urls_type']==1){
						$v['urls']='http://goead1.ysxdgy.com/Index/yhq';
					}elseif($v['is_urls_type']==2){
						$v['urls']='http://goead1.ysxdgy.com/Goods/category';
						}elseif($v['is_urls_type']==3){
							$v['urls']='http://goead1.ysxdgy.com/Goods/category';
							}
							$arrs[$k]=$v;
					}else{
						$arrs[$k]=$v;
						}
				}
				return $arrs;
		}
		

		function urls_name1($arr){
			foreach($arr as $k=>$v){
				$v['tuantypeid'] = M('Goods')->where('id='.$v['goodsid'])->getField('tuantypeid');
				if($v['is_urls_type']!=0){
					if($v['is_urls_type']==1){
						$v['urls']='http://goead1.ysxdgy.com/Index/yhq';
					}elseif($v['is_urls_type']==2){
						$v['urls']='http://goead1.ysxdgy.com/Goods/category';
						}elseif($v['is_urls_type']==3){
							$v['urls']='http://goead1.ysxdgy.com/Goods/category';
							}
							$arrs[$k]=$v;
					}else{
						$arrs[$k]=$v;
						}
				}
				return $arrs; 
		}	
		
		
	}
 ?>