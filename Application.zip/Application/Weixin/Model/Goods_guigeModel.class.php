<?php
namespace Home\Model;
use Think\Model;
class Goods_guigeModel extends Model{
	
		function getinfo($id){
            $rs=$this->where('id = '.$id)->find();
            return $rs;
		}


	}
 ?>