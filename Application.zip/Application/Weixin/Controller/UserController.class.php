<?php
namespace Weixin\Controller;
use Think\Controller;
class UserController extends Controller {
    /**
     * 登录
     */
    public function login(){
        $this->display();
    }
    /**
     * 微信登录
     */
    public function wxlogin(){
        $this->display();
    }
    
    /**
     * 注册
     */
    
    public function register(){
        $this->display();
    }
    /**
     * 首页
     */
    public function index(){
        $this->display();
    }
    /**
     * 修改密码
     */
    public function editpwd(){
        $this->display();
    }
    /**
     * 忘记密码
     */
    public function wjpwd(){
        $this->display();
    }
    
    /**
     * 绑定手机
     */
    public function bdtel(){
        $this->display();
    }
    
    /**
     * 绑定邮箱
     */
    public function bdemail(){
        $this->display();
    }
    
}