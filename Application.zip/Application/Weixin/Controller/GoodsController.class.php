<?php
namespace Weixin\Controller;
use Think\Controller;
class GoodsController extends CommonController {
	
	public function _initialize() {
		parent::_initialize();
	
	}
	
	public function test(){
	
		/* var_dump($this->city);
		var_dump($_SERVER); */
		$ip = get_client_ip();
		
		$address=get_position();
		 
		$Ip = new \Org\Net\IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
		$area = $Ip->getlocation('203.34.5.66'); // 获取某个IP地址所在的位置
		
		echo $area;
		
		//echo $ip;
			
	}
	
    /**
     * 商品分类列表
     */
    public function goodslist(){
		$M_Category = M('Category');
		$categorylist = $M_Category->where('is_show=1')->select();
		$this->assign('categorylist',$categorylist);
		$this->assign('menutype',2);
        $this->display();
    }
	
    /**
     * 商品列表
     */
    public function listdot(){
    	$M_Category = M('Category');
    	$categorylist = $M_Category->where('is_show=1')->limit(1)->select();
    	
		$classid = intval(I('get.id'))?intval(I('get.id')):$categorylist['id'];
		$is_new=intval(I('get.is_new'));
        if($classid){
            $map['classid']=$classid;
        }

		if($is_new){
			$map['is_new']=$is_new;
		}

        $map['is_show']='1';

		$M_Goods = M('Goods');
		$list = $M_Goods->where($map)->order('id desc')->select();
		
		$this->assign('list',$list);
		$this->assign('menutype',2);
        $this->display();
    }

    
    /**
     * 商品详情
     */
    public function detail(){
		date_default_timezone_set('PRC');
		$id = intval(I('get.id'));
        $typeid = intval(I('get.typeid'));
		$count = 0; //总销售量  
		if($id){
			$M_Goods = M('Goods');
			$M_GoodsGuige=M('goods_guige');
			$M_Orderdetail = M('orderdetail');

			/* 商品详情 */
			$Goodsinfo = $M_Goods->where('id='.$id)->find(); 
			if($Goodsinfo['is_show']!=1){
				echo "<div style='text-align:center;padding-top: 50px;font-size:16px;font-weight:bold;'>产品已下架</div>";
				exit;
			}
            $starttime =  date('Y/m/d H:i:s',strtotime($Goodsinfo['starttime']));
            $endtime =  date('Y/m/d H:i:s',strtotime($Goodsinfo['endtime']));
			$nowtime =  date('Y/m/d H:i:s',time());
			
            $this->assign('starttime',$starttime);
            $this->assign('endtime',$endtime);
			$this->assign('nowtime',$nowtime);

            $userid = getLoginID();
     
			$collect = M('mycollect')->where(array('taskid'=>$id,'userid'=>$userid))->find();

			if($collect){
				$this->assign('collectGoods','1');
			}else{
				$this->assign('collectGoods','0');
			}

            $userinfo=M('Smember')->find($userid);
            $this->assign('userinfo',$userinfo);

			$Goodsinfo['picarr'] = explode(",",$Goodsinfo['pic1']);

			/* 商品规格列表 */
			$goods_guige=$M_GoodsGuige->where('nums!=0 and goodsid='.$id)->order('id asc')->select(); // 直接筛选有库存的

            $starttime = date('Y-m-d',time())." 00:00:00";
            $endtime = date('Y-m-d',time())." 23:59:59";
            foreach ($goods_guige as $key => $val) {
                $limit_where['pay_status']=1;
                $limit_where['userid']=$userid;
                $limit_where['goodsid']=$id;
                $limit_where['goods_guige_id']=$val['id'];
                $limit_where['paytime'] = array('between',array($starttime,$endtime));
                $num = $M_Orderdetail->where($limit_where)->count();
                $num = $num?$num:0;
                $goods_guige[$key]['guigebuy'] = $num;
            }

          



            $paycount = $M_Orderdetail->where(array('goodsid'=>$id))->count();

			$count = $paycount+$Goodsinfo['virtual']; //总销售量=虚拟销售量+已销售量 
			$Goodsinfo['pay_price'] = $Goodsinfo['price'];
			
			//编辑器内容html实体转换
			$Goodsinfo['detail']=str_ireplace('\"','"',htmlspecialchars_decode($Goodsinfo['detail']));
			
		}else{
			$Goodsinfo = array();
			$goods_guige = array();
		}
		$this->assign('Goodsinfo',$Goodsinfo);
		$this->assign('goods_guige',$goods_guige);
		$this->assign('count',$count);
		$this->assign('menutype',2);		
        $this->display();
    }
	
	public function GetTime(){
		$data['time'] =  date('Y/m/d H:i:s',time());
		echo json_encode($data);exit;
	}


//商品收藏

    public function collect(){
    	$goodsid = intval(I('get.goodsid'));
    	$userid = getLoginID();

	    if($goodsid==''||$userid==''){
            $result = array(
                'status'=>'0',
                'info'=>'缺少必要参数'
                );
            echo json_encode($result);exit;

        }

     
        $action = M('mycollect');
        $data['taskid'] = $goodsid;
        $data['userid'] = $userid;
        $data['addtime'] = date('Y-m-d H:i:s',time());


        $where['taskid'] = $goodsid;
        $where['userid'] = $userid;

        $collect = $action->where($where)->find();
        if(!$collect){
        	$arr = $action->add($data);
	        if($arr){
	        	$result = array(
	                'status'=>'1',
	                'info'=>'收藏成功'
	                );
	            echo json_encode($result);exit;
	        }

        }
 
    }


    //商品取消收藏

    public function cancercollect(){
    	$goodsid = intval(I('get.goodsid'));
    	$userid = getLoginID();
    	//$userid = 6;
	    if($goodsid==''||$userid==''){
            $result = array(
                'status'=>'0',
                'info'=>'缺少必要参数'
                );
            echo json_encode($result);exit;

        }

        $action = M('mycollect');
        $data['addtime'] = date('Y-m-d H:i:s',time());
        $where['taskid'] = $goodsid;
        $where['userid'] = $userid;
        $collect = $action->where($where)->find();
        if($collect){
        	$arr = $action->where($where)->delete();
	        if($arr){
	        	$result = array(
	                'status'=>'1',
	                'info'=>'取消成功'
	                );
	            echo json_encode($result);exit;
	        }

        }
 
    }

    
    /**
     * 专区
     */
    public function listdot2(){
 
    	$M_goods=M('Goods');
    	$typeid=intval(I('get.typeid'))?intval(I('get.typeid')):1;
    	$pic_type=M('Pic_type')->select();
    	$map['special_type']=$typeid;
    	$map['is_show']=1;
    	$list=$M_goods->where($map)->limit(8)->order('id desc')->select();
    	$count=$M_goods->where($map)->count();
    	$this->assign('pic_type',$pic_type);
    	$this->assign('typeid',$typeid);
    	$this->assign('list',$list);
    	$this->assign('count',$count);
        $this->display();
    }
    
    /* 
     * 加载更多
     */
    
    public function loadmord(){
    	
    	$num=intval(I('post.num'));
    	$typeid=intval(I('post.typeid'));
    	$M_goods=M('Goods');
    	$i=8;
    	$st = $num+$i;
    	$map['special_type']=$typeid;
    	$map['is_show']=1;
    	$list=$M_goods->where($map)->order('sequence desc')->limit($st,$i)->select();
    	$count=$M_goods->where($map)->count();
    	$con='';
    	foreach ($list as $k=>$v){
    		
    		if($k%2==1){
    			$con.='<div class="listdot_left" style="float:right;">
				        <div class="listdot_left_wz">
				        	<a href="/Weixin/Goods/detail.html?id='.$v['id'].'">
				        		<p>'.$v['goods_en_name'].'</p>
				        		<h1>'.$v['goods_name'].'</h1>
				        		<img src="'.$v['pic'].'" width="100%">
				        		<h2><span class="price">¥'.$v['price'].'</span>('.$v['kucun'].'只)</h2>
				        	</a>
				        </div>
			        </div>';
    		}else{
    			$con.='<div class="listdot_left">
				        <div class="listdot_left_wz">
				        	<a href="/Weixin/Goods/detail.html?id='.$v['id'].'">
				        		<p>'.$v['goods_en_name'].'</p>
				        		<h1>'.$v['goods_name'].'</h1>
				        		<img src="'.$v['pic'].'" width="100%">
				        		<h2><span class="price">¥'.$v['price'].'</span>('.$v['kucun'].'只)</h2>
				        	</a>
				        </div>
			        </div>';
    		}
    		
    		
    	}
    	
    	
    	$n=$st+$i;
    	
    	if($n >= $count){
    		$data['t']="1";
    		
    	}else{
    		
    		$data['t']="";
    		
    	}
    	
    	$data['st']=$st;
    	$data['con']=$con;
    	$this->ajaxReturn($data);
    	exit();
    	

    	
    	
    }
}