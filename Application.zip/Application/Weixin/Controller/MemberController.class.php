<?php
namespace Weixin\Controller;
use Think\Controller;
class MemberController extends CommonController{
	
	/**
	 * 初始化函数
	 */
	public function _initialize() {
		parent::_initialize();
	}
	
    /**
     * 我的
     */
    public function index(){
        $id = intval(I('get.id'));
        $goods_guige = M('goods_guige');
        $orderdetailtModel = M('orderdetail');
        $order_m = M('orderlist');

         if(!empty($id)){
            $info = $orderdetailtModel->where(array('orderid'=>$id))->select();
           $order =  $order_m->where(array('id'=>$id))->find();
            if($order['is_num']!=2 && $order['pay_status']==0){
                foreach ($info as $key => $vo) {
                   $result = $goods_guige->where(array('id'=>$vo['goods_guige_id']))->setInc('nums',$vo['num']);
                }
				
                $data['is_num'] = 2;
                $res = $order_m->where(array("id"=>$id))->setField($data);
           }
        
         }

    	$this->assign('menutype',4);
        $this->display();
    }
    
    /**
     * 新增收货地址页面
     */
    public function xzshdz(){
        $this->display();
    }


    /**
     * 新增收货地址信息
     */
    public function address(){
        $this->display();
    }

     /**
     * 新增收货地址信息
     */
    public function addressorder(){

        $goodsid = intval(I('get.goodsid'));
        $guigeid = I('get.guigeid');
        $type = I('get.type');


        $this->assign('goodsid',$goodsid);
        $this->assign('guigeid',$guigeid);
        $this->assign('type',$type);
 
        $this->display();
    }
    
	/* public function add_order(){

		$action=D('Orderaddress');
		$rs=$action->add_order();
		$this->ajaxReturn($rs);
        return;

	} */
    
    public function add_order(){
    	
    	$M_address=M('Orderaddress');
    	$arr['consignee']=I('post.consignee');
    	$arr['telephone']=I('post.telephone');
    	$arr['is_default']=I('post.is_default');
    	$arr['province']=I('post.province');
    	$arr['city']=I('post.city');
    	$arr['country']=I('post.county');
    	$arr['xiangqing']=I('post.xiangqing');
    	$arr['addtime']=date("Y-m-d H:i:s",time());
    	$arr['userid']=$memberid = getLoginID();

    	$map['userid']=$memberid;
    	
    	if($arr['is_default'] ==1){
    			
    		$dataPre['is_default'] = 0;
    			
    		$M_address->where($map)->field('is_default')->save($dataPre);
    			
    	}

    	$re=$M_address->where($map)->add($arr);
    	if($re){
    			
    		$data['re']=1;
    		$data['msg']="操作成功！";
    	}else{
    		$data['re']=0;
    		$data['msg']="操作失败！";
    	}
    	
    	$this->ajaxReturn($data);
    	exit();
    	
    }
	
	public function edit_address(){
		
		$M_address=M('Orderaddress');
		$userid = getLoginID();
		$id=intval(I('post.id'));
		$data['consignee']=I('post.consignee');
		$data['telephone']=I('post.telephone');
		$data['is_default']=I('post.is_default');
		$data['province']=I('post.province');
		$data['city']=I('post.city');
		$data['country']=I('post.county'); 
        $data['id'] = $id;

		$data['xiangqing']=I('post.xiangqing');
        $where['is_default'] = 1; 
        $where['userid'] = $userid; 
        if($data['is_default']==1){
            $defaultaddress = $M_address->where($where)->find();
            if($defaultaddress['id']!=$id){
                if($defaultaddress){
                    $M_address->where(array('id'=>$defaultaddress['id']))->setField('is_default','0');
                }
            } 
        }

        $result=$M_address->save($data);
		if($result){
			$arry['re']=1;
			$arry['msg']="修改信息成功！";
		}else{
			$arry['re']=0;
			$arry['msg']="修改信息失败！";
		}
		
		echo json_encode($arry);exit;
		
	}


    public function add_order1(){

        $action=D('Orderaddress');
        $rs=$action->add_order();

        echo json_encode($rs);exit;

    }


	
    /**
     * 选择城市
     */
    public function address1(){
        $this->display();
    }
    
    /**
     * 地址列表
     */
    
    public function addresslist(){
		$memberid = getLoginID();
        $where['userid'] = $memberid;
        $address = M('orderaddress')->where($where)->order('is_default desc')->select();
        $this->assign('address',$address);
        $this->display();
    }


     /**
     * 地址列表
     */
    
    public function addresslist1(){
    	
        $memberid = getLoginID();

        $goodsid = I('get.goodsid');
        $guigeid = I('get.guigeid');
        $type = I('get.type');


        $where['userid'] = $memberid;
        $address = M('orderaddress')->where($where)->select();
        $this->assign('address',$address);
        $this->assign('goodsid',$goodsid);
        $this->assign('guigeid',$guigeid);
        $this->assign('type',$type);
        $this->display();
    }

    
    /**
     * 修改地址
     */
    public function editaddress(){
        $id = intval(I('get.id'));
        if($id){
        	$map['id']=$id;
        	$map['userid']=getLoginID();
            $address = M('orderaddress')->where($map)->find();
        }
  
        $this->assign('address',$address);
        $this->display();
    }




    /**
     * 购买时修改地址
     */
    public function editaddress1(){
        $id = intval(I('get.id'));

        $goodsid = I('get.goodsid');
        $guigeid = I('get.guigeid');
        $type = I('get.type');

        if($id){
            $map['id']=$id;
            $map['userid']=getLoginID();
            $address = M('orderaddress')->where($map)->find();
        }
  
        $this->assign('address',$address);

        $this->assign('goodsid',$goodsid);
        $this->assign('guigeid',$guigeid);
        $this->assign('type',$type);

        $this->display();
    }


    public function edit_address1(){
        
        $M_address=M('Orderaddress');
        $userid = getLoginID();
        $id=intval(I('post.id'));

      

        $data['consignee']=I('post.consignee');
        $data['telephone']=I('post.telephone');
        $data['is_default']=I('post.is_default');
        $data['province']=I('post.province');
        $data['city']=I('post.city');
        $data['country']=I('post.county'); 
        $data['id'] = $id;

        $data['xiangqing']=I('post.xiangqing');
        $where['is_default'] = 1; 
        $where['userid'] = $userid; 
        if($data['is_default']==1){
            $defaultaddress = $M_address->where($where)->find();
            if($defaultaddress['id']!=$id){
                if($defaultaddress){
                    $M_address->where(array('id'=>$defaultaddress['id']))->setField('is_default','0');
                }
            } 
        }

        $result=$M_address->save($data);
        if($result){
            $arry['re']=1;
            $arry['msg']="修改信息成功！";
        }else{
            $arry['re']=0;
            $arry['msg']="修改信息失败！";
        }
        
        echo json_encode($arry);exit;
        
    }



	
    /**
     * 删除地址
     */
    public function delete_ress(){
		
        if(IS_POST){
            $user_id = getLoginID();
            $id = intval(I('post.id'));
            if($user_id && $id){
                $result=M("orderaddress")->where("id = %d and userid={$user_id}",$id)->delete();
                if($result){
                    echo 1;
                }else{
                    echo 0;
                }
                
            }
        }
    }	
    
    //设默认地址
    public function default_address(){
    	
    	$M_address=M('Orderaddress');
    	
    	if(IS_POST){
    		
    		$user_id=getLoginID();
    		
    		$id=intval(I('post.id'));
    		
    		if($user_id && $id){
    			
    			$map['userid']=$user_id;
    			
    			$dataPre['is_default'] = 0;
    				
    			$M_address->where($map)->field('is_default')->save($dataPre);
    			
    			$map['id']=$id;
    			$res=$M_address-> where($map)->setField('is_default','1');
    			
    			if($res){
    				
    				$data['re']=1;
    				$data['msg']="操作成功！";
    				
    			}else{
    				
    				$data['re']=0;
    				$data['msg']="操作失败！";
    			}
    		
    			$this->ajaxReturn($data);
    			exit();
    		}
    	}
    }
	
    
    /**
     * 会员卡页面
     */
    public function hyk(){
        $this->display();
    }
    
    /**
     * 会员卡绑定手机号
     */
    
    public function hyk1(){
        $this->display();
    }
    
    /**
     * 会员卡绑定成功
     */
    public function hyk2(){
        $this->display();
    }
    
    /**
     * 积分兑换列表
     */
    public function jifen(){
    	
    	$list=M('Jifen_goods')->where(array('is_show'=>1))->select();
    	$this->assign('list',$list);
    	$this->assign('menutype',4);
        $this->display();
    }
	
	
    /**
     * 积分兑换详情
     */
    public function jifendetail(){
		$id = intval(I('get.id'));
		if($id){
			$M_Goods = M('Jifen_goods');


			/* 商品详情 */
			$Goodsinfo = $M_Goods->where('id='.$id)->find(); 
			//print_r($Goodsinfo);
            $userid = getLoginID();

            $userinfo=M('Smember')->find($userid);
            $this->assign('userinfo',$userinfo);

			$Goodsinfo['picarr'] = explode(",",$Goodsinfo['pic1']);
			
			$Goodsinfo['pay_price'] = $Goodsinfo['price'];
			
			//编辑器内容html实体转换
			$Goodsinfo['detail']=str_ireplace('\"','"',htmlspecialchars_decode($Goodsinfo['detail']));
			
		}else{
			$Goodsinfo = array();
			$goods_guige = array();
		}
	
		$this->assign('Goodsinfo',$Goodsinfo);
		$this->assign('menutype',2);		
        $this->display();
    }
	
	

    /**
     * 签到
    */
    public function sign(){

        $user_id=getLoginID();
        $userinfo=D('smember')->where(array('id'=>$user_id))->field('signnum,integral')->find();
        # 连续签到天数对7取余
        $time = date('Y年m月d日');
    
        # 判断用户是否已签到
        $end_date=D('smember')->where(array('id'=>$user_id))->getField('endsigntime');
        $end_date=date('Y-m-d',strtotime($end_date)); //最后签到时间
        $now_date = date("Y-m-d",time());    //当前时间
        if ($now_date==$end_date) {
            $is_sign=1;
            $now_date=date('Y-m-d',time());
            $jindou=D('Signlog')->order('id desc')->where(array('addtime'=>$now_date))->getField('integral_num');
        }else{
            $is_sign=0; 
 
        }

        # 用户签到日期数组
        $userDate=D('Signlog')->where(array('userid'=>$user_id))->select();
        # 当前月份
        $month=date('m',time());
        $dayArr=array();
        foreach ($userDate as $v) {
            $userMonth=date('m',strtotime($v['addtime']));
            if ($month==$userMonth) {
                $day=date('d',strtotime($v['addtime']));
                $dayArr[]=$day-1;
            }
        }

        $this->assign('is_sign',$is_sign);
        $this->assign('dayArr',json_encode($dayArr));
        $this->assign('time',$time);
        $this->assign('userinfo',$userinfo);
        $this->display(); 
  
    }


    public function getsign(){
        if(IS_AJAX){
            $userid = getLoginID();
            $integral = M('sign_config')->getField('value');
            if($userid!=''){
                $userinfo=D('smember')->where(array('id'=>$userid))->find();
                if($userinfo['endsigntime']){
                    $end_date=date('Y-m-d',strtotime('+1 day '.$userinfo['endsigntime'])); //最后签到时间的后一天   
                }else{
                    $end_date = date("Y-m-d",time());    //未签到
                }
                $now_date = date("Y-m-d",time());    //当前时间

                if($end_date==$now_date){
                    $signnum = $userinfo['signnum']+1;
                    $integral = $integral;
                }elseif ($end_date<$now_date) {
                   $signnum = 1;
                   $integral = $integral;
                }else{
                    # 已签到
                    $return=array(
                        'status'=>'0',
                        'info'=>'今天已经签过到了'
                        );
                    $this->ajaxReturn($return);exit;

                }

                $signData=array(
                    'userid'=>$userid,
                    'operation'=>'签到',
                    'before_integral'=>$userinfo['integral'],
                    'integral_num'=>$integral,
                    'now_integral'=>$userinfo['integral']+$integral,
                    'addtime'=>date('Y-m-d H:i:s',time()),
                    );

                $res = M('signlog')->add($signData);
                $D = date('d',time());
                if($res){
                    $data=array(
                        'integral'=>$userinfo['integral']+$integral,
                        'signnum'=>$signnum,
                        'endsigntime'=>date('Y-m-d H:i:s',time()),
                    );

                    M('smember')->where(array('id'=>$userid))->save($data);
                    $result = array(
                        'status'=>'1',
                        'info'=>'签到成功',
                        'today'=>$D,
                        'signnum'=>$signnum,
                        'integral'=>$userinfo['integral']+$integral
                    );
                    echo json_encode($result);exit;


                }else{
                     $result = array(
                        'status'=>'0',
                        'info'=>'签到失败'
                    );
                    echo json_encode($result);exit;
                }
            }

        }

        $this->display();  
    }
    
 
    
    /**
     * 积分规则
     */
    public function jifengz(){
    	$this->assign('menutype',4);
        $this->display();
    }
    
    /**
     * 联系卖家
     */
    public function lxmj(){
        $info = M('conquestion')->where(array('type'=>'0'))->find();
        $this->assign('info',$info);
        $this->assign('menutype',4);
        $this->display();
    }
    /**
     * 售后
     */
    public function shouhou(){
        $info = M('conquestion')->where(array('type'=>'1'))->find();
        $this->assign('info',$info);
        $this->assign('menutype',4);
        $this->display();
    }








    
    
    /**
     * 收藏
     */
    public function sc(){
        $user_id = getLoginID();
        //$user_id = '21';
        $where['userid'] = $user_id;
        $sc = M('mycollect')->where($where)->order('addtime desc')->select();
        if($sc){
            foreach ($sc as $k => $vo) {
                $scgoods[$k] = M('goods')->where(array('id'=>$vo['taskid']))->find();
            }

        }
        
        $this->assign('scgoods',$scgoods);
        $this->display();
    }
    
    /**
     * 收货地址
     */
    public function shdz(){
        $this->display();
    }
    
    /**
     * 特权
     */
    public function tequan(){
        $this->display();
    }
    /**
     * 现金券
     */
    public function xjq(){
        $this->display();
    }
    
    /**
     * 优惠券
     */
    
    public function yhq(){
        $this->display();
    }
    
    /**
     * 资料修改
     */
    public function zlxg(){

		$memberid = getLoginID();
		
		$info=M('Smember')->find($memberid);
		$this->assign('info',$info);
		$this->assign('menutype',4);
        $this->display();
    }
	
	
	
	public function info_save(){
		
		$memberid 		= getLoginID();
		$action 		= 'FindIdentityNo';
		$realname		= I('post.realname');
		$telephone		= I('post.telephone');
		$card 			= I('post.card_id');
		$cardnumber 	= I('post.cardnumber');
		$service_status = 0;
		$card_status 	= 0;
		
		if(empty($memberid)){
			$arrys = array(
				'status'=>0,
				'msg'=>'缺少必要参数'
				);
			echo json_encode($arrys);exit;
		}

		$memberinfo = M('Smember')->where(array('id'=>$memberid))->field('cardnumber,card_id,vip')->find();
		
		
		if($memberinfo['cardnumber'] != $cardnumber && $cardnumber!=""){
			
			$status = M('card')->where(array('card'=>$cardnumber))->find();
			
			if(empty($status)){
				$arrys = array(
					'status'=>0,
					'msg'=>'该5.1服务卡不存在'
				);
				echo json_encode($arrys);exit;	
			}
			
			if($status['status']==1){
				$arrys = array(
					'status'=>0,
					'msg'=>'该5.1服务卡已绑定'
				);
				echo json_encode($arrys);exit;
			}
			/* 5.1卡号可用 */
			$service_status = 1;
			
		}
		
		
		if($cardnumber == ""){
			$service_status = 2;
		}
		
			
		
		
		if($memberinfo['card_id'] != $card && $card != ""){

			
			$stauts1 = M('Smember')->where(array('card_id'=>$card))->find();
			/* 身份证已存在 */
			if(!empty($stauts1)){
				$arrys = array(
					'status'=>0,
					'msg'=>'该身份证已存在'
				);
				echo json_encode($arrys);exit;
			}
			
			$zhuangtai = sqlserver($action,$card,'','','','');
			/* 存在该员工 */
			if($zhuangtai){
				$card_status = 1;	
			}else{
				$card_status = 2;
			}
			
		}
		if($card != ""){
			$card_status = 2;
		}
		
		/* 服务卡，员工身份判断 $data['vip'] */
		if($memberinfo['vip'] == 0){
			
			if($service_status == 1 && $card_status==1){
				$data['vip'] = 3;
			}
			
			if($service_status == 1 && ($card_status==0 || $card_status==2)){
				$data['vip'] = 2;
			}
			
			if($card_status == 1 && ($service_status==0 || $service_status==2)){
				$data['vip'] = 1;
			}	
		}
		
		if($memberinfo['vip'] == 1){
			
			if($service_status == 1 && ($card_status==1 || $card_status==0)){
				$data['vip'] = 3;
			}
			
			if($service_status == 1 && $card_status==2){
				$data['vip'] = 2;
			}
			
			if($card_status == 1 && ($service_status==0 || $service_status==2)){
				$data['vip'] = 1;
			}	
			
			if($service_status == 2 && $card_status==2){
				$data['vip'] = 0;
			}
			
		}
		
		if($memberinfo['vip'] == 2){
			
			if($card_status == 1 && ($service_status==1 || $service_status==0)){
				$data['vip'] = 3;
			}
			
			if($card_status == 1 && $service_status==2){
				$data['vip'] = 1;
			}
			
			if($service_status == 1 && ($card_status==0 || $card_status==2)){
				$data['vip'] = 2;
			}	
			
			if($card_status == 2 && $service_status==2){
				$data['vip'] = 0;
			}
			
		}
		
		if($memberinfo['vip'] == 3){
			
			if(($card_status == 1 || $card_status==0) && ($service_status==1 || $service_status==0)){
				$data['vip'] = 3;
			}
			
			if($card_status == 1 && $service_status==2){
				$data['vip'] = 1;
			}
			
			if($service_status == 1 && $card_status == 2){
				$data['vip'] = 2;
			}	
			
			if($card_status == 2 && $service_status==2){
				$data['vip'] = 0;
			}
			
		}
		/* 服务卡，员工身份判断 $data['vip'] END */
		
		if($service_status == 2 || $service_status == 1){
			if($memberinfo['vip']>=2){
				M('card')->where(array('card'=>$memberinfo['cardnumber']))->save(array('status'=>0,'userid'=>''));
			}
		}
		
		if($service_status == 1){
			M('card')->where(array('card'=>$cardnumber))->save(array('status'=>1,'userid'=>$memberid));
		}
		
		
		
		$data['realname']   = $realname;
		$data['telephone']  = $telephone;
		$data['card_id']    = $card;
		$data['cardnumber'] = $cardnumber;

		$res = M('Smember')->where(array('id'=>$memberid))->save($data);
		$arrys = array(
			'status'=>0,
			'msg'=>'信息更新成功'
			);
		echo json_encode($arrys);exit;	
		
        
    }
	
	
	public function ceshi(){
		$card	   = "330282198612152223";
		$action    = 'FindIdentityNo';
		$zhuantai = sqlserver($action,$card,'','','','');
		
		var_dump($zhuantai);
		
	}
    

    
    
    
    
}