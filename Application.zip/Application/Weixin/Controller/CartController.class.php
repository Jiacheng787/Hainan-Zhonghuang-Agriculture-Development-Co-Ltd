<?php
namespace Weixin\Controller;
use Think\Controller;
class CartController extends CommonController {
    /**
     * 购物车首页
     */
    public function index(){

    	$action = M('cart');
    	$userid = getLoginID();
        $M_Orderdetail = M('orderdetail');
        $map['userid'] = $userid;


        $cart_goods = $action->where($map)->order('id desc')->select();
        $count = 0;
        $order_price = 0;
        foreach ($cart_goods as $key => $value) {
            $count+=$value['num'];
            $goods = M('goods')->where('id='.$value['goodsid'])->field('pic,good_name')->find();
            $goods['price'] = getPrice($value['goodsid'],$userid);     
            $guige = M('goods_guige')->where('id='.$value['guigeid'])->find();
            $cart_goods[$key]['total_price'] = $goods['price']*$value['num'];
            $order_price += $goods['price']*$value['num'];
            $cart_goods[$key]['price'] = $goods['price'];
            $cart_goods[$key]['cartid'] = $value['id'];
            $cart_goods[$key]['pic'] = $goods['pic'];
            $cart_goods[$key]['good_name'] = $goods['good_name'];
            $cart_goods[$key]['kucun'] = $guige['nums']; 
            $cart_goods[$key]['is_limit'] = $guige['is_limit']?$guige['is_limit']:''; 
            $cart_goods[$key]['num_limit'] = $guige['num_limit']?$guige['num_limit']:''; 

            $limit_where['pay_status']=1;
            $limit_where['userid']=$userid;
            $limit_where['goodsid']=$value['goodsid'];
            $limit_where['goods_guige_id']=$value['guigeid'];
            $havepay = $M_Orderdetail->where($limit_where)->count();
            $havepay = $havepay?$havepay:0;
            $cart_goods[$key]['havepay'] = $havepay; 
        }


        $nums=count($cart_goods);
        $this->assign('nums',$nums);
        $this->assign('count',$count);
        $this->assign('order_price',$order_price);
        $this->assign('cart_goods',$cart_goods);
        $this->assign('img_url',IMG_URL);
		$this->assign('menutype',3);
        
        $this->display();
    }



    /**
     * 加入购物车
    */

    public function shopcart(){
        if(IS_AJAX){
            $action = M('cart');
         	$userid = getLoginID();
            $map['userid'] = $userid;
            $M_Orderdetail = M('orderdetail');
            if($userid==''){
                $arrys = array('status'=>1,'info'=>'请登录');
                echo json_encode($arrys);exit;
            }else{
                $proid=intval(I('get.proId'));
                $num=intval(I('get.num'));
                $guigeid=intval(I('get.guigeid'));
                $special_type=intval(I('get.special_type'));
                $vip = M('Smember')->where(array('id'=>$userid))->getField('vip');

                
                if($special_type==1){
                  if($vip!=1&&$vip!=3){
                    $arrys = array('status'=>0,'info'=>'员工才能购买');
                    echo json_encode($arrys);exit;
                 
                  }
                }

                if($special_type==2){
                  if($vip!=2&&$vip!=3){
                    $arrys = array('status'=>0,'info'=>'5.1服务卡会员才能购买');
                    echo json_encode($arrys);exit;
                  }
                }

               
                $cart = $action->where(array('userid'=>$userid,'goodsid'=>$proid,'guigeid'=>$guigeid))->find();

              
                $glimit=M('goods_guige')->where(array('goodsid'=>$proid,'id'=>$guigeid))->find();//限购数量

                $starttime = date('Y-m-d',time())." 00:00:00";
                $endtime = date('Y-m-d',time())." 23:59:59"; 
                $limit_where['pay_status']=1;
                $limit_where['userid']=$userid;
                $limit_where['goods_id']=$proid;
                $limit_where['goods_guige_id']=$guigeid;
                $limit_where['paytime'] = array('between',array($starttime,$endtime));
                $paynum = $action->where($limit_where)->count();
                $paynum = $paynum?$paynum:0;
                $allnum=$paynum+$cart['num'];
               
                if($glimit['num_limit']!="0" && $glimit['num_limit']!=""){

                    if($allnum > $glimit['num_limit']){
                        $arrys = array('status'=>4,'info'=>'活动商品每个ID仅限购买'.$glimit['num_limit'].'件');
                        echo json_encode($arrys);exit;
                   }

                }
                

                if($cart){
                    $data['num']=$cart['num']+$num;

                    $res =  $action->where(array('id'=>$cart['id']))->save($data);
                }else{
                    $data['num'] = $num;
                    $data['goodsid'] = $proid;
                    $data['userid'] = $userid;
                    $data['guigeid'] = $guigeid;
                    $data['addtime'] = date('Y-m-d H:i:s',time());
                    $res =  $action->add($data);
                }
                 

                $cartnum = $action->where($map)->field('num')->select();

                $number = 0;
                foreach ($cartnum as $key => $val) {
                    $number +=  $val['num'];
                }

                if($res){
                    $arrys = array('status'=>2,'number'=>$number,'info'=>'已加入购物车');
                    echo json_encode($arrys);exit;
                }else{
                    $arrys = array('status'=>3,'info'=>'加入购物车失败');
                    echo json_encode($arrys);exit;
                }

            }

        }
    }




    //购物车商品数量添加
    public function addnum(){
    	if(IS_AJAX){
    		$action = M('cart');
	        $id = intval(I('post.id'));
	        $data=$action->where("id=%d",array($id))->find();
	        $re=$action->where("id=%d",array($id))->setField('num',$data['num']+1);
	        if($re){
	        	$result = array(
	        		'status'=>1
	        		);
	        	echo json_encode($result);exit;
	            
	         }

    	}
       
       
    }

    // 购物车数量减少
    public function reduce(){
    	if(IS_AJAX){
            $action = M('cart');
	        $id = intval(I('post.id'));
	        $data=$action->where("id=%d",array($id))->find();
	        if($data['num']>1){
	            $re=$action->where("id=%d",array($id))->setField('num',$data['num']-1);
	            if($re){
	                $result = array(
	                	'status'=>1
	                	);
	                  echo json_encode($result);exit;
	            }
	        }else{
	            $result = array(
	                	'status'=>0
	                	);
	            echo json_encode($result);exit;
	           
	        }

	       

    	}
        
  
    }


    //删除购物车

    public function delcart(){
        if(IS_AJAX){
            $id = intval(I('get.id'));
            if($id==''){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少必要参数'
                    );
                echo json_encode($result);exit;

            }
            
            $memberid=getLoginID();
            
            $del = M('cart')->where(array('id'=>$id))->delete();
            $count=M('cart')->where(array('userid'=>$memberid))->count();
            
            if($del){
            	
            	if($count==0){
            		
            		$result = array(
            				're'=>0,
            				'status'=>'1',
            				'info'=>'删除成功'
            		);
            		
            	}else {
            		
            		$result = array(
            				're'=>1,
            				'status'=>'1',
            				'info'=>'删除成功'
            		);
            		
            	}
                
                echo json_encode($result);exit;

            }else{

                $result = array(
                    'status'=>'2',
                    'info'=>'删除失败'
                    );
                echo json_encode($result);exit;

            }


        }


    }



     /**
     * 计算付款总价
     */

    public function allPayPrice(){
        $M_cart=M('Cart');
        $allprice=0;
    	$userid = getLoginID();
       
        $cart = $M_cart->where(array('userid'=>$userid))->select();
        $nums = 0;
        foreach ($cart as $key => $v) {
            $goodprice = getPrice($v['goodsid'],$userid);  
            $allprice+=$goodprice*$v['num'];  
            $nums+=$v['num'];  
        }

        $result = array(
        	'status'=>1,
        	'allprice'=>$allprice,
            'nums'=>$nums
        	);
        echo json_encode($result);exit;
      
        
     
    }













}