<?php
namespace Weixin\Controller;
use Think\Controller;
class OrderController extends CommonController{

	/**
	 * 初始化函数
	*/
	public function _initialize() {
		parent::_initialize();

	}
	

    /**
     * 全部订单
     */
    public function orderlist(){
        $memberid = getLoginID();
        $map['userid'] =  $memberid;
        $map['is_delete'] = '0';
        $action=D('orderlist');
        $detail = M('orderdetail');

        $orders = $action->where($map)->field('id,orderstate,orderno,total_price,confirmtime,confirm_status')->order('addtime desc')->select();
        if($orders){
            foreach ($orders as $key => $vo) {
                $goods = $detail->where(array('orderid'=>$vo['id']))->field('img,goodsname,num,good_nowprice,img')->select();
                $orders[$key]['count'] = M('order_message')->where(array('orderid'=>$vo['id'],'status'=>0))->count();
                $orders[$key]['goods'] = $goods[0];
                if($vo['confirm_status']==1){
                	$returntime = strtotime($vo['confirmtime'])+7*24*3600;
                	 
                	if($returntime<time()){
                		$return = 0;
                	}else{
                		$return = 1;
                	}

                	$this->assign('return',$return);
                }
            }

        }

        $this->assign('orders', $orders);
        $this->assign('menutype',4);
        $this->display();


    }


    /**
     * 待付款
     */
    public function waitpay(){
        $orderno=I('get.orderno');
        if($orderno!=''){
            $ordernos=$orderno;
        }
        $memberid = getLoginID();
        $action=D('orderlist');
        $detail = M('orderdetail');
        $orders = $action->where(array('userid'=>$memberid,'orderstate'=>'1','is_delete'=>0))->field('id,orderstate,orderno,total_price')->order('addtime desc')->select();
        if($orders){
            foreach ($orders as $key => $vo) {
                $goods = $detail->where(array('orderid'=>$vo['id']))->field('img,goodsname,num,good_nowprice,img')->select();
                $orders[$key]['goods'] = $goods[0];
            }
        }

        $this->assign('allorder', $Allorder);
        $this->assign('orders', $orders);
        $this->assign('menutype',4);
        $this->display();
    }



    /*
    *订单取消
    */

    public function cancelOrder(){
        if(IS_AJAX){
            $id  = I('post.id');
            if(empty($id)){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少参数'
                    );
                echo json_encode($result);exit;
            }

            $where['id'] = $id;
            $res = M('orderlist')->where($where)->setField('orderstate','6');
            if($res){
                $result = array(
                    'status'=>'1',
                    'info'=>'订单取消成功'
                    );
                echo json_encode($result);exit;
            }
        }

    }


    /*
    *订单删除
    */

    public function delOrder(){

        if(IS_AJAX){
            $id  = I('post.id');
            $ordertype  = I('post.ordertype');
            if(empty($id)){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少必要参数'
                    );
                echo json_encode($result);exit;
            }

            $where['id'] = $id;
            if($ordertype==1){
                $res = M('orderlist')->where($where)->setField('is_delete','1');
            }elseif($ordertype==2){
                $res = M('jifen_order')->where($where)->setField('is_delete','1');
            }
            
            if($res){
                $result = array(
                    'status'=>'1',
                    'info'=>'订单删除成功'
                    );
                echo json_encode($result);exit;
            }
        }
    }


    /*
    *普通订单确认收货
    */

    public function confirmOrder(){

        if(IS_AJAX){
            $id  = I('post.id');
            if(empty($id)){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少参数'
                    );
                echo json_encode($result);exit;
            }

            $time = date('Y-m-d H:i:s',time());

            $where['id'] = $id;
            $data['orderstate'] = '4';
            $data['confirm_status'] = '1';
            $data['confirmtime'] = $time;
            $res = M('orderlist')->where($where)->setField($data);
            if($res){
                $result = array(
                    'status'=>'1',
                    'info'=>'确认收货成功'
                    );
                echo json_encode($result);exit;
            }
        }
    }


    /*
    *积分订单确认收货
    */

     public function jifenconfirm(){

        if(IS_AJAX){
            $id  = I('post.id');
            if(empty($id)){
                $result = array(
                    'status'=>'0',
                    'info'=>'缺少必要参数'
                    );
                echo json_encode($result);exit;
            }

            $time = date('Y-m-d H:i:s',time());

            $where['id'] = $id;
            $data['orderstate'] = '3';
            $data['confirm_status'] = '1';
            $data['confirmtime'] = $time;
            $res = M('jifen_order')->where($where)->setField($data);
            if($res){
                $result = array(
                    'status'=>'1',
                    'info'=>'确认收货成功'
                    );
                echo json_encode($result);exit;
            }
        }
    }





/*
    *商品评价
    */

    public function evaluate(){
    	
    	$id  = I('get.id');
    	$con=M('orderdetail')->where(array('id'=>$id))->find();
    	  
		
    	if(IS_AJAX){  
    	$userid =  getLoginID();    	 	
    	$data['content']  = I('post.content');
    	$ids = I('post.detailid'); 
    	$cons=M('orderdetail')->where(array('id'=>$ids))->find();  
    	$data['goodsid']  = $cons["goodsid"];
    	$data['orderid']  = $cons["orderid"];
    	$data['detailid'] = $ids;
    	
  		$num=M('evaluate')->where(array('userid'=>$userid,'detailid'=>$ids))->count(); 
	  		if($num=="0" || $num==""){  		
	  			$data['addtime']  = date('Y-m-d H:i:s',time()); 
	  			$data['userid'] = $userid; 
	    		$res=M('evaluate') -> add($data);
		    		if($res){
		                $result = array(
		                'status'=>'1',
		                'info'=>'提交评价成功'
		                );
		                echo json_encode($result);exit;
		           		 }
	    	}else{
				$result = array(
	            'status'=>'0',
	            'info'=>'您已评价过！'
	            );
	       		 echo json_encode($result);exit;
	  		}   
    	
    	}
 	    $this->assign('details', $con);
        $this->display();

    }



    /*
    *退货
    */

    public function refund(){
    	$reason = M('return_reason')->select();

    	$id = intval(I('get.id'));
    	$orderlist = M('orderlist')->where(array('id'=>$id))->find();

       // dump($orderlist);
    	$orderdetail = M('orderdetail')->where(array('orderid'=>$id))->select();
 
        $number = 0;
    	foreach ($orderdetail as $key => $vo) {
    		$number +=$vo['num'];
    	}

        $this->assign('orderlist',$orderlist);
        $this->assign('number',$number);
        $this->assign('orderdetail',$orderdetail);
        $this->assign('reason',$reason);
        $this->display();

    }



    public function returnconfirm(){
    	if(IS_AJAX){
    		$id = intval(I('post.id'));
    		$pay_fee = M('orderlist')->where(array('id'=>$id))->getField('pay_fee');

    		if($id!=''){
    			$data['is_refund'] = '1';
    			$data['refund_fee']= $pay_fee ;
    			$data['reason_id']= I('post.reason_id');
    			$data['return_content']= I('post.r_content');
    			$data['orderstate']= '5';
    			$data['refundtime']= date('Y-m-d,H:i:s',time());
    			$res = M('orderlist')->where(array('id'=>$id))->setField($data);
    			if($res){
    				$result = array(
    					'status'=>1,
    					'info'=>'退款申请成功'
    					);

    			}else{
    				$result = array(
    					'status'=>0,
    					'info'=>'申请退款失败'
    					);
    			}
                echo json_encode($result);exit;

    		}
    	}


    }



    /**
     * 待收货
     */
    public function waitsh(){
        $map['orderstate'] = array('in','3');
        $memberid = getLoginID();
        $map['userid'] =  $memberid;
        $map['is_delete'] = '0';

        $action=D('orderlist');
        $detail = M('orderdetail');
        $orders = $action->where($map)->field('id,orderstate,orderno,total_price')->order('addtime desc')->select();
        if($orders){
            foreach ($orders as $key => $vo) {
                $orders[$key]['count'] = M('order_message')->where(array('orderid'=>$vo['id'],'status'=>0))->count();
                $goods = $detail->where(array('orderid'=>$vo['id']))->field('img,goodsname,num,good_nowprice,img')->select();
                $orders[$key]['goods'] = $goods[0];
            }

        }

    
        $this->assign('allorder', $Allorder);
        $this->assign('orders', $orders);
        $this->assign('menutype',4);
        $this->display();
    }



    
    public function addOrder(){
        if(IS_AJAX){
            $id_arr= I('post.id');
            $arr = array();
            $arr = explode('_',$id_arr);
            $data = array_filter($arr);
            $_SESSION['order']=$data;
            $arrys = array('status'=>1);
            echo json_encode($arrys);exit;
        }
    }


    
    /* 
     *订单详情 
     *  
     */
    public function order_detail(){
    
    	$id=intval(I('get.id'));
    	$memberid = getLoginID();
    	$map['userid']=$memberid;
    	$map['id']=$id;
    	
    	$info=M('orderlist')->where($map)->find();
        $message = M('order_message')->where(array('orderid'=>$id))->find();
        $message['message'] = str_ireplace('\"','"',htmlspecialchars_decode($message['message']));

        $re = M('order_message')->where(array('orderid'=>$id))->setField('status',1);

    	if(!$info){
    		echo '<script> alert("参数错误");window.history.back(-1);</script>';
    		exit();
    	}    	
    	$map1['orderid']=$info['id'];
    	$goods_list=M('Orderdetail')->where($map1)->select();

    	foreach ($goods_list as $key => $value) {
    		$pin = M('evaluate')->where(array('userid'=>$memberid,'detailid'=>$value['id']))->count();
    		if($pin>0){
                $goods_list[$key]['can'] = 1;
    		}else{
    			$goods_list[$key]['can'] = 0;

    		}

    	}
    	$info['reason_con']=M('return_reason')->where(array('id'=>$info['reason_id']))->find();    	
    	$this->assign('info',$info);
        $this->assign('message',$message);
    	$this->assign('goods_list',$goods_list);
    	$this->assign('menutype',4);
    	$this->display();
    }
    
    
	/* 
	 *确认兑换 
	 *首先判断用户积分是否足够
	 *
	 *
	 *
	 */
	public function qrdh(){

		$goodsid=intval(I('get.goodsid'));
		$M_Orderaddress = M('Orderaddress');
		$M_Goods = M('Jifen_goods');
        $memberid = getLoginID();
		
      
		/* 判断参数 */
		if($goodsid==0 ){
			$this->redirect("/Weixin/Member/jifen"); //直接跳转，不带计时后跳转
		}
		
		$Goodsinfo = $M_Goods->where('id='.$goodsid)->find();
		
	

		$member_info=M('Smember')->find($memberid);
		
		
		$is_default = 0; //是否存在默认地址 1.存在		
		

		if(intval(I('get.adressid'))){
			
			$where['id']=I('get.adressid');
			
		}else{
			
			$where['userid']=$memberid;
			$where['is_default']=1;
		}
		
		/* 默认地址 */
		$Orderaddress = $M_Orderaddress->where($where)->find();

		if (!$Orderaddress) {
			# 没有默认地址选择最新添加的作为收货地址
			$Orderaddress = $M_Orderaddress->where(array('userid'=>$memberid))->order('addtime desc')->find();
		}
		
		if(!empty($Orderaddress)){
			$is_default = 1;
		}

		$this->assign('Goodsinfo',$Goodsinfo);
		$this->assign('type','3');
		$this->assign('Orderaddress',$Orderaddress);
		$this->assign('is_default',$is_default);
		$this->display();
	}

	/* 
	 *数量增加时是否积分足够 
	 *  
	 */
	public function exchange(){
		
		$goodsid=intval(I('post.goodsid'));
		$nums=intval(I('post.nums'));
		$map['id']=$goodsid;
		$integral=M('Jifen_goods')->where($map)->getField('integral');
		$total_integral=$nums*$integral;

		$memberid = getLoginID();
		
		$member_info=M('Smember')->find($memberid);
		
		if($member_info['integral'] < $total_integral){
				
			$data['re']="0";
			$data['info']="您的积分不够！";
			
		}else{
			
			$data['re']="1";
			$data['integral']=$total_integral;
		}
		
		$this->ajaxReturn($data);
		exit();
		
	}
	
	/* 
	 * 积分购买
	 * 先判断积分是否足够 
	 */
	public function exchange_order() {

		$memberid = getLoginID();
		$order['userid'] = $memberid;
		$order['goodsid'] = intval(I('post.goodsid'));
		$nums = intval(I('post.nums')); //商品数量
		$addressID = intval(I("post.addressID")); //收货地址id
		
		$member_info=M('Smember')->find($memberid);
		$map['id']=$goodsid;
		$integral=M('Jifen_goods')->where($map)->getField('integral');
		$total_integral=$nums*$integral;
		
		if($member_info['integral'] < $total_integral){

			$return['msg']="您的积分不够！";
			
			$this->ajaxReturn($return);
			exit;
		}
			
		
		
		/* 收货地址 */
		if(!$addressID){
			
			$return['msg'] = '收货地址不能为空';
			$this->ajaxReturn($return);
			exit;
		}
		
		$M_Order = M('Jifen_order');
		$M_Goods = M('Jifen_goods');
		$M_Orderaddress = M('Orderaddress');
		
		$Goodsinfo = $M_Goods->where('id='.$order['goodsid'])->find();
		$Orderaddressinfo = $M_Orderaddress->where('id='.$addressID)->find();

		/* 是否下架 */
		if($Goodsinfo['is_show']=0){
			$return['status'] = 0;
			$return['msg'] = '已下架罄';
			$this->ajaxReturn($return);
			exit;
		}
		
		$pay_integral =$nums* intval($Goodsinfo['integral']); //所需积分
		
		$order['orderno'] = date('YmdHis', time()) . rand(1000, 9999);
		$order['total_integral']=$pay_integral;
		$order['consignee'] = $Orderaddressinfo['consignee'];
		$order['telephone'] = $Orderaddressinfo['telephone'];
		$order['country'] = $Orderaddressinfo['country'];
		$order['province'] = $Orderaddressinfo['province'];
		$order['city'] = $Orderaddressinfo['city'];
		$order['district'] = $Orderaddressinfo['district'];
		$order['address'] = $Orderaddressinfo['address'];
		$order['comment'] = I('post.content');
		$order['shipping_status'] = 0;	
		$order['addtime'] = Gettime();
		$order['orderstate'] = 1;
		$order['goodtitle'] =$Goodsinfo['title'];
		$order['pic'] =$Goodsinfo['pic'];
		$order['nums']=$nums;
		$order['integral']=$Goodsinfo['integral'];
		
		$rs = $M_Order->add($order);   //插入订单
		
		if($rs){
			
			M('Smember')->where(array('id'=>$memberid))->setDec('integral',$pay_integral);
			
			$return['status'] = 1;
			$this->ajaxReturn($return);
			exit;
			
		}else{

			$return['status'] = 0;
			$return['msg'] = '创建订单失败';
			$this->ajaxReturn($return);
			exit;
		}
	}
	
	
	public function exchangelist(){
		$memberid = getLoginID();
		$map['userid']=$memberid;
		$orderstate=I('get.orderstate');
		
		if($orderstate){
			$map['orderstate']=$orderstate;
		}
		
		$list=M('Jifen_order')->where($map)->order('addtime desc')->select();

        foreach ($list as $key => $val) {
            $list[$key]['count'] =  M('jifen_message')->where(array('orderid'=>$val['id'],'status'=>0))->count();
        }
		
		$this->assign('list',$list);
		$this->assign('menutype',4);
		$this->display();
	}
	
	
	//兑换详细
	public function exchange_detail(){
		
		$id=intval(I('get.id'));
		$memberid = getLoginID();
		$map['userid']=$memberid;
		$map['id']=$id;
		 
		$info=M('jifen_order')->where($map)->find();
        $message = M('jifen_message')->where(array('orderid'=>$id))->find();
        $message['message'] = str_ireplace('\"','"',htmlspecialchars_decode($message['message']));
		
		if(!$info){
		
			echo '<script> alert("参数错误");window.history.back(-1);</script>';
			exit();
		}

		$this->assign('info',$info);
        $this->assign('message',$message);
		$this->assign('menutype',4);
		$this->display();
	}


    
    /**
     * 兑换记录
     */
    
    public function duihuanlist(){
        $this->display();
    }
    
    /**
     * 拼团详情
     */
    public function ptdeatil(){
        $this->display();
    }
    /**
     * 团购成功
     */
    public function pingtuan1(){
        $this->display();
    }
    
    /**
     * 确认支付
     */
    public function qrzf(){
		$goodsid=intval(I('get.goodsid'));
		$guigeid=intval(I('get.guigeid'));
		$type=intval(I('get.type')); // 1.单买  2.购物车
        $memberid = getLoginID();
		$is_default = 0; //是否存在默认地址 1.存在

		$M_Orderaddress = M('Orderaddress');
		$M_Goods = M('Goods');
		$M_Goods_guige= M('Goods_guige');
        $M_Orderdetail = M('orderdetail');

        if(intval(I('get.adressid'))){
           $where['id']=I('get.adressid');
        }else{
            $where['userid']=$memberid;
            $where['is_default']=1;
        }

        /* 默认地址 */
        $Orderaddress = $M_Orderaddress->where($where)->find();
        if (!$Orderaddress) {
            # 没有默认地址选择最新添加的作为收货地址
            if($memberid){
                $Orderaddress = $M_Orderaddress->where(array('userid'=>$memberid))->order('addtime desc')->find();
            }
           
        }
    
        if(!empty($Orderaddress)){
            $is_default = 1;
        }

		/* 判断参数 */
		if($goodsid==0 || $guigeid==0){
			$this->redirect("/Weixin/Goods/goodslist"); //直接跳转，不带计时后跳转
		}

        $starttime = date('Y-m-d',time())." 00:00:00";
        $endtime = date('Y-m-d',time())." 23:59:59";

        $limit_where['pay_status']=1;
        $limit_where['userid']=$memberid;
        $limit_where['goodsid']=$goodsid;
        $limit_where['goods_guige_id']=$guigeid;
        $limit_where['paytime'] = array('between',array($starttime,$endtime));

        $havapay = $M_Orderdetail->where($limit_where)->count();
        $havapay = $havapay?$havapay:0;

		$Goodsinfo = $M_Goods->where('id='.$goodsid)->find();
        $starttime =  date('Y/m/d H:i:s',strtotime($Goodsinfo['starttime']));
        $endtime =  date('Y/m/d H:i:s',strtotime($Goodsinfo['endtime']));
        $this->assign('starttime',$starttime);
        $this->assign('endtime',$endtime);

		$Goods_guigeinfo = $M_Goods_guige->where('id='.$guigeid)->find();
        $vip = M('Smember')->where(array('id'=>$memberid))->getField('vip');
		
		/* 支付价格 */
		$Goodsinfo['pay_price'] = getPrice($goodsid,$memberid);
	
		$this->assign('Goodsinfo',$Goodsinfo);
		$this->assign('Goods_guigeinfo',$Goods_guigeinfo);
		$this->assign('Orderaddress',$Orderaddress);
		$this->assign('is_default',$is_default);
        $this->assign('havapay',$havapay);
        $this->assign('vip',$vip);
		$this->assign('type',$type);
        $this->display();
    }



   //购物车购买
    public function paynow(){
        $memberid = getLoginID();
        $is_default = 0; //是否存在默认地址 1.存在
        $M_Orderaddress = M('Orderaddress');
        

        if(intval(I('get.adressid'))){
           $where['id']=I('get.adressid');
        }else{
            $where['userid']=$memberid;
            $where['is_default']=1;
        }

        /* 默认地址 */
        $Orderaddress = $M_Orderaddress->where($where)->find();
        if (!$Orderaddress) {
            # 没有默认地址选择最新添加的作为收货地址
            $Orderaddress = $M_Orderaddress->where(array('userid'=>$memberid))->order('addtime desc')->find();
        }
    
        if(!empty($Orderaddress)){
            $is_default = 1;
        }

        

        $M_Goods = M('Goods');
        $M_Goods_guige= M('Goods_guige');
        $M_cart = M('cart');

     
        if(is_array($_SESSION['order'])){
            foreach ($_SESSION['order'] as $key => $value) {
                $carinfo = $M_cart->where(array('id'=>$value))->find();

                $goodsinfo=$M_Goods->where("id=%d",array($carinfo['goodsid']))->find();
     
                $goods[$key]['num']=$carinfo['num'];
                /* 支付价格 */
                $goods[$key]['pay_price'] = getPrice($carinfo['goodsid'],$memberid);
                $allprice+=$carinfo['num']*$goods[$key]['pay_price'];
                $Goods_guigeinfo = $M_Goods_guige->where('id='.$carinfo['guigeid'])->find();
                $goods[$key]['guige']=$Goods_guigeinfo['guige'];
                $goods[$key]['pic']=$goodsinfo['pic'];
                $goods[$key]['name']=$goodsinfo['good_name'];
            }
        }

      
        $this->assign('goods',$goods);
        $this->assign('allprice',$allprice);
        $this->assign('type','2');
        $this->assign('Orderaddress',$Orderaddress);
        $this->assign('is_default',$is_default);
        $this->display();

    }
    
    
	
	
    public function orderadd(){
		$memberid = getLoginID();
        $order['userid'] = $memberid;
		$order['goods_id'] = intval(I('post.goodsid'));
		$nums = intval(I('post.nums')); //商品数量
		$guigeid = intval(I("post.guigeid")); //商品规格id
		$addressID = intval(I("post.addressID")); //收货地址id
    
		/* 收货地址 */
		if(!$addressID){
			$return['status'] = 0;
			$return['msg'] = '收货地址不能为空';
			$this->ajaxReturn($return);
			exit;
		}
		
        $M_Orderlist = M('Orderlist');
        $M_Orderdetail = M('Orderdetail');
        $M_Goods = M('Goods');
        $M_Goods_guige = M('Goods_guige');
		$M_Orderaddress = M('Orderaddress');
		
		$Goodsinfo = $M_Goods->where('id='.$order['goods_id'])->find();

        $special_type=$Goodsinfo['special_type'];
        $vip = M('Smember')->where(array('id'=>$memberid))->getField('vip');

        if($special_type==1){
          if($vip!=1&&$vip!=3){
            $arrys = array('status'=>0,'info'=>'员工才能购买');
            echo json_encode($arrys);exit;
         
          }
        }

        if($special_type==2){
          if($vip!=2&&$vip!=3){
            $arrys = array('status'=>0,'info'=>'5.1服务卡会员才能购买');
            echo json_encode($arrys);exit;
          }
        }

        $now_time=time();
        $start_time=strtotime($Goodsinfo['starttime']);
        $end_time=strtotime($Goodsinfo['endtime']);


        if($special_type==4){
           if($start_time>$now_time){
               $return['status'] = 0;
               $return['msg'] = '抢购还未开始';
               $this->ajaxReturn($return);
               exit;

            }elseif($now_time>$end_time){
               $return['status'] = 0;
               $return['msg'] = '抢购已结束';
               $this->ajaxReturn($return);
               exit;
            } 

        }

		$Goods_guigeinfo = $M_Goods_guige->where('id='.$guigeid)->find();
		$Orderaddressinfo = $M_Orderaddress->where('id='.$addressID)->find();
   

        
        $starttime = date('Y-m-d',time())." 00:00:00";
        $endtime = date('Y-m-d',time())." 23:59:59";
        /* 是否限购 */
        if($Goods_guigeinfo['num_limit']>0){
            $limit_where['pay_status']=1;
            $limit_where['userid']=$memberid;
            $limit_where['goodsid']=$order['goods_id'];
            $limit_where['goods_guige_id']=$guigeid;
            $limit_where['paytime'] = array('between',array($starttime,$endtime));
            $paycount = $M_Orderdetail->where($limit_where)->count();
            $canbuy = $nums + $paycount;
            if($canbuy>$Goods_guigeinfo['num_limit']){
                $return['status'] = 0;
                $return['msg'] = '活动商品 每天仅限购买'.$Goods_guigeinfo['num_limit'].'件';
                $this->ajaxReturn($return);
                exit;
            }
        }

		/* 是否售罄 */
		if($Goods_guigeinfo['nums']<=0){
			$return['status'] = 0;
			$return['msg'] = '已售罄';
			$this->ajaxReturn($return);
			exit;
		}

		/* 是否下架 */
		if($Goodsinfo['is_show']=0){
			$return['status'] = 0;
			$return['msg'] = '已下架罄';
			$this->ajaxReturn($return);
			exit;
		}

		$pay_price = getPrice($order['goods_id'],$memberid); //支付价格
		
        $order['orderno'] = date('YmdHis', time()) . rand(1000, 9999);
        $order['consignee'] = $Orderaddressinfo['consignee'];
        $order['telephone'] = $Orderaddressinfo['telephone'];
        $order['country'] = $Orderaddressinfo['country'];
		$order['province'] = $Orderaddressinfo['province'];
		$order['city'] = $Orderaddressinfo['city'];
		$order['district'] = $Orderaddressinfo['district'];
		$order['address'] = $Orderaddressinfo['xiangqing'];
        $order['comment'] = I('post.content');
		$order['pay_fee'] = $pay_price*$nums; // 支付价格 商品单价*商品数量 + 运费
        $order['pay_status'] = 0;
		$order['shipping_status'] = 0;
		$order['coupon_fee'] = 0 ;
        $order['addtime'] = Gettime();
		$order['total_price'] = $order['pay_fee']+$order['coupon_fee']; //总价
		$order['paytype'] = 2;     
		$order['orderstate'] = 1;
		$rs = $M_Orderlist->add($order);   //插入订单

        $orderd['goodsid'] = $order['goods_id'];
        $orderd['userid'] = $memberid;
        $orderd['orderno'] = $order['orderno'];
        $orderd['good_nowprice'] = $pay_price;  //单价
        $orderd['goodsname'] = $Goodsinfo['good_name'];   // 商品名
        $orderd['guige'] = $Goods_guigeinfo['guige'];  // 规格名称
        $orderd['goods_guige_id'] = $guigeid;  // 规格名称
        $orderd['img'] = $Goodsinfo['pic'];  //图片
        $orderd['num'] = $nums;  // 数量
        $orderd['allprice'] = $order['total_price'];  //总价
        $orderd['addtime'] = Gettime();
		$orderd['orderid'] = $rs;
		$rsd = $M_Orderdetail->add($orderd);   //插入订单细节       

		if($rs && $rsd){
			session('orderid',$rs);
			$return['status'] = 1;
			$this->ajaxReturn($return);
			exit;
		}else{
			$return['status'] = 0;
			$return['msg'] = '订单插入失败';
			$this->ajaxReturn($return);
			exit;
		}

	}



    /**
     * 购物车支付
    **/
    public function gopay(){
        if(empty($_SESSION['order'])){

            $result = array(
                'status'=>0,
                'info'=>'购物车已清空，请重新选择产品'
                );
            echo json_encode($result);exit;
        }

        $addressid=I('post.addressid');
      

        $remark=I('post.remark');
        $memberid = getLoginID();
        $user_id=$memberid;

        $paymoney=I('post.paymoney');
    
        $addressinfo=M('orderaddress')->where("id=%d",array($addressid))->find();//地址信息

        # 开启事务
        $Order = D('orderlist')->startTrans();
        $orderno=date('YmdHis', time()) . rand(1000, 9999);
        $arr['userid']=$user_id;
        $arr['addtime']=date("Y-m-d H:i:s");
        $arr['orderno']=$orderno;
        $arr['telephone']=$addressinfo['telephone'];
        $arr['consignee']=$addressinfo['consignee'];
        $arr['province']=$addressinfo['province'];
        $arr['city']=$addressinfo['city'];
        $arr['country']=$addressinfo['country'];
        $arr['address']=$addressinfo['xiangqing'];
        $arr['total_price']=$paymoney;
        $arr['pay_fee']=$paymoney;
        $arr['comment']=$remark;
        $re=M('orderlist')->data($arr)->add();

        if($re){
            $M_cart=M('Cart');
            $M = M('goods');
            foreach ($_SESSION['order'] as $key => $value) {
                $carinfo = $M_cart->where(array('id'=>$value))->find();
                $goods=$M->where("id=%d",array($carinfo['goodsid']))->find();
                $orderd['userid'] = $user_id;
                $da['orderid']=$re;
                $da['orderno']=$orderno;
                $da['addtime']=$arr['addtime'];
                $da['goodsid']=$carinfo['goodsid'];
                $da['num']=$carinfo['num'];//
                $da['allprice']=$paymoney;
                $pay_price = getPrice($carinfo['goodsid'],$user_id); //支付价格
                $da['good_nowprice']=$pay_price;
                $da['img']=$goods['pic'];
                $da['goodsname']=$goods[good_name];
                $da['userid']=$user_id;
                $da['goods_guige_id']=$carinfo['guigeid'];
                $res=M('orderdetail')->data($da)->add();
                M("Cart")->where('id=%d',array($value))->delete();//删除购物车产品

            }

            $_SESSION['order']="";

        }


        if($res){
        
            $result = array(
                'status'=>1,
                'info'=>'提交成功',
                'orderid'=>$re
                );
            echo json_encode($result);exit;

        }else{
            $result = array(
                'status'=>2,
                'info'=>'提交失败'
                );
            echo json_encode($result);exit;
        }

       

    }





    public function jsapi(){
        header('content-type:text/html;charset=utf-8;');
		vendor('Wxpay.WxPayPubHelper.WxPayPubHelper');
		$orderid = intval(I('get.id'));
		$userid = getLoginID();
        $come = I('get.come');
        $url = U('Weixin/order/orderlist');
        if(empty($orderid)){
		    $orderid = session('orderid');
        }else{
            session('orderid',$orderid);
        }
		
		// 如果付款成功点击微信后退报错处理 BEGIN 2016.06.30
		if(empty($orderid))
		{
			header("Location: ".U("Weixin/index")); 
		}
		// 如果付款成功点击微信后退报错处理 END 2016.06.30
		
		if(!empty($orderid))
		{
			$m = M('orderlist');
			$arr = $m->where("id=$orderid")->find(); //根据订单号查找订单详情  
            $detail = M('orderdetail')->where(array('orderid'=>$orderid))->find();

            if($detail['goodsid']){
                $good_name = M('goods')->where("id=".$detail['goodsid'])->getField('good_name');
            }

            if(empty($good_name)){
                echo '<script>alert("商品不存在");window.location.href="'.$url.'";</script>';die;
            }

			$out_trade_no=$arr['orderno'];
			$total_fee=$arr['pay_fee']*100;
		}
		else
		{
			$state=I('get.state');
			$str = stripslashes($state);
			$arr=json_decode($str,1);
			$out_trade_no=$arr['out_trade_no'];
			$total_fee=$arr['pay_fee']*100;
		}

		
		//使用jsapi接口 
		$jsApi = new \JsApi_pub();
		//=========步骤1：网页授权获取用户openid============
		//通过code获得openid
		if (!isset($_GET['code']))

		{
			//触发微信返回code码
			$url= $jsApi->createOauthUrlForCode(\WxPayConf_pub::JS_API_CALL_URL);
			$state = json_encode(array(
				"orderid" => $orderid,
                /* "good_name" => $good_name,
				"out_trade_no" => $out_trade_no,
				"total_fee" => "$total_fee", */
				
			));
			$url = str_replace("STATE", $state, $url);
			echo "<script>window.location.href='".$url."'</script>";die;
		}else{
			//获取code码，以获取openid
			$code = $_GET['code'];
			$jsApi->setCode($code);
			$openid = $jsApi->getOpenId();
			session("openid",$openid);
		}





		//=========步骤2：使用统一支付接口，获取prepay_id============
		//使用统一支付接口
		$unifiedOrder = new \UnifiedOrder_pub();
		//设置统一支付接口参数
		//设置必填参数
		//appid已填,商户无需重复填写
		//mch_id已填,商户无需重复填写
		//noncestr已填,商户无需重复填写
		//spbill_create_ip已填,商户无需重复填写
		//sign已填,商户无需重复填写
		$unifiedOrder->setParameter("openid","$openid");//用户标识
		$unifiedOrder->setParameter("body","$good_name");//商品描述
		//自定义订单号，此处仅作举例
	//	$timeStamp = time();
	//	$out_trade_no = WxPayConf_pub::APPID."$timeStamp";
	//    $orderid=$_GET['orderid'];
		$unifiedOrder->setParameter("out_trade_no","$out_trade_no");//商户订单号
		$unifiedOrder->setParameter("total_fee","$total_fee");//总金额
		$unifiedOrder->setParameter("notify_url",\WxPayConf_pub::NOTIFY_URL);//通知地址
		$unifiedOrder->setParameter("trade_type","JSAPI");//交易类型
		//非必填参数，商户可根据实际情况选填
		//$unifiedOrder->setParameter("sub_mch_id","XXXX");//子商户号
		//$unifiedOrder->setParameter("device_info","XXXX");//设备号
		//$unifiedOrder->setParameter("attach","XXXX");//附加数据
		//$unifiedOrder->setParameter("time_start","XXXX");//交易起始时间
		//$unifiedOrder->setParameter("time_expire","XXXX");//交易结束时间
		//$unifiedOrder->setParameter("goods_tag","XXXX");//商品标记
		//$unifiedOrder->setParameter("openid","XXXX");//用户标识
		//$unifiedOrder->setParameter("product_id","XXXX");//商品ID
		$prepay_id = $unifiedOrder->getPrepayId();

        if($arr['pay_status']==1){
            echo '<script>alert("订单已支付");window.location.href="'.$url.'";</script>';die;
        }

        if(empty($prepay_id)){
            echo '<script>alert("支付失败");window.location.href="'.$url.'";</script>';die;
        }

        $orderdetailtModel = M('orderdetail');
        $goods_guige = M('goods_guige');
        $order_m = M("orderlist");
        $goods_info = M('goods');
        $goods_guige->startTrans();


        $info = $orderdetailtModel->where(array('orderid'=>$orderid))->select();
        foreach ($info as $key => $vo) {


            $kucun = M('goods_guige')->where(array('id'=>$vo['goods_guige_id']))->getField('nums');
            $Goods_guigeinfo = M('goods_guige')->where(array('id'=>$vo['goods_guige_id']))->find();
            if($arr['is_num']!=1){
				
				
				
                if($kucun<=0){
                    $goods_guige->rollback();
                    echo '<script language="javascript">alert("已售罄");window.location.href="'.$url.'";</script>';die;
                }

                $result = $goods_guige->where(array('id'=>$vo['goods_guige_id']))->setDec('nums',$vo['num']);
                if(!$result){
                    $goods_guige->rollback();
                    echo '<script language="javascript">alert("已售罄");window.location.href="'.$url.'";</script>';die;
                }
				
				
				
				
				

            }

           
      
            if($come==1){
                $Goodsinfo = $goods_info->where(array('id'=>$vo['goodsid']))->field('special_type','starttime','endtime')->find();
                if($Goodsinfo['special_type']==4){
                    $start_time = strtotime($Goodsinfo['starttime']);
                    $end_time = strtotime($Goodsinfo['endtime']);
                    $nowtime = time();

                    if($start_time>$nowtime){
                        echo '<script language="javascript">alert("抢购还未开始");window.location.href="'.$url.'";</script>';die;
                    }elseif ($nowtime>$end_time){
                        echo '<script language="javascript">alert("抢购已结束");window.location.href="'.$url.'";</script>';die;
                    }

                }
            }

 

            $starttime = date('Y-m-d',time())." 00:00:00";
            $endtime = date('Y-m-d',time())." 23:59:59";


             /* 是否限购 */
            if($Goods_guigeinfo['num_limit']>0){
                $limit_where['pay_status']=1;
                $limit_where['userid']=$userid;
                $limit_where['goodsid']=$vo['goodsid'];
                $limit_where['goods_guige_id']=$vo['goods_guige_id'];
                $limit_where['paytime'] = array('between',array($starttime,$endtime));
                
                $paycount = $orderdetailtModel->where($limit_where)->count();
                $canbuy = $paycount + $vo['num'];
                if($canbuy>$Goods_guigeinfo['num_limit']){
                    echo '<script language="javascript">alert("活动商品 每天仅限购买'.$Goods_guigeinfo['num_limit'].'件");window.location.href="'.$url.'";</script>';die;
                }
            }
            
        }

        if($arr['is_num']!=1){
            $res = $order_m->where(array("id"=>$orderid))->setField("is_num", 1);
            if(!$res){
                $goods_guige->rollback();
                echo '<script language="javascript">alert("购买失败！");window.location.href="'.$url.'";</script>';die;
            }
        }

        $goods_guige->commit();


		//=========步骤3：使用jsapi调起支付============
		$jsApi->setPrepayId($prepay_id);
		$jsApiParameters = $jsApi->getParameters();
		
        $this->assign('out_trade_no',$out_trade_no);
		$this->assign("jsApiParameters",$jsApiParameters);
		$this->assign("id",$orderid);
	
		$this->display();
    }






    public function notify_url(){

		$host_url = C('HOST_URL');
		$orderid = session('orderid');
		if(empty($orderid))
		{
			header("Location:".$host_url."/Weixin/Order/orderlist");
			exit;
		}
		$orderlistModel = M('orderlist');
		
		$orderstate = 2;
		$pay_status = 1;
		$paytime = date('Y-m-d H:i:s',time());
		$rs = $orderlistModel->where("id={$orderid}")->save(array('orderstate'=>$orderstate,'pay_status'=>$pay_status,'paytime'=>$paytime));
 
        $arr['paytime'] = $paytime;
        $res = M('orderdetail')->where(array('orderid'=>$orderid))->save($arr);

       
		session("orderid",null);
		header("Location:".$host_url."/Weixin/Order/orderlist"); exit;


	}
	
	
	

	/**
     * 支付成功
     */
    public function paysuccess(){
        $this->display();
    }
    
    /**
     * 订单状态
     */
    public function orderstate(){
        $this->display();
    }
    
    /**
     * 物流
     */
    public function wuliu(){

        $where['id'] = I('get.id');
        $ordertype = I('get.ordertype');
        if($ordertype==1){
            $order = M('orderlist')->where($where)->find();
        }elseif($ordertype==2){
            $order = M('jifen_order')->where($where)->find();
        }
       
        //$order['expressname'] = '圆通速递';
       // $order['expressno'] = '200382770316';
	   
        $res = $this->getOrderTracesByJson($order['expressname'],$order['expressno']);
		
        $express = json_decode($res,true);
		//print_r($express );
        if($express['showapi_res_code']==0){
            $exp = $express['showapi_res_body']['data'];
        }
		//print_r($exp);
        $this->assign('order',$order);
        $this->assign('exp',$exp);
        $this->assign('menutype',4);
        $this->display();

    }
	
	

     /**
    * Json方式 查询订单物流轨迹
    */
    function getOrderTracesByJson($express,$LogisticCode){
		
		$host = "http://ali-deliver.showapi.com";
		$path = "/showapi_expInfo";
		$method = "GET";
		$appcode = "378f2cac706140eb9b0fe0748698500a";
		$headers = array();
		array_push($headers, "Authorization:APPCODE " . $appcode);
		$querys = "com=".$express."&nu=".$LogisticCode;
		$bodys = "";
		$url = $host . $path . "?" . $querys;
		
		
		$proxy = "192.168.69.152";
		$proxyport = "3128";
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_FAILONERROR, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, true);
		curl_setopt($curl, CURLOPT_PROXY,$proxy);
		curl_setopt($curl, CURLOPT_PROXYPORT,$proxyport);
		curl_setopt($curl, CURLOPT_TIMEOUT, 120);
		if (1 == strpos("$".$host, "https://"))
		{
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		}
		$response = curl_exec($curl);
		
		if (curl_getinfo($curl, CURLINFO_HTTP_CODE) == '200') {
			$header_size	= curl_getinfo($curl, CURLINFO_HEADER_SIZE);
			$headers		= substr($response, 0, $header_size);
			$body		= substr($response, $header_size);
		}
				
		return $body;
		
        exit;
        /* $name = array(
            '顺丰快递'=>'SF',
            '申通快递'=>'STO',
            '韵达快递'=>'YD',
            '圆通速递'=>'YTO',
            '天天快递'=>'HHTT',
            '德邦'=>'DBL',
            'EMS'=>'EMS',
			'中通快递'=>'ZTO'
        );
        $ShipperCode = $name[$express];
        $LogisticCode = $LogisticCode;
        
        $EBusinessID = '1265531';
        $AppKey = '2fac2b65-0f6e-4738-abcb-52ff176ca90a';
        $ReqURL = 'http://api.kdniao.cc/Ebusiness/EbusinessOrderHandle.aspx';
        
        $requestData= "{'OrderCode':'','ShipperCode':'".$ShipperCode."','LogisticCode':'".$LogisticCode."'}";
        $datas = array(
            'EBusinessID' => $EBusinessID,
            'RequestType' => '1002',
            'RequestData' => urlencode($requestData) ,
            'DataType' => '2',
        );
        $datas['DataSign'] = self::encrypt($requestData, $AppKey);
        $result=self::sendPost($ReqURL, $datas);  
        
        //根据公司业务处理返回的信息......

        return $result; */
    }


       /**
     *  post提交数据 
     * @param  string $url 请求Url
     * @param  array $datas 提交的数据 
     * @return url响应返回的html
     */
    function sendPost($url, $datas) {
        $temps = array();   
        foreach ($datas as $key => $value) {
            $temps[] = sprintf('%s=%s', $key, $value);      
        }   
        $post_data = implode('&', $temps);
        $url_info = parse_url($url);
        if($url_info['port']=='')
        {
            $url_info['port']=80;   
        }
        $httpheader = "POST " . $url_info['path'] . " HTTP/1.0\r\n";
        $httpheader.= "Host:" . $url_info['host'] . "\r\n";
        $httpheader.= "Content-Type:application/x-www-form-urlencoded\r\n";
        $httpheader.= "Content-Length:" . strlen($post_data) . "\r\n";
        $httpheader.= "Connection:close\r\n\r\n";
        $httpheader.= $post_data;
		print_r($url_info) ;
		exit;
        $fd = fsockopen($url_info['host'], $url_info['port']);
        fwrite($fd, $httpheader);
        $gets = "";
        $headerFlag = true;
        while (!feof($fd)) {
            if (($header = @fgets($fd)) && ($header == "\r\n" || $header == "\n")) {
                break;
            }
        }
        while (!feof($fd)) {
            $gets.= fread($fd, 128);
        }
        fclose($fd);  
        
        return $gets;
    }



    /**
     * 电商Sign签名生成
     * @param data 内容   
     * @param appkey Appkey
     * @return DataSign签名
     */
    function encrypt($data, $appkey) {
        return urlencode(base64_encode(md5($data.$appkey)));
    }










}