<?php
namespace Weixin\Controller;
use Think\Controller;
class CommonController extends PublicController {
    public function _initialize(){
    	
    	parent::_initialize();
		
		$host_url = C('HOST_URL');
        //判断用户是否已经登录
		
		//session('smember_id',2);
        $uid =session('smember_id');
		//$cookie_member_id = cookie('member_id');
		
        if(!$uid){
            $_SESSION['surl']=$host_url.$_SERVER['REQUEST_URI'];
			//$_SESSION['surl'] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
            $this->redirect($host_url."Weixin/Login/weixin"); //直接跳转，不带计时后跳转
        }  
		
        /* if(!$uid){
			if(!empty($cookie_member_id)){
				session('smember_id',$cookie_member_id);
			}else{
				$_SESSION['surl']=$host_url.$_SERVER['REQUEST_URI'];
				$this->redirect($host_url."/Login/weixin/"); //直接跳转，不带计时后跳转
			}
        }  */
	   
		/* 
			BEGIN 定位获取经销商id 分屏判断必要元素
		*/
/* 		$dealer_id=session('posId'); // 经销商id 
		if(!$dealer_id){
			$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			header("Location:/IndexPos/main?url=$url");
			exit;
		} */
		/* 
			END 定位获取经销商id 分屏判断必要元素
		*/	   
	   

		
    }
}