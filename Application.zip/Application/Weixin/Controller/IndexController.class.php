<?php
namespace Weixin\Controller;
 use Think\Controller;
 class IndexController extends CommonController {
    
    /**
     * 初始化函数
     */
    public function _initialize() {
        parent::_initialize();
    
    }
    
    public function test(){
        
        var_dump($this->city);
        
    }
    
    /**
     * 首页
     */
    public function index(){
        
        $M_pic=M('Pic');
      
        $banner=$M_pic->where(array('typeid'=>1))->order('sequence desc')->select();
        $this->assign('banner',$banner);
        //广告
        $ad=$M_pic->where(array('typeid'=>2))->order('sequence desc')->select();
        $this->assign('ad',$ad);
        
        //新品推荐
        $new_pro=$M_pic->where(array('typeid'=>3))->order('sequence asc')->select();
        foreach ($new_pro as $key=>$val){
            $price = getPrice($val['goodsid'],$userid); 
            $new_pro[$key]['price'] = $price;
        }
        $this->assign('new_pro',$new_pro);
 
        //专区
        $arr=M('pic_type')->select();
        foreach ($arr as $k=>$v){
            $arr[$k]['goods']=$M_pic->where(array('uha_pic.dealer_id'=>$v['id'],'uha_goods.is_show'=>1,'uha_pic.typeid'=>4))
            ->join('left join uha_goods ON uha_pic.goodsid=uha_goods.id')
            -> field("uha_pic.*,uha_goods.price,uha_goods.old_price,uha_goods.id as gid")
            -> order('uha_goods.sequence desc')
            ->limit(1)->select();

        }

        $this->assign('list',$arr);
        $this->assign('menutype',1);
        $this->display();
    }
    
    
}