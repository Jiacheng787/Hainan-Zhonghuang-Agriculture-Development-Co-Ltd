<?php
namespace Weixin\Controller;
use Think\Controller;
class PublicController extends Controller {
	
    public $session_id;
    
    protected $city;
   
    /*
     * 初始化操作
     */
    public function _initialize() { 

		$auth_module_list = M('auth_module')->where(array("id"=>11))->find();
		if($auth_module_list['is_show']==0){
			echo '<div style="text-align:center;padding-top: 120px;font-size:50px;font-weight:bold;">功能维护中...</div>';
			exit;	
		}
    	$this->session_id=session( 'smember_id' );
        define('SESSION_ID',$this->session_id); //将当前的session_id保存为常量，供其它方法调用
        $this->city = get_position();
        $this->read_member_info();
        $this->cart_nums();
        $this->get_location();
    }
    /**
     * 用户信息 
     */
    public function read_member_info()
    {
    	$memberid=$this->session_id;
    	$member_info=M('Smember')->find($memberid);

    	$this->assign('member_info',$member_info);
          
    }
    
    public function cart_nums(){
    	
    	$M_cart = M('cart');
    	$memberid=$this->session_id;
    	$map['userid'] = $memberid;
    	$cart_goods = $M_cart->where($map)->field('num')->order('id desc')->select();
    	
    	$cart_nums = 0;
    	
    	foreach ($cart_goods as $key => $value) {
    		
    		$cart_nums+=$value['num'];

    	}
    	
    	$this->assign('cart_nums',$cart_nums);
    	
    }
    
    public function get_location(){
    	
    	$address=get_position();
    	
    	$this->assign('city',$address['city']);
    	
    }

}