<?php
namespace Weixin\Controller;
use Think\Controller;
class Login1Controller extends Controller {
    /**
     * 员工首页
     */
    public function index(){
        $this->display();
    }
	
	//微信
	public function weixin(){
		$host_url = C('HOST_URL');
		$appid = "wx6463f5918d23e8b8";
        $uri = urlencode($host_url."/Weixin/Login1/weixinLogin");
		header("Location: https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$appid."&redirect_uri=".$uri."&response_type=code&scope=snsapi_userinfo#wechat_redirect");
    }
	
	
	public function weixinLogin(){

       $post = $_POST;
        //$post=$this->_post();
        

       
        if(empty($post['openid'])){
            $this->display();
        }else{
			//$member = D('Smember')->where("wx_openid='%s'",$post['openid'])->getField('id');
        	$member = D('Smember')->where(array('wx_openid'=>$post['openid']))->getField('id');


            if(empty($member)){
                $act=M('Smember');
				$date['wx_name']=$_POST['truename'];
				$date['wx_openid']=$_POST['openid'];
				$date['wx_img']=$_POST['touimg'];
				$date['addtime']=date('Y-m-d H:i:s');
				$pid=$act->add($date);
                session('smember_id',$pid);
				//cookie('member_id',$pid,3600*24*15);
                echo "<script>window.location.href='".$_SESSION['surl']."'</script>";
            }else{
                session('smember_id',$member);
                
                echo session( 'smember_id' );
                exit();
                
				//cookie('member_id',$member,3600*24*15);
                echo "<script>window.location.href='".$_SESSION['surl']."'</script>";
            }
        }
    }
    
   public function test(){
   	
   	$id=getLoginID();
   	echo $id;
   	exit();
   	
   }
  
}