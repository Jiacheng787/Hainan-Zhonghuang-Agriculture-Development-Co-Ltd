<?php
namespace Admin\Model;
use Think\Model;
class SmemberModel extends Model{
	function getmemberlist($isexamine=""){
        $title=I('get.title');
        if(!empty($title)){
            $map['wx_name']=array('like',"%$title%");
            $map['telephone']=array('like',"%$title%");
            $map['_logic'] = 'or';
            $date['_complex'] = $map;
        }
        if(isset($goodtype)){
            $date['goodstype']=$goodtype;
        }
     
      
        $date["isdel"] = 1;
        $count = $this->where($date)->count();
 
        $p = getpage($count,10);
       
        $list = $this->where($date)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
        $date['list']=$list; // 赋值数据集
        $date['page']= $p->show();// 赋值分页输出
        $date['count']= $count;
        return $date;

	}
	
	function getmember(){
        if(isset($goodtype)){
            $date['goodstype']=$goodtype;
        }
        $title=I('get.title');
        $classid=I('get.dengji');
        if(!empty($goodtype)){
            $date['goodstype']=$goodtype;
        }
        if(!empty($title)){
            $date['telephone']=array('like',"%$title%");
        }
        if(!empty($classid)){
            $date['dengji']=$classid;
        }
			$date['is_fenxiao']=1;


        $count = $this->where($date)->count();
        $p = getpage($count,10);
        $list = $this->field(true)->where($date)->order('id desc')->limit($p->firstRow, $p->listRows)->select();

		
        $date['list']=$list; // 赋值数据集
        $date['page']= $p->show();// 赋值分页输出
        $date['count']= $count;

        return $date;

    }
	
	
	


	function getonememberdetail($mid){
        $date['id']=$mid;
        $rs=$this->where($date)->find();
        return $rs;
    }
 }

?>