<?php
namespace Admin\Model;
use Think\Model;
class OrderlistModel extends Model
{
    public function orderlist($tasks,$userids = "")
    {
    	$orderstate = I("orderstate");
    	$order_no   = I("order_no");
    	$telephone  = I("telephone");
    	$starttime  = I("starttime"); 
        $endtime    = I("endtime"); 
    	if($orderstate!==""){
    		$where['orderstate'] = $orderstate;
    	}

    	if($where["order_no"] !== ""){
			$where["order_no"] = array("like","%$order_no%");
    	}

    	if($telephone !== ""){
    		$where["telephone"] = array("like","%$telephone%");
    	}


        if($starttime){
            $where['a.addtime']=array('egt',$starttime);
        }
        
        if($endtime){
            $where['a.addtime']=array('elt',$endtime);
        }
        

        $where["a.isdel"] = 0;
       	$DB_PREFIX = C("DB_PREFIX");
        $str = "left join {$DB_PREFIX}member as u on u.id = a.userid and u.isdel = 0 and u.status=0";
        $count = $this->alias("a")->where($where)->count();
        $page = getpage($count,8);
        $result['data'] = $this->alias("a")->where($where)->join($str)->
                field("
        			telephone as tel,realname as username,
		        	a.id,
					a.type,task,title,
					a.addtime,
					content,special,remuneration,
					prepay,pay_type,
					orderstate,a.status,
					work_type,pay_time,refundtime,
					refund_fee,refund_state,userid,
					longitude,latitude,btime,
					order_no,audio,pic1,pic2,pic3,
					pic4,pic5,pic6
		        	")
        	->limit($page->firstRow, $page->listRows)
        	->select();
        foreach($result['data'] as $k=>$v){
        	$result['data'][$k]['type'] = $tasks[$v['type']];
        }
        $result['page'] = $page->show();
        return $result;
    }
}


 ?>