<?php
namespace Admin\Model;
use Think\Model;
class RecruitmentModel extends Model{
		
	public function getAllSalary(){
		$position = I('get.title');
		$where['position'] = array("like","%$position%");
		$where["r.isdel"] = 0;
		$result = $this-> where($where) ->field("c.company_name,r.*") -> select();
		return $result;
	}	
}
 ?>