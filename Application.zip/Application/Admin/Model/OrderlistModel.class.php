<?php
namespace Admin\Model;
use Think\Model;
class OrderlistModel extends Model
{


    function orderlist($ordertype)
    {
        $starttime = I('get.starttime');
        $endtime = I('get.endtime');
        $orderno = I('get.orderno');
        $telephone = I('get.telephone');
        $ordertype = I('get.pay_type');
		$dealerid = I('get.dealerid');
		$groupbuy_type = I('get.groupbuy_type');

		$date['is_delete'] = 0;
      
        if ($dealerid!="") {
            $date['dealerid'] = $dealerid;
        }

		if (!empty($ordertype)) {
			if($ordertype==5){
				$date['orderstate'] = array('eq',5);
				$date['is_refund'] = 1;
            }else if($ordertype==2){
                $date['orderstate'] = array('eq',2);
			}else if($ordertype==3){
				$date['orderstate'] = 3;
			}else if($ordertype==4){
				$date['orderstate']=array('eq',4);
			}else{
            	$date['orderstate'] = $ordertype;
				$date['is_groupbuy'] = 0;	
			}
        }

        if (!empty($orderno)) {
            $date['orderno'] = $orderno;
        }
        if (!empty($telephone)) {
            $date['telephone'] = $telephone;
        }
		
        if (!empty($starttime)) {
            $date['addtime'] = array('gt', $starttime);
        }
        
        if (!empty($endtime)) {
            $date['addtime'] = array('lt', $endtime);
        }

        

		$count = $this->where($date)->count();
		$p = getpage($count, 8);
		$list = $this->field(true)->where($date)->order('id desc')->limit($p->firstRow, $p->listRows)->select();

        for ($i = 0; $i < count($list); $i++) {
            $orderid = $list[$i]['id'];
            $actiond = D('orderdetail');
            $rsd = $actiond->getorderdetail($orderid);
            $list[$i]['orderdatail'] = $rsd;
        }

        $date['list'] = $list; // 赋值数据集
		$date['count'] = $count; // 统计个数
        $date['page'] = $p->show();// 赋值分页输出
        return $date;

    }

    function selectGoodsRefund($ary=array()){
    	$where = "";
    	//根据手机号查找
    	if($ary['telephone']){
    		$where .= " and telephone='".$ary['telephone']."'";
    	}
    	//根据订单号查找
    	if($ary['orderno']){
    		$where .= " and orderno='".$ary['orderno']."'";
    	}

        $count = $this->where("is_refund=1".$where)->count();
        $p = getpage($count, 8);
        $list = $this->field(true)->where("is_refund=1".$where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();

        for ($i = 0; $i < count($list); $i++) {
            $orderid = $list[$i]['id'];

            $actiond = D('orderdetail');

            $rsd = $actiond->getorderdetail($orderid);
            $list[$i]['orderdatail'] = $rsd;
        }

        $date['list'] = $list; // 赋值数据集
        $date['count'] = $count; // 统计个数
        $date['page'] = $p->show();// 赋值分页输出

        return $date;
    }

    function getoneorderdetail($oid){
        $date['id']=$oid;
        $rs = $this->where($date)->find();
        $orderid=$rs['id'];
        $actiond = D('orderdetail');
        $rsd = $actiond->getorderdetail($orderid);

        $rs['orderdatails'] = $rsd;
        return $rs;

    }
	
    function getone($id,$fieldname){

		$rs = $this->where('id='.$id)->getField($fieldname);
		return $rs;
		
    }
	
	
	
    function delivergoods($id){

        $data['id']=$id;
        $data['orderstate']=3;
        $rs=$this->save($data);

        return $rs;
    }
	
  
	

	

	
	
	
	

}


 ?>