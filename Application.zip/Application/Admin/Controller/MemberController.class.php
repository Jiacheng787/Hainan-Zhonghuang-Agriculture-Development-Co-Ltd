<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class MemberController extends CommonController {
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",4);
    }



    public function index(){
        $action=D('Smember');
        $rsdate=$action->getmemberlist();
        $rs=$rsdate['list'];
		$count=$rsdate['count'];
        $page=$rsdate['page'];
        $this->assign('memberlist',$rs);
		$this->assign('count',$count);
		if($count>10)
		{
		$this->assign('page',$page);
		}
        $this->assign("title",I("title"));
        $this->assign("isexamine",I("isexamine"));
        $this->assign("urlname",'member');
        $this->display();
    }


    //商品收藏

    public function sc(){
        $userid = intval(I('get.id'));
        $date['userid'] =  $userid;
        $count = M('mycollect')->where($date)->count();
        $p = getpage($count,10);
        $list = M('mycollect')->where($date)->order('addtime desc')->limit($p->firstRow, $p->listRows)->select();

        if($list){
            foreach ($list as $key => $value) {
                $scgoods[$key] = M('goods')->where(array('id'=>$value['taskid']))->find();
                $scgoods[$key]['scid'] = $value['id'];
            }
        }
       
       $page = $p->show();// 赋值分页输出
       $this->assign("scgoods",$scgoods);
       $this->assign("userid",$userid);
       $this->assign("page",$page);
       $this->assign("urlname",'member');
       $this->assign("count",$count);
       $this->display();

    }


    //删除收藏


    public function delsc(){
        $id = I('get.scid');
        $userid = I('get.userid');
        if($id!=''){
            $del = M('mycollect')->delete($id);
            if($rs){
                $this->success('删除成功',U('/Admin/Member/sc',array('id'=>$userid)));
            }else{
                $this->error('删除失败');
            }
        }
        $this->assign("urlname",'member');
    }


    // 编辑个人资料
    public function editMember(){
        $id = I("id");
        $data = I("post.");
        if(IS_POST){
            // 编辑个人资料
            // 判断密码
            $data["adsasad"] = 1;
            if($data["password"]===""){
                unset($data['password']);
            }else{
                $data["password"] = md5($data["password"]);
            }
            // 判断余额
            if($data["integral"] === $data["integral_old"]){
                unset($data["integral"]);
            }
            // 判断积分
            if($data["wallet"] === $data["wallet_old"]){
                unset($data["wallet"]);
            }
            $m = M("member");
            $res = $m->create($data);
            if($res){
                $res2 = $m->save($res);
                if($res2){
                    $info["status"] = 1;
                    $info["info"] = "更新成功";
                    $this->ajaxReturn($info);
                }else{
                    $info["status"] = 0;
                    $info["info"] = "更新失败";
                    $this->ajaxReturn($info);
                }
            }else{
                $info["status"] = 0;
                $info["info"] = "更新失败";
                $this->ajaxReturn($info);
            }
        }else{
            $map["id"] = $id;
            $cache = M("member")->where($map)->find();
            $this->assign("cache",$cache);
            $this->display();
        }
    }
    


	public function delmember(){
        $memberid=I('get.id');
        $m = M("member"); // 实例化User对象
        $rs=$m->where("id=$memberid")->delete(); // 删除id为5的用户数据
        if($rs){
            $this->success('删除成功',U('/Admin/Member/index'));
        }else{
            $this->error('删除失败');
        }
    }

   
	public function detail(){
        $mid=I('get.id');
        $act=D('Smember');
        $memberdetail=$act->where('id='.$mid)->find();
		print_r($memberdetail);
		
        $this->assign('memberdetail',$memberdetail);
		$this->assign('categorylist',$rs);
		$this->assign('urlname','member');
		$this->display();

    }



    //联系卖家

    public function contact(){
        $info = M('conquestion')->where(array('type'=>'0'))->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        $this->assign('info',$info);

        if(IS_POST){
            $id = intval(I('post.id'));
            $data['qq'] = I('post.qq');
            $data['phone'] = I('post.phone');
            $data['content'] = I('post.content');
            $res = M('conquestion')->where(array('id'=>$id))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Member/contact'));exit;
            }else{
                $this->error('编辑失败');exit;
            }
        }

        $this->assign('urlname','contact');
        $this->display();

    }


    //常见问题

    public function question(){
        $info = M('conquestion')->where(array('type'=>'1'))->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        $this->assign('info',$info);

        if(IS_POST){
            $id = intval(I('post.id'));
            $data['title'] = I('post.title');
            $data['content'] = I('post.content');
            $res = M('conquestion')->where(array('id'=>$id))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Member/question'));exit;
            }else{
                $this->error('编辑失败');exit;
            }
        }

        $this->assign('urlname','question');
        $this->display();

    }

    //积分设置

    public function integral(){
        $info = M('sign_config')->find();
        $info['content'] = str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        $this->assign('info',$info);

        if(IS_POST){
            $id = intval(I('post.id'));
            $data['value'] = I('post.value');
            $data['content'] = I('post.content');
            $res = M('sign_config')->where(array('id'=>$id))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Member/integral'));exit;
            }else{
                $this->error('编辑失败');exit;
            }
        }

        $this->assign('urlname','integral');
        $this->display();

    }


   //51会员列表
    public function fiftyMember(){
        $date = array();
        $card = I('get.card');
        if($card!=''){
            $date['card'] = array('like','%'.$card.'%');
        }
        $count = M('card')->where($date)->count(); 
        $p = getpage($count,10);
        $list = M('card')->where($date)->limit($p->firstRow, $p->listRows)->select();

        foreach ($list as $key => $value) {
            $list[$key]['username'] = M('Smember')->where(array('id'=>$value['userid']))->getField('wx_name');
        }

        $page = $p->show();// 赋值分页输出
        $this->assign("list",$list);
        $this->assign("count",$count);
        $this->assign("page",$page);
        $this->assign("integral",'fifty');
        $this->display();

    }

    //添加5.1服务卡

    public function addfiftyMember(){
        if(IS_POST){
            $data['card'] = I('post.card');
			$info = M('card')->where($data)->find();
			if(empty($info)){
				$res = M('card')->add($data);
				if($res){
					$this->success('添加成功',U('/Admin/Member/fiftyMember'));exit;
				}else{
					$this->success('添加成功',U('/Admin/Member/fiftyMember'));exit;
				}
			}else{
				$this->success('已存在此卡号',U('/Admin/Member/fiftyMember'));exit;
			}
        }
        $this->display();
    }
	
	
    //修改5.1服务卡

    public function editfiftyMember(){
        $id = I('get.id');
        $info = M('card')->where(array('id'=>$id))->find();
        if(IS_POST){
            $id = I('post.id');
            $data['card'] = I('post.card');
            $res = M('card')->where(array('id'=>$id))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Member/fiftyMember'));exit;
            }else{
                $this->success('编辑成功',U('/Admin/Member/fiftyMember'));exit;
            }
        }

        $this->assign("info",$info);
        $this->display();
    }


    //删除51会员列表

    public function delfiftyMember(){
        $id = I('get.id');
		
		$info = M('card')->where(array('id'=>$id))->find();
		if($info['status']==1){
			$memberInfo = M('smember')->where(array('id'=>$info['userid']))->find();
			$data['cardnumber'] = "";
			if($memberInfo['vip'] == 3){
				$data['vip'] = 1;
			}
			if($memberInfo['vip'] == 2){
				$data['vip'] = 0;
			}
			M('smember')->where(array('id'=>$info['userid']))->save($data);
		}
		
        $del = M('card')->where(array('id'=>$id))->delete();

        if($del){
            $this->success('删除成功',U('/Admin/Member/fiftyMember'));exit;
        }else{
            $this->success('删除失败');exit;
        }

        $this->display();

    }




    /**
     * 导入会员
    */
    public function uploadExcel(){
      
       if(IS_POST){
        header('content-type:text/html;charset=utf-8;');
        $filetmpname = $_FILES['excel']['tmp_name'];
        $file_types = explode ( ".", $_FILES ['excel'] ['name'] );
        $file_type = $file_types [count ( $file_types ) - 1];

       
         /*判别是不是.xls文件，判别是不是excel文件*/
        if (strtolower ( $file_type ) != "xls"){
            echo "不是Excel文件，重新上传";die;
        }

        $url = U('Admin/Member/fiftyMember');
        import('Org.Util.PHPExcel');
        $objPHPExcel = \PHPExcel_IOFactory::load($filetmpname);
        $arrExcel = $objPHPExcel->getSheet(0)->toArray();
  
        //删除不要的表头部分，我的有三行不要的，删除三次
        $first_line = $arrExcel[0];
       
        if(
            $first_line[0] != "卡号"
        ){
            echo '<script>alert("excel表字段信息不正确");window.location.href="'.$url.'";</script>';die;
          
        }
        array_shift($arrExcel);
        $m = M("card");
        $error = "";
        foreach($arrExcel as $v){
            $count = $m->where(array("card"=>$v[0]))->find();

            if($count){
                $res = 1;
            }else{
                 $data = array(
                    "card"      => $v[0],
                    "status"    =>0
                );
                $res = $m->add($data);
            }
           
        }

      
        if($res){
            echo '<script>alert("导入成功");window.location.href="'.$url.'";</script>';die;
           
        }else{
            echo '<script>alert("导入失败");window.location.href="'.$url.'";</script>';die;
         
        }
       
       }
       
     
    } 









  









	
}