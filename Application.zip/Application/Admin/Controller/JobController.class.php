<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
use Think\Upload;
class JobController extends CommonController {
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",6);
    }

    public function index(){
        
        $this->display();
    }

    // 职业分类
    // 分类列表
    public function category(){
        $m     = D('positionClass');
        $where = array("isdel"=>0);
        $list  = $m->where($where)->order("sequence asc")->select();
        $lists = $m->get_category($list);
        $this->assign('category', $lists); // 赋值数据集

        $this->assign('urlname','jobcategory');
        $this->assign('zp',1);
        $this->display();

    }

    // 编辑分类
    public function editCategory(){
        $m = D('positionClass');
        if(IS_AJAX){
            $classname = I('post.classname');
            $sequence  = I('post.sort');
            $parid     = I('post.fid');
            $pic       = I('post.pic');
            $taskId    = I('post.categoryid');
        
            $rs=$m->check_category($classname,$parid,$taskId);    //判断类名是否重复
            if($rs){
                $data['info']   =   '类名已存在'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
                $this->ajaxReturn($data);
            }
            $m=M('positionClass');
            $arr['classname'] = $classname;
            $arr['sequence']  = $sequence;
            $arr['parid']     = $parid;
            $arr['pic']       = $pic;
            $arr['id']        = $taskId;
            $arr['addtime'] = date("Y-m-d H:i:s",time());
            $result = $m->where("id=$taskId")->save($arr);
            
            $data['info']   =   '修改成功'; // 提示信息内容
            $data['status'] =   1;  // 状态 如果是success是1 error 是0
            $data['url']    =   ''; // 成功或者错误的跳转地址


            $this->ajaxReturn($data);
            return;
        }
    }


    public function alldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('resume_cast')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }


    public function salaryalldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('recruitment')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }








    // 添加分类
    public function addCategory(){
        if(IS_AJAX){
            $classname = I('post.classname');
            $parid     = I('post.fid');
            $sequence  = I('post.sort');
            $pic       = I('post.pic');

            $action=D('positionClass');
            $rs=$action->check_category($classname,$parid);    //判断类名是否重复
            
            if(!$rs){            
                $arr['classname'] = $classname;
                $arr['parid']     = $parid;
                $arr['sequence']  = $sequence;
                $arr['pic']       = $pic;
                $arr['addtime'] = date("Y-m-d H:i:s",time());
                $rt=$action->add($arr);
                if($rt){
                    $data['info']   =   '添加成功'; // 提示信息内容
                    $data['status'] =   1;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }else{
                    $data['info']   =   '添加失败'; // 提示信息内容
                    $data['status'] =   0;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }

            }else{
                $data['info']   =   '此分类已存在'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }

            $this -> ajaxReturn($data);
            return;
        }
    }


    public function resume_cast(){
        
        $M = M("resume_cast");
        $company_name = I('get.company');
        $position = I('get.title');
        $sex = I('get.sex');
        $begin_time = I('get.begin_time');
        $end_time = I('get.end_time');
        $type = I('get.type');
	
        $map = array();
        if($company_name!=''){
            $map['uha_company.company_name'] = array('like','%'.$company_name.'%');
        }

        if($position!=''){
            $map['uha_recruitment.position'] = array('like','%'.$position.'%');
        }

        if($sex!=''){
            $map['uha_myresume.sex'] = $sex;
        }
		
		 if($type!=''){
            $map['uha_member.type'] = $type;
        }


        if($begin_time>0&&$end_time>0){
            $map['uha_resume_cast.addtime']=array(array('egt',$begin_time),array('elt',$end_time),'AND');
        }

        
       
        $count = $M->where($where)-> count();
        $p     = getpage($count,10);

        $list = $M -> where($map)
                -> join("left join uha_recruitment ON uha_recruitment.id = uha_resume_cast.recru_id")
                -> join("left join uha_company ON uha_company.id = uha_recruitment.company_id")
                -> join("left join uha_member ON uha_member.id = uha_resume_cast.userid")
                -> join("left join uha_myresume ON uha_member.id = uha_myresume.memberID")
                -> limit($p->firstRow, $p->listRows)
                -> order("uha_resume_cast.addtime desc")
                -> field('uha_resume_cast.*,uha_company.company_name,uha_recruitment.position,uha_member.wx_name,uha_member.type,uha_myresume.username,uha_myresume.sex,uha_myresume.mobile,uha_myresume.birth as shenri')->select();
			
		
					
        $this->assign('count',$count);
        $this->assign('page',$p->show());
        $this->assign('list',$list);
        $this->assign('resume',1);
        $this->display();
    }



    public function exportExcel(){

        $ids = I("ids");
		$type = I("get.type");
		
        $ids_arr = explode("_", trim($ids,"_"));
        $new_ids = implode(",", $ids_arr);

        $M = M("resume_cast");
        $map['uha_resume_cast.id'] = array('in',$new_ids);

        $list = $M -> where($map)
                -> join("left join uha_recruitment ON uha_recruitment.id = uha_resume_cast.recru_id")
                -> join("left join uha_company ON uha_company.id = uha_recruitment.company_id")
                -> join("left join uha_member ON uha_member.id = uha_resume_cast.userid")
                -> join("left join uha_myresume ON uha_member.id = uha_myresume.memberID")
                -> limit($p->firstRow, $p->listRows)
                -> order("uha_resume_cast.addtime desc")
                -> field('uha_resume_cast.*,uha_company.company_name,uha_recruitment.position,uha_member.wx_name,uha_member.type,uha_myresume.username,uha_myresume.sex,uha_myresume.mobile,uha_myresume.birth as shenri')->select();
			
				
		if(!empty($type)){
			foreach($list as $key=>$val){
			    $zhuantai =  mobile($val['mobile']);
				if($zhuantai==false){
					$info[$key] = $val;
					$info[$key]['type'] = 1;
				}
			}

			if($info){
				foreach($info as $key => $val) {
					$info[$key]['jiaoyu'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>1))->select();
					$info[$key]['work'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>2))->select();
				}
			}

		
			$m = M("myresume");

			$sex = array(
				'1'=>'男',
				'2'=>'女',
				'3'=>'其它'
				);
			$str = '';
			$str1 = '';

			$filename = date("YmdHis", time())."-简历";
			foreach($info as $k=>$v){
				$data[$k]['company_name'] = $v['company_name'];
				$data[$k]['position']   = $v['position'];
				$data[$k]['username']   = $v['username'];
				$data[$k]['sex']   = $sex[$v['sex']];
				$data[$k]['birth']   = $v['shenri'];
				$data[$k]['mobile']   = $v['mobile'];
				$data[$k]['addtime']  = date('Y-m-d',strtotime($v['addtime']));


				$str = '';
				$str1 = '';

				if($v['jiaoyu']){
					foreach ($v['jiaoyu'] as $key => $vo) {
						$stime = date('Y-m',strtotime($vo['starttime']));
						$etime = date('Y-m',strtotime($vo['endtime']));
						if($vo['major']==''){
						   $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',学历:'.$vo['education'].'||';
						}else{
							$str.= $stime.'至'.$etime.',学校:'.$vo['school'].',专业:'.$vo['major'].',学历:'.$vo['education'].'||';
						}
					}

					$data[$k]['jiaoyu'] = $str;
					
				}

				if($v['work']){
					foreach ($v['work'] as $key1 => $val) {
						$stime = date('Y-m',strtotime($val['starttime']));
						$etime = date('Y-m',strtotime($val['endtime']));

						if($val['company']==''&&$val['position']!=''){
							$str1.= $stime.'至'.$etime.',岗位:'.$val['position'].'||';
						}elseif($val['position']==''&&$val['company']!=''){
							 $str1.= $stime.'至'.$etime.',公司:'.$val['company'].'||';
						}elseif($val['company']&&$val['position']){
							$str1.= $stime.'至'.$etime.',公司:'.$val['company'].',岗位:'.$val['position'].'||';
						} 
					}
					$data[$k]['work'] = $str1;
				}
				$data[$k]['work'] = $str1;
			}
			
		}else{
	
			if($list){
				foreach($list as $key => $val) {
					$list[$key]['jiaoyu'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>1))->select();
					$list[$key]['work'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>2))->select();
				}
			}

			$m = M("myresume");
			$sex = array(
				'1'=>'男',
				'2'=>'女',
				'3'=>'其它'
				);


			$str = '';
			$str1 = '';

			$filename = date("YmdHis", time())."-简历";
			foreach($list as $k=>$v){
				$data[$k]['company_name'] = $v['company_name'];
				$data[$k]['position']   = $v['position'];
				$data[$k]['username']   = $v['username'];
				$data[$k]['sex']   = $sex[$v['sex']];
				$data[$k]['birth']   = $v['shenri'];
				$data[$k]['mobile']   = $v['mobile'];
				$data[$k]['addtime']  = date('Y-m-d',strtotime($v['addtime']));


				$str = '';
				$str1 = '';

				if($v['jiaoyu']){
					foreach ($v['jiaoyu'] as $key => $vo) {
						$stime = date('Y-m',strtotime($vo['starttime']));
						$etime = date('Y-m',strtotime($vo['endtime']));
						if($vo['major']==''){
						   $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',学历:'.$vo['education'].'||';
						}else{
							$str.= $stime.'至'.$etime.',学校:'.$vo['school'].',专业:'.$vo['major'].',学历:'.$vo['education'].'||';
						}
					}

					$data[$k]['jiaoyu'] = $str;
					
				}

				if($v['work']){
					foreach ($v['work'] as $key1 => $val) {
						$stime = date('Y-m',strtotime($val['starttime']));
						$etime = date('Y-m',strtotime($val['endtime']));

						if($val['company']==''&&$val['position']!=''){
							$str1.= $stime.'至'.$etime.',岗位:'.$val['position'].'||';
						}elseif($val['position']==''&&$val['company']!=''){
							 $str1.= $stime.'至'.$etime.',公司:'.$val['company'].'||';
						}elseif($val['company']&&$val['position']){
							$str1.= $stime.'至'.$etime.',公司:'.$val['company'].',岗位:'.$val['position'].'||';
						} 
					}
					$data[$k]['work'] = $str1;

				}

				$data[$k]['work'] = $str1;

			}
			
		
			
		}
		
	
        $title = array('公司名称','职位名称','应聘人员','性别','出生年月','手机号码','投递时间','教育背景','工作经历');
        $this->export($data,$title,$filename);

    }
	


       public function exportExcel2(){

      
        $type = I("get.type");
    
        $M = M("resume_cast");
      
        $list = $M -> where($map)
                -> join("left join uha_recruitment ON uha_recruitment.id = uha_resume_cast.recru_id")
                -> join("left join uha_company ON uha_company.id = uha_recruitment.company_id")
                -> join("left join uha_member ON uha_member.id = uha_resume_cast.userid")
                -> join("left join uha_myresume ON uha_member.id = uha_myresume.memberID")
                -> limit($p->firstRow, $p->listRows)
                -> order("uha_resume_cast.addtime desc")
                -> field('uha_resume_cast.*,uha_company.company_name,uha_recruitment.position,uha_member.wx_name,uha_member.type,uha_myresume.username,uha_myresume.sex,uha_myresume.mobile,uha_myresume.birth as shenri')->select();
            
                
        if(!empty($type)){
            foreach($list as $key=>$val){
              
                if($val['type']==1){
                    $info[$key] = $val;
                
                }
            }

            if($info){
                foreach($info as $key => $val) {
                    $info[$key]['jiaoyu'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>1))->select();
                    $info[$key]['work'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>2))->select();
                }
            }

        
            $m = M("myresume");

            $sex = array(
                '1'=>'男',
                '2'=>'女',
                '3'=>'其它'
                );
            $str = '';
            $str1 = '';

            $filename = date("YmdHis", time())."-简历";
            foreach($info as $k=>$v){
                $data[$k]['company_name'] = $v['company_name'];
                $data[$k]['position']   = $v['position'];
                $data[$k]['username']   = $v['username'];
                $data[$k]['sex']   = $sex[$v['sex']];
                $data[$k]['birth']   = $v['shenri'];
                $data[$k]['mobile']   = $v['mobile'];
                $data[$k]['addtime']  = date('Y-m-d',strtotime($v['addtime']));


                $str = '';
                $str1 = '';

                if($v['jiaoyu']){
                    foreach ($v['jiaoyu'] as $key => $vo) {
                        $stime = date('Y-m',strtotime($vo['starttime']));
                        $etime = date('Y-m',strtotime($vo['endtime']));
                        if($vo['major']==''){
                           $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',学历:'.$vo['education'].'||';
                        }else{
                            $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',专业:'.$vo['major'].',学历:'.$vo['education'].'||';
                        }
                    }

                    $data[$k]['jiaoyu'] = $str;
                    
                }

                if($v['work']){
                    foreach ($v['work'] as $key1 => $val) {
                        $stime = date('Y-m',strtotime($val['starttime']));
                        $etime = date('Y-m',strtotime($val['endtime']));

                        if($val['company']==''&&$val['position']!=''){
                            $str1.= $stime.'至'.$etime.',岗位:'.$val['position'].'||';
                        }elseif($val['position']==''&&$val['company']!=''){
                             $str1.= $stime.'至'.$etime.',公司:'.$val['company'].'||';
                        }elseif($val['company']&&$val['position']){
                            $str1.= $stime.'至'.$etime.',公司:'.$val['company'].',岗位:'.$val['position'].'||';
                        } 
                    }
                    $data[$k]['work'] = $str1;
                }
                $data[$k]['work'] = $str1;
            }
            
        }else{
    
            if($list){
                foreach($list as $key => $val) {
                    $list[$key]['jiaoyu'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>1))->select();
                    $list[$key]['work'] = M('myexperience')->where(array('resumeID'=>$val['resumeid'],'memberID'=>$val['userid'],'typeID'=>2))->select();
                }
            }

            $m = M("myresume");
            $sex = array(
                '1'=>'男',
                '2'=>'女',
                '3'=>'其它'
                );


            $str = '';
            $str1 = '';

            $filename = date("YmdHis", time())."-简历";
            foreach($list as $k=>$v){
                $data[$k]['company_name'] = $v['company_name'];
                $data[$k]['position']   = $v['position'];
                $data[$k]['username']   = $v['username'];
                $data[$k]['sex']   = $sex[$v['sex']];
                $data[$k]['birth']   = $v['shenri'];
                $data[$k]['mobile']   = $v['mobile'];
                $data[$k]['addtime']  = date('Y-m-d',strtotime($v['addtime']));


                $str = '';
                $str1 = '';

                if($v['jiaoyu']){
                    foreach ($v['jiaoyu'] as $key => $vo) {
                        $stime = date('Y-m',strtotime($vo['starttime']));
                        $etime = date('Y-m',strtotime($vo['endtime']));
                        if($vo['major']==''){
                           $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',学历:'.$vo['education'].'||';
                        }else{
                            $str.= $stime.'至'.$etime.',学校:'.$vo['school'].',专业:'.$vo['major'].',学历:'.$vo['education'].'||';
                        }
                    }

                    $data[$k]['jiaoyu'] = $str;
                    
                }

                if($v['work']){
                    foreach ($v['work'] as $key1 => $val) {
                        $stime = date('Y-m',strtotime($val['starttime']));
                        $etime = date('Y-m',strtotime($val['endtime']));

                        if($val['company']==''&&$val['position']!=''){
                            $str1.= $stime.'至'.$etime.',岗位:'.$val['position'].'||';
                        }elseif($val['position']==''&&$val['company']!=''){
                             $str1.= $stime.'至'.$etime.',公司:'.$val['company'].'||';
                        }elseif($val['company']&&$val['position']){
                            $str1.= $stime.'至'.$etime.',公司:'.$val['company'].',岗位:'.$val['position'].'||';
                        } 
                    }
                    $data[$k]['work'] = $str1;

                }

                $data[$k]['work'] = $str1;

            }
            
        
            
        }
        
    
        $title = array('公司名称','职位名称','应聘人员','性别','出生年月','手机号码','投递时间','教育背景','工作经历');
        $this->export($data,$title,$filename);

    }
	
	
	





    /**
     * 导出数据为excel表格
     *@param $data    一个二维数组,结构如同从数据库查出来的数组
     *@param $title   excel的第一行标题,一个数组,如果为空则没有标题
     *@param $filename 下载的文件名
     *@examlpe
     *$stu = M ('User');
     *$arr = $stu -> select();
     *exportexcel($arr,array('id','账户','密码','昵称'),'文件名!');
     */
    private function export($data = array(), $title = array(), $filename = 'report') {
        header("Content-type:application/octet-stream");
        header("Accept-Ranges:bytes");
        header("Content-type:application/vnd.ms-excel");
        header("Content-Disposition:attachment;filename=" . $filename . ".xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        //导出xls 开始
        if (!empty($title)) {
            foreach ($title as $k => $v) {
                $title[$k] = iconv("UTF-8", "GB2312", $v);
            }
            $title = implode("\t", $title);
            echo "$title\n";
        }
        if (!empty($data)) {
            foreach ($data as $key => $val) {
                foreach ($val as $ck => $cv) {
                    $data[$key][$ck] = iconv("UTF-8", "GB2312", $cv);
                }
                $data[$key] = implode("\t", $data[$key]);

            }
            echo implode("\n", $data);
        }

    }








    public function notice(){
        $memberID = intval(I('get.userid'));
        $recruit_id = intval(I('get.recruit_id'));
        $id = intval(I('get.id'));
        if(IS_POST){
            $data['memberID'] = $memberID;
            $data['recruit_id'] = $recruit_id;

            $file = I('post.file');
            $fujian = '';
            if($file){
                foreach ($file as $key => $val) {
                    $fujian .= $val.',';
                }
            }
            $fujian = substr($fujian,0,-1);
            $data['fujian'] =  $fujian;


            $filename = '';
            $fujianname = I('post.filename');
            if($fujianname){

                foreach ($fujianname as $key => $val) {
                    $filename .= $val.',';
                }
            }


            $filename = substr($filename,0,-1);
            $data['filename'] =  $filename;



            $data['title'] = I('post.title');
            $data['content'] = I('post.content');
            $data['company'] = I('post.company');
            $data['addtime'] = date('Y-m-d,H-i:s',time());
            $res = M('notice')->add($data);

            if($res){
                M('resume_cast')->where(array('id'=>$id))->setField('status','1');
                $this->success('通知成功',U('Admin/Job/resume_cast',array('id'=>$recruit_id)));exit;
            }else{
                $this->error('通知失败');exit;
            }



        }
        $this->assign('zp',1);
        $this->display();
    }




    public function delres(){
        $id = intval(I('get.cid'));
        if(empty($id)){
            $del = M('resume_cast')->delete($id);
            if($del){
                $this->success('删除成功',U('Admin/Job/resume_cast',array('id'=>$id)));exit;
            }else{
                $this->error('删除失败');exit;
            }
        }
    }




    public function record(){
        $recruit_id = intval(I('get.id'));
        $action = M('notice');
        $message = $action->where(array('recruit_id'=>$recruit_id))->select();
        $count = count($message);
        foreach ($message as $key =>$vo) {
            $memberinfo = M('myresume')->where(array('memberid'=>$vo['memberid']))->find();    
            $message[$key]['username']  = $memberinfo['username'];
            $message[$key]['mobile']  = $memberinfo['mobile'];
        }

        $this->assign('count',$count);
        $this->assign('message',$message);
        $this->display();

    }


    public function recordDetail(){
        $id = intval(I('get.id'));
        $action = M('notice');
        $message = $action->where(array('id'=>$id))->find();
        $message['content']=str_ireplace('\"','"',htmlspecialchars_decode($message['content']));
   
        if($message['fujian']!=''){
            $file = explode(',',$message['fujian']);
            $file = array_filter($file);

            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $fujianlist[$key]['file'] = $str[$length-1];
                $fujianlist[$key]['fujian'] = $val ;

            } 
        }

        $url = "http://".$_SERVER['HTTP_HOST'];
        $this->assign('url',$url);
        $this->assign('fujianlist',$fujianlist);
        $this->assign('message',$message);
        $this->display();

    }






    public function delcategory(){
        if(IS_ajax){
            $positionId = intval(I('get.cid'));
            $m          = D('positionClass');
            $result     = $m->del_category($positionId);
            if($result){
                $this -> success('删除成功',U('/admin/job/category'));
            }else{
                $this -> error('删除失败',U('/admin/job/category'),2);
            }
        }
    }

    // 关联列表
    public function technology(){
        $m         = D('positionClass');
        $where     = array(
                "parid" => array("gt","0"),
                "isdel" => 0
            );
        // 获取所有的职业列表
        $list  = $m->field("id,classname")->where($where)->order("sequence asc")->select();
        //dump($list);
        // 循环获取所有的关系表
        $tech      = D("technologyClass");
        $posi_tech = D("positionTechnology");
        $tech_all  = $tech->field("id,classname")->where("isdel=0")->order("sequence asc")->select();
        $result    = $tech->get_technology($list);
        $this->assign('category', $result); // 赋值数据集
        $this->assign('urlname','techcategory');
        $this->assign("techList",$tech_all);
        $this->display();
    }

    // 编辑关联表
    public function editTechnology(){
        if(IS_AJAX){
            $techId    = intval(I("post.categoryid"));
            $parid     = intval(I("post.fid"));
            $tpid      = intval(I("post.tpid"));
            $sequence  = I("post.sort");
            $tech_posi = D("positionTechnology");
                //修改关联
            $map2["id"] = $tpid;
            $arr2 = array(
                        "position_id" => $parid,
                        "tech_id"     => $techId
                    );
            $tech_posi -> where($map2) ->save($arr2);



            // 名称，排序修改成功
            $data['info']   =   '修改成功'; // 提示信息内容
            $data['status'] =   1;  // 状态 如果是success是1 error 是0
            $data['url']    =   ''; // 成功或者错误的跳转地址
                
            $this->ajaxReturn($data);
        }
    }

    public function delTechnology(){
        $techId     = intval(I('get.cid'));
        $m          = D('position_technology');
        $map["id"]  = $techId;
        $data["isdel"] = 1;
        $result     = $m->where($map) -> save($data);
        if($result){
            $this -> success('删除成功',U('/admin/job/technology'));
        }else{
            $this -> error('删除失败',U('/admin/job/technology'),2);
        }
    }

    // 添加关联
    public function addTechnology(){
        if(IS_AJAX){
            $techId     = intval(I('post.techId'));
            $positionId = intval(I('post.fid'));
            $sequence   = I('post.sort');

            $m     = D('positionTechnology');
            $map['tech_id'] = $techId;
            $map['position_id'] = $positionId;
            $map['isdel'] = 0;
            $rs = $m->field('id')->where($map)->find();
            // $rs=$PT->checkPT($techId, $positionId);    //判断类名是否重复
            
            if(!$rs){            
                $arr['tech_id']     = $techId;
                $arr['position_id'] = $positionId;
                $arr['sequence']    = $sequence;
                $arr['addtime']     = date("Y-m-d H:i:s",time());
                $rt=$m->add($arr);
                if($rt){
                    $data['info']   =   '添加成功'; // 提示信息内容
                    $data['status'] =   1;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }else{
                    $data['info']   =   '添加失败'; // 提示信息内容
                    $data['status'] =   0;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }

            }else{
                $data['info']   =   '此分类已存在'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }

            $this -> ajaxReturn($data);
            return;
        }
    }


    // 技能列表
    public function techList(){
        $m = D('technologyClass');
        // 获取所有的职业列表
        $where["isdel"] = 0;
        $list      = $m->field("id,classname,sequence")->where($where)->order("sequence asc")->select();
        $this->assign('category', $list); // 赋值数据集
        $this->assign('urlname','techList');
        $this->display();
    }

    public function editTechList(){
        if(IS_AJAX){
            $techId    = I("post.categoryid");
            $sequence  = I("post.sort");
            $classname = I("post.classname");
            $m         = D("technologyClass");
            $res       = $m -> check_tech($classname,$techId);
            if($res === false){
                $data['info']   =   '数据错误，请联系客服'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }elseif($res){
                $data['info']   =   '类名已存在'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }else{
                $arr = array(
                            "classname"  => $classname,
                            "sequence"   => $sequence
                        );
                $map["id"] = $techId;
                $result    = $m->where($map)->save($arr);
                // 修改关联
                if($result){
                    $data['info']   =   '修改成功'; // 提示信息内容
                    $data['status'] =   1;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }else{
                    $data['info']   =   '修改失败'; // 提示信息内容
                    $data['status'] =   0;  // 状态 如果是success是1 error 是0
                    $data['url']    =   ''; // 成功或者错误的跳转地址
                }
            }
            $this->ajaxReturn($data);
        }
    }

    public function delTechList(){
        $techid     = intval(I("get.cid"));
        $m          = D("technologyClass");
        $tech_posi  = M("positionTechnology");
        $map['id']  = $techid;
        $res        = $m -> where($map) -> delete();
        // 删除关联表数据
        $map2["tech_id"] = $techid;
        $data["isdel"] = 1;
        $res2            =  $tech_posi -> where($map2) ->save($data);
        if($res!==false && $res2!==false){
            $this -> success('删除成功',U('/admin/job/techList'));
        }else{
            $this -> error('删除失败',U('/admin/job/techList'),2);
        }
    }

    /**
     * 添加技能
     */
    public function addTechList(){
        if(IS_AJAX){
            $arr['classname'] = $classname = I("post.classname");
            $arr['sequence']  = I("post.sort");
            $m = D("technologyClass");

            $rs = $m->check_tech($classname,0);
            if($rs){
                $data['info']   =   '该技能已存在'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 
                $this->ajaxReturn($data);
            }
            $res = $m -> add($arr);
            if($res){
                $data['info']   =   '添加成功'; // 提示信息内容
                $data['status'] =   1;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }else{
                $data['info']   =   '添加失败'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }
            $this->ajaxReturn($data);
        }
    }
    
    

    public function salary(){
	    header('content-type:text/html;charset=utf-8;');
        $m        = D("recruitment");
        $position = yang_gbk2utf8(I('get.title'));
        $where['position'] = array("like","%".$position."%");
        $where["isdel"]    = 0;

        $company_list = M("company")->where($where)->select();
        $new_c        = array();
        foreach($company_list as $v){
            $new_c[$v['id']] = $v['company_name'];
        }
        $count = $m->where($where)-> count();
        $p     = getpage($count,10);
        $res   = $m->where($where)
                   ->limit($p->firstRow, $p->listRows)
                   ->order("addtime desc")->select();

        $r     = M("resume_cast");
        $c     = M("collection");
        foreach($res as $k=>$v){
            $res[$k]['company_name'] = $new_c[$v['company_id']];
            $res[$k]['resume_nums'] = $r->where(array("recru_id"=>$v['id']))->count();
            $res[$k]['collect_nums'] = $c->where(array("recru_id"=>$v['id']))->count();
        }
        $this->assign("salary",$res);
        $this->assign("count",$count);
        $this->assign("title",$position);
        $this->assign("urlname","salary");
        $this->assign('zp',1);
        $this->assign('page',$p->show());
        $this->display();
    }




   
    public function salaryDetail(){
        $id   = intval(I("id"));
        $res  = M("myresume")->where(array("id"=>$id))->find();
        $res2 = M("myexperience")->where(array("resumeID"=>$res['id']))->order("starttime asc")->select();
        $data["user_info"] = $res;
        // 1.教育背景  2.工作经历
        foreach($res2 as $v){
            if($v['typeid']==1){
                $data["edu_info"][] = $v;
            }else{
                $data["exp_info"][] = $v;
            }
        }
        $this->assign("user", 4);
        $this->assign("cache", $data);
        $this->display();
    }
   


    public function addImage(){
        $data = $this->uploadImg();
        $this->ajaxReturn($data);
    }

    
    public function addImage1(){
        $data = $this->uploadImg1();
        $this->ajaxReturn($data);
    }


    public function addImage2(){
        $data = $this->uploadImg2();
        $this->ajaxReturn($data);
    }



    /*
    *上传附件
    */
    public function addFile(){
        $data = $this->uploadFile();
        $this->ajaxReturn($data);
    }





    //编辑招聘
    public function editSalary(){
        $sa = D("salaryClass");
        $pos = D('positionClass');
        $tec = D('technologyClass');
        $id = intval(I("id"));
        $data = I("post.");
        if(IS_POST){


            $file = I('post.file');
            $fujian = '';
            if($file){
                foreach ($file as $key => $val) {
                    $fujian .= $val.',';
                }
            }
            if(!empty($fujian)){
                $fujian = substr($fujian,0,-1);
                $data['fujian'] = $fujian;
            }


            $filename = '';
            $fujianname = I('post.filename');
            if($fujianname){

                foreach ($fujianname as $key => $val) {
                    $filename .= $val.',';
                }
            }


            $filename = substr($filename,0,-1);
            $data['filename'] =  $filename;





           $where['id'] = $id;
           $m = M("recruitment");
           $res2 = $m->where($where)->save($data);
            if($res2){
                $this->success('修改成功',U('Admin/Job/salary'));

            }else{
                 $this->error('修改成功');
            }
            
        }else{
            $map['id'] =  $id;
            $recu = M("recruitment")->where($map)->find();
            $recu['requirement'] = str_ireplace('\"','"',htmlspecialchars_decode($recu['requirement']));
            $recu['require'] = str_ireplace('\"','"',htmlspecialchars_decode($recu['require']));

            if($recu['fujian']!=''){
                $file = explode(',',$recu['fujian']);
                $file = array_filter($file);

                $filename = explode(',',$recu['filename']);
                $filename = array_filter($filename);




                foreach ($file as $key => $val) {

                    $fujian = $val;
                    $path=parse_url($fujian);

                    $str=explode('/',$path['path']);

                    $length = sizeof($str);

                    $fujianlist[$key]['file'] = $str[$length-1];
                    $fujianlist[$key]['fujian'] = $val;
                    
                } 

                foreach ($filename as $key => $vo) {
                    $fujianlist[$key]['filename'] = $vo;
                } 








            }

            $this->assign("fujianlist",$fujianlist);


            
            $com = M('Company');
            $where['isdel'] = 0;
            $companys = $com->where($where)->select();
            //薪资范围
            $cache = $sa->where(array("isdel"=>0))->order("sequence asc")->select();
            $this->assign("cache",$cache);    //薪资范围
            $this->assign("recu",$recu);
            $this->assign("companys",$companys);    //公司
            $this->assign('zp',1);
            $this->display();
        }

    }


    //添加招聘
    public function addsalary(){
        $sa = D("salaryClass");
        $pos     = D('positionClass');
        $tec = D('technologyClass');
        $data = I('post.');
        $id = intval(I('id'));
        if(!empty($id)){
            if(IS_POST){
                $where['id'] = $id;
                $m = M("recruitment");
                $data['addtime'] = date('Y-m-d H:i:s',time());
                $res = $m->where($where)->save($data);
                if($res){
                    $this->success('添加成功',U('/Admin/Job/salary'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }else{
            if(IS_POST){
                $file = I('post.file');
                $fujian = '';
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }
                $fujian = substr($fujian,0,-1);


                $filename = '';
                $fujianname = I('post.filename');
                if($fujianname){

                    foreach ($fujianname as $key => $val) {
                        $filename .= $val.',';
                    }
                }


                $filename = substr($filename,0,-1);
                $data['filename'] =  $filename;




                $m = M("recruitment");
                $data['addtime'] = date('Y-m-d H:i:s',time());
                $data['fujian'] = $fujian;
                $res = $m->add($data);
                if($res){
                    $this->success('添加成功',U('/Admin/Job/salary'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }
        
        $com = M('Company');
        $where['isdel'] = 0;
        $companys = $com->where($where)->select();
        //dump($companys);
        //薪资范围
        $cache = $sa->where(array("isdel"=>0))->order("sequence asc")->select();
        //职位
        $where = array("isdel"=>0);
        $list  = $pos->where($where)->order("sequence asc")->select();
        $this->assign("cache",$cache);    //薪资范围
        $this->assign("companys",$companys);    //公司
        $this->assign('zp',1);
        $this->display();


    }

    //删除招聘
    public function delSalary(){
        $id = intval(I("cid"));
        $where['id'] = $id;
        $m = D("recruitment");
        $data["isdel"] = 1;
        $res = $m->where($where)->save($data);
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除失败！");
        }
    }


    //招聘审核

    public function changeStatus(){
        if(IS_POST){
            $id = intval(I('id'));
            $where['id'] = $id;
            $m = D("recruitment");
            $data["status"] = 1;
            $res = $m->where($where)->save($data);
            if($res){
                $arrys = array('status'=>1);
            }else{
                $arrys = array('status'=>0);
            }

            echo json_encode($arrys);exit;
        }


    }


    public function salaryRange(){
        $m = D("salaryClass");
        $cache = $m->where(array("isdel"=>0))->order("sequence asc")->select();
        $this->assign("cache",$cache);
        $this->assign("urlname","salaryRange");
        $this->display();
    }


    //编辑薪资范围
    public function editSalaryRange(){
        $id = $_POST['categoryid'];
        $range = $_POST["classname"];
        $squence = $_POST["sort"];
        $m = D("salaryClass");
     
        $data = array(
                "id"       => $id,
                "area" => $range,
                "squence"  => $squence
            );
        $res = $m->save($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "修改成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "修改失败";
        }
        $this->ajaxReturn($info);


    }


    //添加薪资范围
    public function addsalaryRange(){
        $area = $_POST["classname"];
        $sequence = $_POST["sort"]?$_POST["sort"]:0;
        $m = D("salaryClass");
   
        $data = array(
                "area" => $area,
                "sequence"  => $sequence
            );
        $res = $m->add($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "添加成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "添加失败";
        }
        $this->ajaxReturn($info);
    }

    //删除薪资范围
    public function delSalaryRange(){
        $id = intval(I("id"));
        $map['id'] = $id;
        $data["isdel"] = 1;
        $res = D("salaryClass")->where($map)->save($data);
        if($res){
            $this->success();
        }else{
            $this->error();
        }
    }

    // 以下是简历
    public function resume(){
        $realname = I('realname');
        if(!empty($realname)){
            $where['realname'] = $realname;
        }
        $m = D("resume");
        $res = $m->alias('r')
                 ->field('r.*,u.realname')
                 ->join('uha_user u on u.id=r.userid')
                 ->where($where)
                 ->select();
        $count = count($res);
        $p = getpage($count, 12);
        $resumes = $m->alias('r')
                 ->field('r.*,u.realname')
                 ->join('uha_user u on u.id=r.userid')
                 ->where($where)
                 ->limit($p->firstRow, $p->listRows)
                 ->select();
        
        $recru = M('recruitment');
        foreach ($resumes as $k=>$v){
            $resumes[$k]['company_id'] = $recru->where(array('id'=>$v['recru_id']))->getField('company_id');
        }
      
        $this->assign("resumes",$resumes);
        $this->assign("count",$count);
        $this->assign("page",$p->show());
        $this->assign('zp',2);
        $this->display();
    }
    
    public function seejianli(){
        //将简历的状态更改为已查看
        $id = intval(I('id'));
        $companyid = intval(I('company_id'));
        $status = I('status');
        $resume = M('resume');
        if(!empty($status)){
            $resume->where(array('id'=>$id))->setField('status',$status);
        }
     
        $userid = 55;
        $log = M('company_interview_log');
        $data['companyid'] = $companyid;
        $data['memberID'] = $userid;
        $data['status'] = $status;
        $data['addtime'] = time();
        $log->add($data);
        $where['memberID'] = $userid;
        $resu = M('myresume');
        $info = $resu->where($where)->find();//基本信息
 
        $qt = M('myexperience');
        $educs = $qt->where(array('typeID'=>1,'memberID'=>$userid))->select();//教育背景
        $exec= $qt->where(array('typeID'=>2,'memberID'=>$userid))->select();//经验
        $this->assign('info',$info);
        $this->assign('educ',$educs);
        $this->assign('exec',$exec);
        $this->assign('zp',2);
        $this->display();
    }
    
    /**
     * 是否可以面试
     */
    public function upstatus(){
        $id = intval(I('id'));
        $companyid = intval(I('companyid'));
        $status = I('status');
        $resume = M('resume');
        $userid = intval(I('userid'));
        if(!empty($status)){
            $resume->where(array('id'=>$id))->setField('status',$status);
        }
        $inter = M('company_interview_log');
        $where['company_id'] = $companyid;
        $where['userid'] = $userid;
        $data['status'] = $status;
        $res = $inter->where($where)->setField('status',$status);
        if($res){
            echo 1;
        }else{
            echo 0;
        }
        
    }
    
    //上传简历文档
    public function uploaddoc(){
        $m = M("recruitment");
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('docx', 'doc');// 设置附件上传类型
        $upload->savePath =  '../Uploads/upfiles/';// 设置附件上传目录
        $res = $upload->upload();
        if(!res) {// 上传错误提示错误信息
            echo '上传失败';
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
            $path = $res['file']['savepath'].$res['file']['savename'];
            $data['fujian'] = $path;
            $result = $m->add($data);
            echo $result;
          
        }
    
    }
    
    /**
     * 修改简历
     */
    public function eidtuploaddoc(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('docx', 'doc','pdf');// 设置附件上传类型
        $upload->savePath =  '../Uploads/upfiles/';// 设置附件上传目录
        $res = $upload->upload();
        if(!res) {// 上传错误提示错误信息
            echo '上传失败';
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
    
            $path = $res['file']['savepath'].$res['file']['savename'];
            echo $path;
      
        }
    
    }
    
    //下载简历
    public function downjianli(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $jianli = M('resume');
        $res = $jianli->field('jianli')->where($where)->select();
    
        $jipath = $res[0]['jianli'];
     
        if(!$jipath) header("localhost/");
        if(!isset($jipath)){
            echo '500';
        }
        if(!file_exists($jipath)){ //检查文件是否存在
    
            echo '404';
        }
        $file_name=basename($jipath);
        $file_type=explode('.',$jipath);
        $file_type=$file_type[count($file_type)-1];
        $file_type=fopen($jipath,'r'); //打开文件
        //输入文件标签
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".filesize($jipath));
        header("Content-Disposition: attachment; filename=".$file_name);
        //输出文件内容
        echo fread($file_type,filesize($jipath));
        fclose($file_type);
    
    }
    
    //删除简历
    public function deljianli(){
        $id = intval(I('id'));
        $where['id'] = $id;
        $jianli = M('resume');
        $info = $jianli->where($where)->find();
        $path= $info['jianli'];
        $filessrc=str_replace(__ROOT__.'/', '', str_replace('//', '/', $path));
        if (file_exists($filessrc)){
            unlink($filessrc);
        }
        $jianli->startTrans();
        $res = $jianli->where($where)->delete();
         
        if($res){
            $jianli->commit();
            echo 1;
        }else{
            $jianli->rollback();
            echo  2;
        }
    }

    // 删除简历
    public function delResume(){
        $id = intval(I("id"));
        $m  = M("resume");
        $res = $m->where(array("id"=>$id))->setField(array("isdel"=>1));
        if($res){
            $this->success();
        }else{
            $this->error();
        }
    }
    
    

    
    public function doEditExperience(){
        if(IF_AJAX){
            $data = I("post.");
            $m = M("experience");
            $res = $m->save($data);
            if($res){
                $info = array(
                        "status" => 1,
                        "info"   => "修改成功"
                    );
                $this->ajaxReturn($info);
            }else{
                $info = array(
                        "status" => 0,
                        "info"   => "修改失败"
                    );
                $this->ajaxReturn($info);
            }
        }

    }

    public function doEditProject(){
        if(IF_AJAX){
            $data = I("post.");
            $m = M("project");
            $res = $m->save($data);
            if($res){
                $info = array(
                        "status" => 1,
                        "info"   => "修改成功"
                    );
                $this->ajaxReturn($info);
            }else{
                $info = array(
                        "status" => 0,
                        "info"   => "修改失败"
                    );
                $this->ajaxReturn($info);
            }
        }

    }

    public function doEditEducation(){
        if(IF_AJAX){
            $data = I("post.");
            $m = M("education");
            $res = $m->save($data);
            if($res){
                $info = array(
                        "status" => 1,
                        "info"   => "修改成功"
                    );
                $this->ajaxReturn($info);
            }else{
                $info = array(
                        "status" => 0,
                        "info"   => "修改失败"
                    );
                $this->ajaxReturn($info);
            }
        }

    }



}