<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class CompanyController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",7);
    }

    // 公司列表
    /**
     * 11-15 11：17
     * 修改文件
     */
    public function index(){
		header('content-type:text/html;charset=utf-8;');
        $title = yang_gbk2utf8(I('title'));
        $C_m   = D("Company");
        $CC_m  = D("CompanyClass");
        $where['company_name'] = array("like","%$title%");
        $where['isdel'] = 0;
        $where['cate']  = 0;
        $count = $C_m->where($where)-> count();
        $p     = getpage($count,10);
        $companys = $C_m->where($where) ->limit($p->firstRow, $p->listRows) ->select();
        $count  = $C_m->where($where)->count();
        $cclass = $CC_m->where("isdel=0")->select();
        foreach ($cclass as $k=>$v){
            $arr[$v["id"]] = $v;
        }
        foreach ($companys as $k =>$v){
            $companys[$k]['type'] = $arr[$v['type']]['classname'];
           
        }
        $this->assign("company",$companys);
        $this->assign("title",$title);
        $this->assign("count",$count);
        $this->assign("count",$count);
        $this->assign('page',$p->show());
        $this->assign("comptype",0);
        $this->assign('user',1);
        $this->display();
    }
	
	
	
	
	public function time(){
		$cache = M('time')->find();
		if(IS_POST){
			$id = intval(I('post.id'));
			$data['time'] =I('post.time');
			if($id){
				
				$result = M('time')->where(array('id'=>$cache['id']))->save($data);
			}else{
				$result = M('time')->add($data);
			}
			
			if($result){
				$this->success('设置成功！',U('Admin/company/time'));exit;

			}else{
				$this->success('设置成功！',U('Admin/company/time'));exit;
			}
		}
		
	    $this->assign('cache',$cache);
		$this->display();
	}
	
	
	
	
	
	
	
    // 公司列表
    /**
     * 11-15 11：17
     * 修改文件
     */
    public function company(){
        $title = I('title');
        $C_m   = D("Company");
        $CC_m  = D("CompanyClass");
        $where['company_name'] = array("like","%$title%");
        $where['isdel'] = 0;
        $where['cate']  = 1;
        $companys = $C_m->where($where)->select();
        $count  = $C_m->where($where)->count();
        $cclass = $CC_m->where("isdel=0")->select();
        foreach ($cclass as $k=>$v){
            $arr[$v["id"]] = $v;
        }
        foreach ($companys as $k =>$v){
            $companys[$k]['type'] = $arr[$v['type']]['classname'];
           
        }

        $this->assign("company",$companys);
        $this->assign("title",$title);
        $this->assign("count",$count);
        $this->assign("comptype",0);
        $this->assign('com',5);
        $this->display();
    }

    // 公司详情
    public function companydetail(){
        $companyId = intval(I("id"));
        $c_m = D("Company");
        $CC_m = D("CompanyClass");
        $where['id'] = $companyId;
        $where['isdel'] = 0;
        $cache = $c_m -> where($where) -> find();
        $cache["type"] = $CC_m -> where("id=$cache[type] and isdel=0") ->getField("classname");
        $this->assign("cache",$cache);
        $this->assign("about",4);
        $this->display();
    }

	
    /**
     * 批量导入用户名
    */
    public function piliangdaoru(){

       if(IS_POST){
        $filetmpname = $_FILES['excel']['tmp_name'];

        $file_types = explode ( ".", $_FILES ['excel'] ['name'] );
        $file_type = $file_types [count ( $file_types ) - 1];

        $url = U('Admin/Company/piliangdaoru');

    
         /*判别是不是.xls文件，判别是不是excel文件*/
        if (strtolower ( $file_type ) != "xls"){
            echo "不是Excel文件，重新上传";die;
        }


        import('Org.Util.PHPExcel');
        $objPHPExcel = \PHPExcel_IOFactory::load($filetmpname);
        $arrExcel = $objPHPExcel->getSheet(0)->toArray();
    
        //删除不要的表头部分，我的有三行不要的，删除三次
        $first_line = $arrExcel[0];
       
        if(
            $first_line[0] != "用户名" || 
            $first_line[1] != "公司名称"   
           
        ){
            echo "<script>alert('excel表字段信息不正确!');</script>";
        }
        array_shift($arrExcel);
   
        $m = M("company");
        $error = "";
        foreach($arrExcel as $v){
            
            $count = $m->where(array("company_name"=>$v[1]))->count();
            if($count<=0){
                echo "<script>alert(".$v['1']."不存在)</script>";
            }
            $data = array(
                    "username"  => $v[0]
                );
          
            $where['company_name'] = $v[1];
          
            $res = $m->where($where)->save($data);
            if($res){
                echo "<script>alert(".$data['username']."导入成功)</script>"; 
            }else{
                echo "<script>alert(".$data['username']."导入失败)</script>"; 
            }
        }
       
       }
        $this->display();
     
    }  





    public function exportExcel(){
        $M_Company = M("Company");
		$companyList = $M_Company->where('cate=0 and isdel=0')->select();
		
        foreach($companyList as $k=>$v){
            $data[$k]['username']   = $v['username'];
			$data[$k]['company_name'] = $v['company_name'];      
        }
		
        $filename = date("YmdHis", time())."-公司信息";
        $title = array('用户名','公司名称');
        $this->export($data,$title,$filename);
    }

	
    /**
     * 导出数据为excel表格
     *@param $data    一个二维数组,结构如同从数据库查出来的数组
     *@param $title   excel的第一行标题,一个数组,如果为空则没有标题
     *@param $filename 下载的文件名
     *@examlpe
     *$stu = M ('User');
     *$arr = $stu -> select();
     *exportexcel($arr,array('id','账户','密码','昵称'),'文件名!');
     */
    private function export($data = array(), $title = array(), $filename = 'report') {
        header("Content-type:application/octet-stream");
        header("Accept-Ranges:bytes");
        header("Content-type:application/vnd.ms-excel");
        header("Content-Disposition:attachment;filename=" . $filename . ".xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        //导出xls 开始
        if (!empty($title)) {
            foreach ($title as $k => $v) {
                $title[$k] = iconv("UTF-8", "GB2312", $v);
            }
            $title = implode("\t", $title);
            echo "$title\n";
        }
        if (!empty($data)) {
            foreach ($data as $key => $val) {
                foreach ($val as $ck => $cv) {
                    $data[$key][$ck] = iconv("UTF-8", "GB2312", $cv);
                }
                $data[$key] = implode("\t", $data[$key]);

            }
            echo implode("\n", $data);
        }

    }




    /*
   *分公司多选删除
   */
    public function comalldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('Company')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }



     /*
   *公司多选删除
   */
    public function alldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('Company')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }




    /*
   *公司类型多选删除
   */
    public function catealldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('CompanyClass')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }






    // 公司类型列表
    /**
     * 11-15 11：17
     * 修改文件
     */
    public function catelist(){
        $m = D("companyClass");
        $map["isdel"] = 0;
        $cache = $m -> order("id asc,sequence asc")-> where($map) -> select();
        $this->assign("cache",$cache);
        $this->assign('user',2);
        $this->display();
    }

    // 添加公司类型
    public function addCate(){
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $data = array(
                "classname" => $classname,
                "sequence"  => $sequence
            );
        $m = D("companyClass");
        // 检测是否重复
        $is_repeat = $m -> check_repeat($classname);
        if($is_repeat){
            $info["info"] = "类名已存在！";
            $info["status"] = 0;
            $info["url"] = "";
        }else{
            $res = $m -> add($data);
            if($res){
                $info["info"] = "添加成功";
                $info["status"] = 1;
                $info["url"] = "";
            }else{
                $info["info"] = "添加失败";
                $info["status"] = 0;
                $info["url"] = "";
            }
        }
        $this->ajaxReturn($info);
    }
    // 编辑公司类型
    public function editCate(){
        $id = intval(I("categoryid"));
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $m = D("companyClass");
        if($id){
            $where = array(
                    "id"        => $id,
                    "classname" => $classname,
                    "sequence"  => $sequence
                );
            // 检测是否重复
            $is_repeat = $m -> check_repeat($classname,$id);
            if($is_repeat){
                $info["info"] = "类名已存在！";
                $info["status"] = 0;
                $info["url"] = "";
            }else{
                $res = $m -> save($where);
                if($res !== false){
                    $info["status"] = 1;
                    $info["info"] = "修改成功";
                    $info["url"] = "";
                }else{
                    $info["status"] = 0;
                    $info["info"] = "修改失败";
                    $info["url"] = "";
                }
            }
            $this->ajaxReturn($info);
        }
    }
    // 删除公司类型
    public function delcate(){
        $id = intval(I("cid"));
        $where['id'] = $id;
        $m = D("companyClass");
        $data["isdel"] = 1;
        $res = $m->where($where)->save($data);
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }
    }

    // 公司福利列表
    public function labellist(){
        $m = D("label");
        $map["isdel"] = 0;
        $res = $m->order("sequence asc")->where($map)->select();
        $this->assign("cache",$res);
        $this->assign("comptype",2);
        $this->display();
    }

    // 编辑福利
    public function editLabel(){
        $id = intval(I("categoryid"));
        $labelname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        if($id){
            // 查重
            $m = D("label");
            $is_repeat = $m -> check_repeat($labelname,$id);
            if($is_repeat){
                $info["status"] = 0;
                $info["info"] = "该福利已存在";
                $info["url"] = "";
            }else{
                $data = array(
                        "labelname" => $labelname,
                        "sequence"  => $sequence
                    );
                $res = $m->where("id=$id")->save($data);
                if($res){
                    $info["status"] = 1;
                    $info["info"] = "修改成功";
                    $info["url"] = "";
                }else{
                    $info["status"] = 0;
                    $info["info"] = "修改失败";
                    $info["url"] = "";
                }
            }
            $this->ajaxReturn($info);
        }
    }

    // 添加福利
    public function addLabel(){
        $labelname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $data = array(
                "labelname" => $labelname,
                "sequence"  => $sequence
            );
        $m = D("label");
        // 检测是否重复
        $is_repeat = $m -> check_repeat($classname);
        if($is_repeat){
            $info["info"] = "该福利已存在";
            $info["status"] = 0;
            $info["url"] = "";
        }else{
            $res = $m -> add($data);
            if($res){
                $info["info"] = "添加成功";
                $info["status"] = 1;
                $info["url"] = "";
            }else{
                $info["info"] = "添加失败";
                $info["status"] = 0;
                $info["url"] = "";
            }
        }
        $this->ajaxReturn($info);
    }
    // 删除公司福利
    public function delLabel(){
        $id = intval(I("cid"));
        $where['id'] = $id;
        $m = D("label");
        $data["isdel"] = 1;
        $res = $m->where($where)->save($data);
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }
    }

    // 增加认证公司账号
    public function hrlist(){
        $m = D("member");
        $map['type'] = $map2['type'] = $map3['type'] = 1;
        $map2["status"] =0;
        $map3["status"] = 1;
        $map["isdel"] = 0;
        $cache = $m->getHr();
        $count = $m->where($map)->count();
        $count1 = $m->where($map2)->count();
        $count2 = $m->where($map3)->count();
        // $status_arr = array("冻结","已开通");
        // 得到companyclass
        $compClass = M("companyClass")->where(array("isdel"=>0))->field("id,classname")->select();
        foreach($compClass as $k=>$v){
            $arr[$v["id"]] = $v['classname'];
        }
        foreach($cache["cache"] as $k=>$v){
            $cache["cache"][$k]["type"] = $arr[$v["type"]];
            
        }
        $this->assign("count",$count);
        $this->assign("count1",$count1);
        $this->assign("count2",$count2);
        $this->assign("title",I("title"));
        $this->assign("cache",$cache["cache"]);
        $this->assign("page",$cache["page"]);
        $this->assign("comptype",3);
        $this->display();
    }
    // 冻结/解冻
    public function changeStatus(){
        if(IS_AJAX){
            $id = intval(I("id"));
            $m = M("member");
            $res = $m->where("id=$id")->field("id,status")->find();
            if($res){
                $res['status'] = $res['status']==1?0:1;
                $res2 = $m->save($res);
                if($res2){
                    $arr = array("已认证","未认证");
                    $return = array(
                        "status" => 1,
                        "info" => $arr[$res['status']]
                    );
                }else{
                    $return = array(
                        "status" => 0
                    );
                }
            }else{
                $return = array(
                    "status" => 2
                );
            }
           $this->ajaxReturn($return);
        }
    }
    // 增加认证公司账号
    public function createhr(){
        if(IS_AJAX){
            $data = I("post.");
            if(!preg_match("/^1[34578]{1}\d{9}$/",$data["telephone"])){  
                $result = array(
                        "status"  => 0,
                        "info"    => "手机格式不正确"
                    ); 
                $this->ajaxReturn($result);
            } 
            if($data["url"] && !preg_match("/^(http|https):\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is",$data["url"])){  
                $result = array(
                        "status"  => 0,
                        "info"    => "网址格式不正确，请以http://或https://开始"
                    ); 
                $this->ajaxReturn($result);
            } 
            // 查重用户名查重
            $m_cf = M("member")->where(array("telephone"=>$data["telephone"],"isdel"=>0))->find();
            if($m_cf===false){
                $result = array(
                        "status"  => 0,
                        "info"    => "操作member失败"
                    );
                $this->ajaxReturn($result);
            }elseif($m_cf){
                $result = array(
                        "status"  => 0,
                        "info"    => "已有该用户"
                    );
                $this->ajaxReturn($result);
            }
            // 查重公司名查重
            $c_cf = M("company")->where(array("company_name"=>$data["company_name"],"isdel"=>0))->find();
            if($c_cf===false){
                $result = array(
                        "status"  => 0,
                        "info"    => "操作company失败"
                    );
                $this->ajaxReturn($result);
            }elseif($c_cf){
                $result = array(
                        "status"  => 0,
                        "info"    => "已有该公司"
                    );
                $this->ajaxReturn($result);
            }
            $company_data = array(
                    "company_name" => $data["company_name"],
                    "url"          => $data["url"],
                    "addtime"      => Gettime()
                );
            $c_res = M("company")->add($company_data);
            if($c_res){
                $m_data = array(
                        "companyid"  => $c_res,
                        "telephone"  => $data["telephone"],
                        "password"   => md5($data["password"]),
                        "type"       => 1,
                        "status"     => 1,
                        "addtime"    => Gettime()
                    );
                $m_res = M("member")->add($m_data);
                if($m_res){
                    $result = array(
                            "status"  => 1,
                            "info"    => "创建成功"
                        );
                }else{
                    M("company")->where(array("id"=>$c_res))->delete();
                }
            }else{
                $result = array(
                        "status"  => 0,
                        "info"    => "创建失败"
                    );
            }
            $this->ajaxReturn($result);
        }
        $this->assign("comptype",4);
        $this->display();
    }

    public function edithr(){
        if(IS_AJAX){
            $data = I("post.");
            if(!preg_match("/^1[34578]{1}\d{9}$/",$data["telephone"])){  
                $result = array(
                        "status"  => 0,
                        "info"    => "手机格式不正确"
                    ); 
                $this->ajaxReturn($result);
            } 
            if($data["url"] && !preg_match("/^(http|https):\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is",$data["url"])){  
                $result = array(
                        "status"  => 0,
                        "info"    => "网址格式不正确，请以http://或https://开始"
                    ); 
                $this->ajaxReturn($result);
            } 
            // 查重用户名查重
            $map1 = array(
                    "id"        =>array("neq",$data["id"]),
                    "telephone" =>$data["telephone"],
                    "isdel"     =>0
                );
            $m_cf = M("member")->where($map1)->find();
            if($m_cf===false){
                $result = array(
                        "status"  => 0,
                        "info"    => "操作member失败"
                    );
                $this->ajaxReturn($result);
            }elseif($m_cf){
                $result = array(
                        "status"  => 0,
                        "info"    => "已有该手机号"
                    );
                $this->ajaxReturn($result);
            }
            $m_data = array(
                    "id"         => $data["id"],
                    "telephone"  => $data["telephone"],
                    "type"       => 1,
                    "status"     => 1
                );
            if(!empty($data["password"])){
                $m_data["password"] = md5($data["password"]);
            }
            $c_id  = M("member")->where(array("id"=>$data["id"]))->getField("companyid");
            if(!$c_id){
                $result = array(
                        "status"  => 0,
                        "info"    => "该hr不是有效hr"
                    );
                $this->ajaxReturn($result);
            }
            // 查重公司名查重
            $map2 = array(
                    "id"            => array("neq",$c_id),
                    "company_name"  => $data["company_name"],
                    "isdel"         => 0
                );
            $c_cf = M("company")->where($map2)->find();
            if($c_cf===false){
                $result = array(
                        "status"  => 0,
                        "info"    => "操作company失败"
                    );
                $this->ajaxReturn($result);
            }elseif($c_cf){
                $result = array(
                        "status"  => 0,
                        "info"    => "已有该公司名"
                    );
                $this->ajaxReturn($result);
            }
            $m_res = M("member")->save($m_data);
            if($m_res){
                $company_data = array(
                        "id"           => $c_id,
                        "company_name" => $data["company_name"],
                        "url"          => $data["url"]
                    );
                $c_res = M("company")->where(array("id"=>$c_id))->save($company_data);
                if($m_res){
                    $result = array(
                            "status"  => 1,
                            "info"    => "修改成功"
                        );
                }else{
                    $result = array(
                            "status"  => 0,
                            "info"    => "修改失败"
                        );
                }
            }else{
                $result = array(
                        "status"  => 0,
                        "info"    => "修改失败"
                    );
            }
            $this->ajaxReturn($result);
        }
    }

    // 增加公司
    public function addCompany(){
        if(IS_POST){
            unset($_POST["id"]);
            $m = M("company");
            // 上传图片
            $data = I("post.");
            $data['info_img'] = I("post.pic");
			
            $data["addtime"] = Gettime();
			
            $res = $m->add($data);
            if($res){
                $this->success('添加成功',U('/Admin/Company/index'));
            }else{
                $this->error('添加失败');
            }
        }else{
            $companyClass = M("companyClass")->where(array("isdel"=>0))->field("id,classname")->order("id asc,sequence desc")->select();
            $this->assign("cate", 0);
            $this->assign("title","添加公司");
            $this->assign("companyClass",$companyClass);
            $this->assign("comptype",0);
            $this->assign('about',4);
            $this->display();
        }
    }



    // 增加公司
    public function addCompany2(){
        if(IS_POST){
            unset($_POST["id"]);
            $m = M("company");
            // 上传图片
            $data = I("post.");
            if ($_FILES) {
              foreach ($_FILES as $key=>$file) {
                if ($file['error']==0) {
                  # 配置上传目录
                  $cfg=array(
                    'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
                    );
                  $up=new \Think\Upload($cfg);
                  $move=$up->uploadOne($_FILES[$key]);
                  $picPath=$up->rootPath.$move['savepath'].$move['savename'];
                  $data[$key]="/".trim(trim($picPath,"."),"/");
                }
              }
            }
            $data["addtime"] = Gettime();
            $res = $m->add($data);
            if($res){
                $this->success('添加成功',U('/Admin/Company/company'));
            }else{
                $this->error('添加失败');
            }
        }else{
            $companyClass = M("companyClass")->where(array("isdel"=>0))->field("id,classname")->order("sequence desc")->select();
            $this->assign("cate", 1);
            $this->assign("title","添加公司");
            $this->assign("companyClass",$companyClass);
            $this->assign("comptype",0);
            $this->assign('com',5);
            $this->display();
        }
    }


    // 修改公司
    public function editcompany(){
        $id = intval(I("id"));
        if(IS_POST){
            $m = M("company");
            // 上传图片
            $data = I("post.");
            $pic = I("post.pic");
            $data['info_img'] =  $pic;
            $data["addtime"] = Gettime();
			
            if($data['password']){
                $data['password'] = md5($data['password']);
            }else{
                unset($data['password']);
            }
            $res = $m->where(array("id"=>$id,"isdel"=>0))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Company/editCompany',array('id'=>$id)));
            }else{
                $this->success('编辑成功');
            }
        }else{
            $companyClass = M("companyClass")->where(array("isdel"=>0))->field("id,classname")->order("id asc,sequence desc")->select();
            $cache = M("company")->where(array("id"=>$id,"isdel"=>0))->find();
            $this->assign("title","修改公司");
            $this->assign("companyClass",$companyClass);
            $this->assign("cache",$cache);
            $this->assign("comptype",0);
            $this->assign('about',4);
            $this->display("addCompany");
        }
    }



        // 修改公司
    public function editcompany2(){
        $id = intval(I("id"));
        if(IS_POST){
            $m = M("company");
            // 上传图片
            $data = I("post.");
            if ($_FILES) {
              foreach ($_FILES as $key=>$file) {
                if ($file['error']==0) {
                  # 配置上传目录
                  $cfg=array(
                    'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
                    );
                  $up=new \Think\Upload($cfg);
                  $move=$up->uploadOne($_FILES[$key]);
                  $picPath=$up->rootPath.$move['savepath'].$move['savename'];
                  $data[$key]="/".trim(trim($picPath,"."),"/");
                }
              }
            }
            $data["addtime"] = Gettime();
            if($data['password']){
                $data['password'] = md5($data['password']);
            }else{
                unset($data['password']);
            }
            $res = $m->where(array("id"=>$id,"isdel"=>0))->save($data);
            if($res){
                $this->success('编辑成功',U('/Admin/Company/editCompany2',array('id'=>$id)));
            }else{
                $this->success('编辑失败');
            }
        }else{
            $companyClass = M("companyClass")->where(array("isdel"=>0))->field("id,classname")->order("sequence desc")->select();
            $cache = M("company")->where(array("id"=>$id,"isdel"=>0))->find();
            $this->assign("title","修改公司");
            $this->assign("companyClass",$companyClass);
            $this->assign("cache",$cache);
            $this->assign("comptype",0);
            $this->assign('com',5);
            $this->display("addCompany2");
        }
    }






    // 删除公司
    public function delCompany(){
        $id = intval(I("id"));
        $res = M("company")->where(array("id"=>$id))->setField(array("isdel"=>1));
        if($res){
            $this->success('删除成功',U('/Admin/Company/index'));
        }else{
            $this->error('删除失败');
        }
    }

    // 分发账号，公司验证过后的账号
    /*
    业务逻辑：
        Company表：     
		username   为公司名称大小写+id
		password   公司账号的登录密码
        获取公司简拼的方法  makeSimpleLetter(公司名称);
        @param ids要生成账号密码的公司id，以 _ 拼接
    */
    public function createCompanyAccount(){
        if(IS_AJAX){
            $ids  = I("ids");
            $pass = I("pass");
            if(!$pass){
                $this->ajaxReturn(array("status"=>0 ,"info"=>"请输入要生成的密码"));
            }
            $ids = trim($ids, "_");
            $ids_arr = explode("_", $ids);
            if(empty($ids_arr)){
                $this->ajaxReturn(array("status"=>0 ,"info"=>"无效的公司"));
            }
            $m = M("company");
            $error_str = "";
            foreach($ids_arr as $v){
                $res = $m->where(array("id"=>$v))->find();
                if(!$res['company_name']){
                    $this->ajaxReturn(array("status"=>0 ,"info"=>"无效的公司"));
                }
                if($res['username']){
                    $error_str .= $res['company_name'].",";
                    continue;
                }
                $data = makeUsernamePass($res['company_name'], $pass, $v);
                $res1 = $m->where(array('id'=>$v))->save($data);
                if(!$res1){
                    $error_str .= $res['company_name'].",";
                }
            }
            $error_str = trim($error_str,",");
            if($error_str){
                $this->ajaxReturn(array("status"=>1, "info"=>"以下公司生成失败：$error_str"));
            }else{
                $this->ajaxReturn(array("status"=>1, "info"=>"生成成功！"));
            }
        }
    }

    /**
     * 员工管理模块
     *      员工是指：公司所属的员工
     */
    public function staffManage(){
        $this->assign("user",3);
        $this->display();
    }

    /**
     * 普通用户管理模块
     *      普通用户是指：进入页面的求职者
     *      表：member
     */
    public function consumerManage(){
		header('content-type:text/html;charset=utf-8;'); 
        $res   = D("member")->getmemberlist();
        $count = M("member")->count();
        $cache = $res['list'];
        $page  = $res['page'];
        $this->assign("cache", $cache);
        $this->assign("page", $page);
        $this->assign("count", $count);
        $this->assign("title", I("title"));
        $this->assign("user",4);
        $this->display();
    }
	
	//简历投递记录
	
	public function resume_detail(){
		$memberid = intval(I('get.id'));
		$company_name = I('get.company');
		$title = I('get.title');
		if($company_name!=''){
			$map['uha_company.company_name'] = array('like','%'.$company_name.'%');
		}
		
		if($title!=''){
			$map['uha_recruitment.position'] = array('like','%'.$title.'%');
		}
		
		$M = M('resume_cast');
		$map['uha_resume_cast.userid'] = $memberid;

		$count = $M->where($map)->count();
		$info = $M->where($map)
		      ->join("left join uha_recruitment ON uha_recruitment.id = uha_resume_cast.recru_id")
			  ->join("left join uha_company ON uha_company.id = uha_recruitment.company_id")
			  ->order('uha_resume_cast.addtime desc')
			  ->field('uha_resume_cast.addtime,uha_resume_cast.status,uha_recruitment.position,uha_company.company_name')->select();

        $this->assign("info",$info);
		$this->assign("count",$count);
		$this->display();
		
	}
	
	
	
	
	

    /**
     * 普通用户资料详情
     * 
     */
    public function consumerDetail(){
        $id  = intval(I("id"));
        $res = M("member")->where(array('id'=>$id))->find();
        $count1 = M("resume_cast")->where(array("userid"=>$id))->count();
        $count2 = M("collection")->where(array("userid"=>$id))->count();
        $this->assign("count1", $count1);
        $this->assign("count2", $count2);
        $this->assign("user", 4);
        $this->assign("cache", $res);
        $this->display();
    }


    /**
     * excel导入公司
     *
     */
    public function uploadExcel1(){
     
        $filetmpname = $_FILES['excel']['tmp_name'];
        import('Org.Util.PHPExcel');
        $objPHPExcel = \PHPExcel_IOFactory::load($filetmpname);

        $arrExcel = $objPHPExcel->getSheet(0)->toArray();
        //删除不要的表头部分，我的有三行不要的，删除三次
        $first_line = $arrExcel[0];
       
        if(
            $first_line[0] != "company_name" || 
            $first_line[1] != "type"         || 
            $first_line[2] != "people"       || 
            $first_line[3] != "address"      || 
            $first_line[4] != "tel"          || 
            $first_line[5] != "email"        || 
            $first_line[6] != "company_type" || 
            $first_line[7] != "url"          ||
            $first_line[8] != "content"      ||
            $first_line[9] != "identify" 
        ){
            echo "excel表字段信息不正确!";die;
        }
        array_shift($arrExcel);
        $m = M("Company");
        $type = M("CompanyClass")->where(array("isdel"=>0))->select();

        $new_type = array();
        foreach($type as $v){
            $new_type[$v['sign']] = $v['id'];
        }
        $error = "";
        foreach($arrExcel as $v){
            if($m->where(array("company_name"=>$v[0]))->count()){
                echo "$v[0]  <b style='color:red'>已存在！</b><br>";continue;
            }
            $data = array(
                    "company_name"  => $v[0],
                    "type"          => $new_type[$v[1]],
                    "people"        => $v[2],
                    "address"       => $v[3],
                    "company_type"  => $v[4],
                    "cate"          => 0,
                  
                );
            $res = $m->add($data);
            if($res){
                $id = $m->getLastInsID();
              
                $account = makeUsernamePass($data['company_name'], 1, $id);
                // 密码与账号一样
                $account["password"] = md5($account['username']);
                $res1 = $m->where(array('id'=>$id))->save($account);
                if(!$res1){
                    echo $data['company_name']."导入<b style='color:red'>失败！</b><br>";
                }else{
                    echo $data['company_name']."导入<b style='color:green'>成功！</b><br>";
                }
            }else{
                echo $data['company_name']."导入<b style='color:red'>失败！</b><br>";
            }
        }
        echo "公司导入完成!<br>";
        echo "<a href='".U("Admin/Company/index")."'>返回</a>";
    }  
	
	
	 /**
     * excel导入公司
     *
     */
    public function uploadExcel(){
     
        $filetmpname = $_FILES['excel']['tmp_name'];
        import('Org.Util.PHPExcel');
        $objPHPExcel = \PHPExcel_IOFactory::load($filetmpname);

        $arrExcel = $objPHPExcel->getSheet(0)->toArray();
        //删除不要的表头部分，我的有三行不要的，删除三次
        $first_line = $arrExcel[0];
       
        if(
            $first_line[0] != "公司名称" || 
            $first_line[1] != "所属行业" || 
            $first_line[2] != "公司人数"       || 
            $first_line[3] != "公司地址"      || 
            $first_line[4] != "电话"          || 
            $first_line[5] != "邮箱"        || 
            $first_line[6] != "企业类型" || 
            $first_line[7] != "公司介绍"
          
        ){
            echo "excel表字段信息不正确!";die;
        }
        array_shift($arrExcel);
        $m = M("Company");
       // $type = M("CompanyClass")->where(array("isdel"=>0))->select();

       // $new_type = array();
      //  foreach($type as $v){
         //   $new_type[$v['sign']] = $v['id'];
      //  }
	  
	  
	    $new_type = array(
		    '农、林、牧、渔业'=>1,
		    '采矿业'=>2,
		    '制造业'=>3,
		    '电力、热力、燃气及水生产和供应业'=>4,
		    '建筑业'=>5,
		    '批发和零售业'=>6,
		    '交通运输、仓储和邮政业'=>7,
		    '住宿和餐饮业'=>8,
		    '信息传输、软件和信息技术服务业'=>9,
		    '金融业'=>10,
		    '房地产业'=>11,
		    '租赁和商务服务业'=>12,
		    '科学研究和技术服务业'=>13,
		    '水利、环境和公共设施管理业'=>14,
			'居民服务、修理和其他服务业'=>15,
			'教育'=>16,
			'卫生和社会工作'=>17,
			'文化、体育和娱乐业'=>18,
		    '公共管理、社会保障和社会组织'=>19,
			'国际组织'=>20,
			'其它'=>21
		);
		
		
		$nature = array(
		   '国有企业'=>1,
		   '外资企业'=>2,
		   '中外合资企业'=>3,
		   '民营企业'=>4,
		   '事业单位'=>5,
		   '机关单位'=>6,
		   '其它'=>7
		);
	  

        $error = "";
        foreach($arrExcel as $v){
            if($m->where(array("company_name"=>$v[0]))->count()){
                echo "$v[0]  <b style='color:red'>已存在！</b><br>";continue;
            }
            $data = array(
                    "company_name"  => $v[0],
                    "type"          => $new_type[$v[1]],
                    "people"        => $v[2],
                    "address"       => $v[3],
                    "tel"           => $v[4],
					"email"         => $v[5],
					"nature"        => $nature[$v[6]],
					"content"        => $v[7],
                    "cate"          => 0,
                  
                );
            $res = $m->add($data);
            if($res){
                $id = $m->getLastInsID();
              
                $account = makeUsernamePass($data['company_name'], 1, $id);
                // 密码与账号一样
                $account["password"] = md5($account['username']);
                $res1 = $m->where(array('id'=>$id))->save($account);
                if(!$res1){
                    echo $data['company_name']."导入<b style='color:red'>失败！</b><br>";
                }else{
                    echo $data['company_name']."导入<b style='color:green'>成功！</b><br>";
                }
            }else{
                echo $data['company_name']."导入<b style='color:red'>失败！</b><br>";
            }
        }
        echo "公司导入完成!<br>";
        echo "<a href='".U("Admin/Company/index")."'>返回</a>";
    } 


    /**
     * 查看用户简历详情
     *
     */
    public function recruitDetail(){
        $id   = intval(I("id"));
        $res  = M("myresume")->where(array("memberID"=>$id))->find();
        $res2 = M("myexperience")->where(array("memberID"=>$id,"resumeID"=>$res['id']))->order("starttime asc")->select();
        $data["user_info"] = $res;
        // 1.教育背景  2.工作经历
        foreach($res2 as $v){
            if($v['typeid']==1){
                $data["edu_info"][] = $v;
            }else{
                $data["exp_info"][] = $v;
            }
        }
        $this->assign("user", 4);
        $this->assign("cache", $data);
        $this->display();
    }
}