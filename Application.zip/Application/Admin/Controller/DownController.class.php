<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class DownController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",11);
    }

    // 公司列表
    public function index(){
        $M = M('dowload');
        $info = $M->select();

        $this->assign("info",$info);
        $this->assign("comptype",'7');
        $this->display();
    
  
    }



    public function edit(){
        $id = I('get.id');
        $M = M('dowload');
        $cache = $M->find($id);
      

        if(IS_POST){
            $oid = I('post.oid');
            $data['title'] = I('post.title');
            $data['url'] = I('post.url');

    
            $data['content'] = I('post.content');
            $img = I('post.pic');
            $oldimg = I('post.spic');
            if($img!=$oldimg&&$img!=""){
                $data['pic'] = $img;
            }

            $rs=$M->where('id='.$oid)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Down/index'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }

        $this->assign("comptype",'7');
        $this->assign("cache",$cache);
        $this->display();

    }



  


    public function add(){
           if(IS_POST){
            $data['title'] = I('post.title');
            $data['url'] = I('post.url');
            $data['pic'] = I('post.pic');
    
            $rs=M('dowload')->add($data);
            if($rs){
                $this->success('添加成功',U('/Admin/Down/index'));exit;
            }else{
                $this->error('添加失败');exit;
            }

        }
        
        $this->assign("comptype",'7');

        $this->display();


    }



     public function del(){

        $id = I('get.id');
        $rs = M('dowload')->delete($id);
        if($rs){
            $this->success('添加成功',U('/Admin/Down/index'));exit;
        }else{
            $this->error('添加失败');exit;
        }
        $this->display();


    }














}