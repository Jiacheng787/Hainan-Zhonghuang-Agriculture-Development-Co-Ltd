<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class TaskController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",2);
    }

    // 添加分类
	public function addCategory(){
        $classname=I('post.classname');
		$parid=I('post.fid');
        $sequence=I('post.sort');
		$pic=I('post.pic');

        $action=D('taskClass');
        $rs=$action->check_category($classname,$parid);    //判断类名是否重复
		
        if(!$rs){            
            $arr['classname']=$classname;
			$arr['parid']=$parid;
            $arr['sequence']=$sequence;
			$arr['pic']=$pic;
            // $arr['addtime']=Gettime();
            $rt=$action->add($arr);
            if($rt){
                $data['info']   =   '添加成功'; // 提示信息内容
                $data['status'] =   1;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }else{
                $data['info']   =   '添加失败'; // 提示信息内容
                $data['status'] =   0;  // 状态 如果是success是1 error 是0
                $data['url']    =   ''; // 成功或者错误的跳转地址
            }

        }else{
            $data['info']   =   '此分类已存在'; // 提示信息内容
            $data['status'] =   0;  // 状态 如果是success是1 error 是0
            $data['url']    =   ''; // 成功或者错误的跳转地址
        }

        $this->ajaxReturn($data);
        return;
    }

    // 编辑分类
 	public function editCategory(){
        $classname=I('post.classname');
        $sequence=I('post.sort');
		$parid=I('post.fid');
		$pic=I('post.pic');
        $taskId=I('post.categoryid');

        $m=D('taskClass');

        $rs=$m->check_category($classname,$parid,$taskId);    //判断类名是否重复
        if($rs){
            $data['info']   =   '类名已存在'; // 提示信息内容
            $data['status'] =   0;  // 状态 如果是success是1 error 是0
            $data['url']    =   ''; // 成功或者错误的跳转地址
            $this->ajaxReturn($data);
        }
        $arr['classname']=$classname;
        $arr['sequence']=$sequence;
		$arr['parid']=$parid;
		$arr['pic']=$pic;
        $arr['id']=$taskId;

        $result = $m->where("id=$taskId")->save($arr);
		
		$data['info']   =   '修改成功'; // 提示信息内容
		$data['status'] =   1;  // 状态 如果是success是1 error 是0
		$data['url']    =   ''; // 成功或者错误的跳转地址


        $this->ajaxReturn($data);
        return;
    }


    // 分类列表
    public function category(){
        $m     = D('taskClass');
        $where = array(
                "isdel" => 0
            );
        $list  = $m->where($where)->select();
		$this->assign('urlname', "ccategory"); // 赋值数据集
        $lists = $m -> get_category($list);
		$this->assign('category', $lists); // 赋值数据集
		$this->display();

    }

    public function delcategory(){
        $id = I("cid");
        $map['id'] = $id;
        $map['parid'] = $id;
        $map['_logic'] = 'OR';
        $data["isdel"] = 1;
        $res = D("taskClass")->where($map)->save($data);
        if($res){
            $this->success();
        }else{
            $this->error();
        }
    }
	
    public function addImage(){
		$data = $this->uploadImg();
		$this->ajaxReturn($data);
		//return;
    }

    // 时间范围
    public function timearea(){
        $m = D("timearea");
        $map = array(
                "isdel" => 0
            );
        $res = $m->field("id,timearea,squence")->where($map)->order("squence asc")->select();
        $this->assign("cache",$res);
        $this->assign("urlname","timearea");
        $this->display();
    }

    // 添加时间范围
    public function addtimearea(){
        $timearea = $_POST["classname"];
        $squence = $_POST["sort"];
        $m = D("timearea");
        if($m->check_repeat($timearea)){
            $info["status"] = 0;
            $info["info"] = "此时间范围已存在";
            $this->ajaxReturn($info);die;
        }
        $data = array(
                "timearea" => $timearea,
                "squence"  => $squence
            );
        $res = $m->add($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "添加成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "添加失败";
        }
        $this->ajaxReturn($info);
    }

    // 编辑时间范围
    public function edittimearea(){
        $id = $_POST['categoryid'];
        $timearea = $_POST["classname"];
        $squence = $_POST["sort"];
        $m = D("timearea");
        if($m->check_repeat($timearea,$id)){
            $info["status"] = 0;
            $info["info"] = "时间范围已存在";
            $this->ajaxReturn($info);
        }
        $data = array(
                "id"       => $id,
                "timearea" => $timearea,
                "squence"  => $squence
            );
        $res = $m->save($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "修改成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "修改失败";
        }
        $this->ajaxReturn($info);
    }

    // 删除时间范围
    public function deltimearea(){
        $id = I("id");
        $map['id'] = $id;
        $data["isdel"] = 1;
        $res = D("timearea")->where($map)->save($data);
        if($res){
            $this->success();
        }else{
            $this->error();
        }
    }

    public function range(){
        $m = D("range");
        $map = array(
                "isdel" => 0
            );
        $res = $m->field("id,range,squence")->where($map)->order("squence asc")->select();
        $this->assign("cache",$res);
        $this->assign("urlname","range");
        $this->display();
    }

    // 添加距离范围
    public function addRange(){
        $range = $_POST["classname"];
        $squence = $_POST["sort"];
        $m = D("range");
        if($m->check_repeat($range)){
            $info["status"] = 0;
            $info["info"] = "此距离范围已存在";
            $this->ajaxReturn($info);die;
        }
        $data = array(
                "range" => $range,
                "squence"  => $squence
            );
        $res = $m->add($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "添加成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "添加失败";
        }
        $this->ajaxReturn($info);
    }

    // 编辑距离范围
    public function editRange(){
        $id = $_POST['categoryid'];
        $range = $_POST["classname"];
        $squence = $_POST["sort"];
        $m = D("range");
        if($m->check_repeat($range,$id)){
            $info["status"] = 0;
            $info["info"] = "距离范围已存在";
            $this->ajaxReturn($info);
        }
        $data = array(
                "id"       => $id,
                "range" => $range,
                "squence"  => $squence
            );
        $res = $m->save($data);
        if($res){
            $info["status"] = 1;
            $info["info"] = "修改成功";
        }else{
            $info["status"] = 0;
            $info["info"] = "修改失败";
        }
        $this->ajaxReturn($info);
    }

    // 删除距离范围
    public function delRange(){
        $id = I("id");
        $map['id'] = $id;
        $data["isdel"] = 1;
        $res = D("range")->where($map)->save($data);
        if($res){
            $this->success();
        }else{
            $this->error();
        }
    }


}