<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class SystemController extends CommonController {
	public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",10);
    }

    public function index(){
    	$m = M("system");
    	$cache = $m->where(array("id"=>1))->find();
    	$cache["lastadmin"] = M("user")->where(array("id"=>$cache['lastadmin']))->getField("username");
    	$this->assign("cache",$cache);
        $this->assign("urlname","index");
    	$this->display();
    }

    public function editApp(){
    	$m = M("system");
    	$data = I("post.");
    	$data["lastAdmin"] = $_SESSION["admin_id"];
    	$data["lastTime"]  = date("Y-m-d H:i:s",time());
    	$res = $m->where("id=1")->save($data);
    	if($res===false){
    		$info["status"] = 0;
    		$info["info"]   = "修改失败";
    	}else{
    		$info["status"] = 1;
    		$info["info"]   = "修改成功，请妥善保管";
    	}
    	$this->ajaxReturn($info);
    }

    public function admin(){
        $cache = M("user")->field("id,username,addtime,last_adddate,is_open")->select();
        $this->assign("cache",$cache);
        $this->assign("urlname","admin");
        $this->display();
    }

 



    public function updatepwd(){
        $action=D('User');
        $pass=I('post.password');
        if($pass){
            $md5_pass=md5($pass);
            $re=$action->where("id='".$_SESSION['admin_id']."'")->setField('password',$md5_pass);
            if($re){
                $this->success('修改成功',U('/Admin/System/updatepwd'));die;
            }else{   
                $this->error('修改失败');die;
            }
        }
        $this->assign('munetype',9);
        $this->display('updatepwd');
    }
    
 
    

   
  








   
}