<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class ContactController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",11);
    }

    // 公司列表
    public function index(){
        $cache  = M('contact')->find();
        if(IS_POST){
           // dump($_POST);
            $id = I('post.id');
            $data['company_name'] = I('post.company_name');
            $data['address'] = I('post.address');
            $data['phone'] = I('post.phone');
            $data['fax'] = I('post.fax');
            $data['url'] = I('post.url');
            $data['email'] = I('post.email');
            //$data['codepic'] = I('post.pic');
            $res = M('contact')->where(array('id'=>$id))->save($data);
        }

        $this->assign('cache',$cache);
        $this->assign("comptype",'6');
        $this->display();
    }

    // 意见反馈
    public function suggestion(){
        $info = M('suggestion')->select();
        $this->assign('info',$info);
        $this->assign("comptype",'9');
        $this->display();
    }


    public function detail(){
        $id = I('get.id');
        $where['id'] =  $id;
        $detail = M('suggestion')->where($where)->find();
        $this->assign('detail',$detail);
        $this->assign("comptype",'9');
        $this->display();

    }




 
    
  
}