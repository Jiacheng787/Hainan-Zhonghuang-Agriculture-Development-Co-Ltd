<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class EhomeController extends CommonController {
    public function _initialize(){
        parent::_initialize();

        $cate = M('service_class')->where(array('isdel'=>0))->order('sequence desc')->select();
        $this->assign("cate",$cate);
        $this->assign("munetype",3);
    }

    public function news(){
       $info = M('service')->order('addtime desc,id desc')->select();
       $this->assign("info",$info);
       $this->assign("urlname",'news');
       $this->display();

    }

    //招聘审核1

    public function changeStatusNews(){
        if(IS_POST){
            $id = I('id');
            $where['id'] = $id;
            $m = D("service");
            $data["status"] = 1;
            $res = $m->where($where)->save($data);
            if($res){
                $arrys = array('status'=>1);
            }else{
                $arrys = array('status'=>0);
            }

            echo json_encode($arrys);exit;
        }
    }
	
	
	
	public function card(){
		$where = array();

        $name = I('param.name');
        $position = I('param.position');
        $card = I('param.card');

        if($name!=""){
            $where['name'] = array("like","%".$name."%");
        }

        if($position!=""){
            $where['position'] = array("like","%".$position."%");
        }

        $where['card'] = array("neq","");

        if($card!=""){
            $where['card'] = $card;
        }



		$count = M('shenfenz')->where($where)->count();
		$users = M('shenfenz')->where($where)->limit($p->firstRow, $p->listRows)->select();
        $action = 'FindIdentityNo';

       // $card = "330227197706245624";
        $zhuantai = sqlserver($action,$card,'','','','');

        foreach ($users as $k => $v) {

            if(!$v['name']){
                $card = $v['card'];
               
                $zhuantai = sqlserver($action,$card,'','','','');
              
                if($zhuantai){
                    $i = 0;
                        foreach($zhuantai as $key=>$val){
                            $list[$i] = yang_gbk2utf8($val);
                            $i++;                       
                        }

                        $data['name'] = $list[2];
                        $data['position'] = $list[3];
                        $data['school'] = $list[4];
                        $data['education'] = $list[5];
                        $data['major'] = $list[6];
                        $data['mobile'] = $list[7];
                        $data['startime'] = $list[8];
                        $data['endtime'] = $list[9];
                        $data['danwei'] = $list[10];
                        $res = M('shenfenz')->where(array("id"=>$v['id']))->save($data);
                }
            }
            
        }

	    $p        = getpage($count,10);
		$page = $p->show();
		$this->assign("users",$users);
		$this->assign("page",$page);
		$this->display();
		
		
	}



    public function deluser(){
        $id = I("param.id");
        $delete = M('shenfenz')->where(array('id'=>$id))->delete();





    }









	
	
	public function log(){
		$userid = intval(I('param.userid'));
		$map['userid'] = $userid;
		$m = M('shenfenz_log');
	    $count = $m->where($map)->count();
		$p        = getpage($count,10);
		$log = $m->where($map)->limit($p->firstRow, $p->listRows)->select();
		
		foreach($log AS $key=>$val){
			$log[$key]['name'] = M('shenfenz')->where(array('id'=>$userid))->getField('name');
			
		}
		$page = $p->show();
        $this->assign("page",$page);
		$this->assign("log",$log);
		
		$this->display();
		
	}
	
	
	public function mima(){
		$id = I('post.id');
		$card = I('post.card');
		$data['password'] = md5(substr($card,-6));
		$save = M('shenfenz')->where(array('id'=>$id))->save($data);
		if($save){
			$return  = array(
			   'status'=>1,
			   'info'=>'密码已初始化为身份证后6位'
			);
			echo json_encode($return);exit;
			
		}else{
			$return  = array(
			   'status'=>0,
			   'info'=>'密码已初始化为身份证后6位'
			);
			echo json_encode($return);exit;
			
			
		}
	
	}
	
	
	
	


    //招聘审核1

    public function changeStatusClassnews(){
        if(IS_POST){
            $id = I('id');
            $where['id'] = $id;
            $m = D("classnews");
            $data["status"] = 1;
            $res = $m->where($where)->save($data);
            if($res){
                $arrys = array('status'=>1);
            }else{
                $arrys = array('status'=>0);
            }

            echo json_encode($arrys);exit;
        }


    }
    //招聘审核2

    public function changeStatusHotnews(){
        if(IS_POST){
            $id = I('id');
            $where['id'] = $id;
            $m = D("hotnews");
            $data["status"] = 1;
            $res = $m->where($where)->save($data);
            if($res){
                $arrys = array('status'=>1);
            }else{
                $arrys = array('status'=>0);
            }

            echo json_encode($arrys);exit;
        }


    }

    public function editnews(){
        $M = M('service');
        $where['id'] = I('get.id');
        $info = $M->where($where)->find();
        $info['content']=str_ireplace('\"','"',htmlspecialchars_decode($info['content']));


        $piclist = '';
        if($info['pic1']){
            $piclist=explode(',', $info['pic1']);
        }

        if(IS_POST){
            $where['id'] = I('post.id');
            $data['title'] = I('post.title');
            $data['cate_id'] = I('post.cate_id');
            $data['is_tui'] = I('post.is_tui');
            $data['content'] = I('post.content');
            $data['gaiyao'] = I('post.gaiyao');
            $pic = I('post.pic');
            $data['pic1']=implode(",",I('post.pic1'));
            if(!empty($pic)){
                $data['pic'] = $pic;
            }
            $data['addtime'] = I('post.addtime');
            $rs=M('service')->where($where)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Ehome/news'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }

        $this->assign("piclist",$piclist);
        $this->assign("info",$info);
        $this->assign("urlname",'news');
        $this->display();


    }



    public function addnews(){

        $id = I('id');
        if(!empty($id)){
            $where['id'] = $id;
            if(IS_POST){

                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic1']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('service')->where($where)->save($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/news'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }else{
            if(IS_POST){
                $data['title'] = I('post.title');
                $data['cate_id'] = I('post.cate_id');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');

                $data['pic1']=implode(",",I('post.pic1'));
            
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('service')->add($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/news'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }
       $this->assign("urlname",'news');
       $this->display();


    }



    public function delnews(){
        $where['id'] = I('get.id');
        $rs=M('service')->where($where)->delete();
        if($rs){
             $this->success('删除成功',U('/Admin/Ehome/news'));exit;
        }else{
            $this->error('删除失败');exit;
        }
    }




    // 服务指栏类型列表
    public function catelist(){
        $m = D("serviceClass");
        $map["isdel"] = 0;
        $cache = $m -> order("sequence asc")-> where($map) -> select();
        $this->assign("cache",$cache);
        $this->assign("urlname",'servicecate');
        $this->display();
    }



    // 添加公司类型
    public function addCate(){
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $data = array(
                "classname" => $classname,
                "sequence"  => $sequence
            );
        $m = D("serviceClass");
        // 检测是否重复
        $res = $m -> add($data);
        if($res){
            $info["info"] = "添加成功";
            $info["status"] = 1;
            $info["url"] = "";
        }else{
            $info["info"] = "添加失败";
            $info["status"] = 0;
            $info["url"] = "";
        }
        
        $this->ajaxReturn($info);
    }
    // 编辑公司类型
    public function editCate(){
        $id = I("categoryid");
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $m = M("serviceClass");
        if($id){
            $data['classname'] = $classname;
            $data['sequence'] = $sequence;
            $save = $m ->where(array('id'=>$id))->save($data);
            if($save){
                $result = array(
                    'status'=>1,
                    'info'=>'修改成功'

                    );
            }else{
                $result = array(
                    'status'=>0,
                    'info'=>'修改失败'

                    );

            }

            echo json_encode($result);exit;


           
        }
    }
    // 删除公司类型
    public function delcate(){
        $id = I("cid");
        $where['id'] = $id;
        $m = D("serviceClass");
        $data["isdel"] = 1;
        $res = $m->where($where)->save($data);
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }
    }



     public function classnews(){
       $info = M('classnews')->order('addtime desc,id desc')->select();

       $this->assign("info",$info);
       $this->assign("urlname",'classnews');
       $this->display();

    }



    public function editclassnews(){
        $M = M('classnews');
        $where['id'] = I('get.id');
        $info = $M->where($where)->find();
        $piclist = '';
        if($info['pic1']){
            $piclist=explode(',', $info['pic1']);
        }

        if($info['fujian']!=''){
            $file = explode(',',$info['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$info['filename']);
            $filename = array_filter($filename);

            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $fujianlist[$key]['file'] = $str[$length-1];
                $fujianlist[$key]['fujian'] = $val;
                
            } 


            foreach ($filename as $key => $vo) {
                $fujianlist[$key]['filename'] = $vo;
            } 




        }

        $this->assign("fujianlist",$fujianlist);
       
   
        $info['content']=str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        if(IS_POST){
            $where['id']     = I('post.id');
            $data['title']   = I('post.title');
            $data['is_tui']  = I('post.is_tui');
            $data['content'] = I('post.content');
            $data['gaiyao']  = I('post.gaiyao');
            $data["list"]    = I("post.list");
            $data["is_slide"]= I("post.is_slide");

            $fujian = '';
            $file = I('post.file');
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }

            $fujian = substr($fujian,0,-1);
            $data['fujian'] =  $fujian;


            $filename = '';
            $fujianname = I('post.filename');
            if($fujianname){

                foreach ($fujianname as $key => $val) {
                    $filename .= $val.',';
                }
            }


            $filename = substr($filename,0,-1);
            $data['filename'] =  $filename;





            $data['pic1']=implode(",",I('post.pic1'));
            $pic = I('post.pic');
            if(!empty($pic)){
                $data['pic'] = $pic;
            }
            $data['addtime'] = I('post.addtime');
            $rs=M('classnews')->where($where)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Ehome/classnews'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }

        $this->assign("info",$info);
        $this->assign("piclist",$piclist);
        $this->assign("urlname",'classnews');
        $this->display();


    }



    public function qcimg(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/Lesson/detail",array('id'=>$id));
        qrcode($qcurl, false);
    }



    public function qcimg1(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/Customer/hotdetail",array('id'=>$id));
        qrcode($qcurl, false);
    }

    
    //课堂多选删除
    public function alldel(){

        if(IS_POST){
            $id = I('post.id');
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('classnews')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }


    //指南多选删除
    public function newsalldel(){

        if(IS_POST){
            $id = I('post.id');
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('service')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }



    //热点多选删除
    public function hotalldel(){

        if(IS_POST){
            $id = I('post.id');
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('hotnews')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }



     public function addclassnews(){

        $id = I('id');
        $time = date('Y-m-d',time());
        if(!empty($id)){
            $where['id'] = $id;
            if(IS_POST){
                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic1']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('classnews')->where($where)->save($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/classnews'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }else{
            if(IS_POST){
                $file = I('post.file');
                $fujian = '';
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }
                $fujian = substr($fujian,0,-1);
                $data['fujian'] =  $fujian;


                $filename = '';
                $fujianname = I('post.filename');
                if($fujianname){

                    foreach ($fujianname as $key => $val) {
                        $filename .= $val.',';
                    }
                }


                $filename = substr($filename,0,-1);
                $data['filename'] =  $filename;




                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic1']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('classnews')->add($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/classnews'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }

        $this->assign("time",$time);
       $this->assign("urlname",'classnews');
       $this->display();





    }


    public function delclassnews(){
        $where['id'] = I('get.id');
        $rs=M('classnews')->where($where)->delete();
        if($rs){
             $this->success('删除成功',U('/Admin/Ehome/classnews'));exit;
        }else{
            $this->error('删除失败');exit;
        }
    }


   
    public function hotnews(){
       $info = M('hotnews')->order('addtime desc,id desc')->select();
       $this->assign("info",$info);
       $this->assign("urlname",'hotnews');
       $this->display();
    }

    public function edithotnews(){
        $M = M('hotnews');
        $where['id'] = I('get.id');
        $info = $M->where($where)->find();
        $piclist = '';
        if($info['pic1']){
            $piclist=explode(',', $info['pic1']);
        }

        if($info['fujian']!=''){
            $file = explode(',',$info['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$info['filename']);
            $filename = array_filter($filename);

            foreach ($file as $key => $val) {
                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $fujianlist[$key]['file'] = $str[$length-1];
                $fujianlist[$key]['fujian'] = $val;
            
            } 

            foreach ($filename as $key => $vo) {
                $fujianlist[$key]['filename'] = $vo;
            } 

        }

        $this->assign("fujianlist",$fujianlist);
       
   
        $info['content']=str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        if(IS_POST){
            $where['id']     = I('post.id');
            $data['title']   = I('post.title');
            $data['is_tui']  = I('post.is_tui');
            $data['content'] = I('post.content');
            $data['gaiyao']  = I('post.gaiyao');
            $data["list"]    = I("post.list");
          
            $fujian = '';
            $file = I('post.file');
            if($file){
                foreach ($file as $key => $val) {
                    $fujian .= $val.',';
                }
            }

            $fujian = substr($fujian,0,-1);
            $data['fujian'] =  $fujian;


            $filename = '';
            $fujianname = I('post.filename');
            if($fujianname){

                foreach ($fujianname as $key => $val) {
                    $filename .= $val.',';
                }
            }


            $filename = substr($filename,0,-1);
            $data['filename'] =  $filename;

            $data['pic1']=implode(",",I('post.pic1'));
            $pic = I('post.pic');
            if(!empty($pic)){
                $data['pic'] = $pic;
            }

            $data['addtime'] = I('post.addtime');
            $rs=M('hotnews')->where($where)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Ehome/hotnews'));exit;
            }else{
                $this->success('修改失败');exit;
            }

        }

        $this->assign("info",$info);
        $this->assign("piclist",$piclist);
        $this->assign("urlname",'hotnews');
        $this->display();
    }



     public function addhotnews(){

        $id = I('id');
        $time = date('Y-m-d',time());
        if(!empty($id)){
            $where['id'] = $id;
            if(IS_POST){
                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('hotnews')->where($where)->save($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/hotnews'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }else{
            if(IS_POST){
                $file = I('post.file');
                $fujian = '';
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }
                $fujian = substr($fujian,0,-1);
                $data['fujian'] =  $fujian;


                $filename = '';
                $fujianname = I('post.filename');
                if($fujianname){

                    foreach ($fujianname as $key => $val) {
                        $filename .= $val.',';
                    }
                }


                $filename = substr($filename,0,-1);
                $data['filename'] =  $filename;


                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic1']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('hotnews')->add($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Ehome/hotnews'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }

        $this->assign("time",$time);
        $this->assign("urlname",'hotnews');
        $this->display();


    }



    public function delhotnews(){
        $where['id'] = I('get.id');
        $rs=M('hotnews')->where($where)->delete();
        if($rs){
             $this->success('删除成功',U('/Admin/Ehome/hotnews'));exit;
        }else{
            $this->error('删除失败');exit;
        }
    }


       // 服务指南预览
    public function qcimgNews(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/Guide/detail",array('id'=>$id));
        qrcode($qcurl, false);
    }
    // 东方课堂预览
    public function qcimgClassNews(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/Lesson/detail",array('id'=>$id));
        qrcode($qcurl, false);
    }
    // 热电信息预览
    public function qcimgHotNews(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/Customer/hotDetailView",array('id'=>$id));
        qrcode($qcurl, false);
    }



    // 查询地点列表
    public function address(){
        $m = M("research_address");
        $map["isdel"] = 0;
        $cache = $m -> order("sequence asc")-> where($map) -> select();

        $this->assign("cache",$cache);
        $this->assign("urlname",'servicecate');
        $this->display();
    }




    // 添加查询地点
    public function addaddress(){
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $data = array(
                "classname" => $classname,
                "sequence"  => $sequence
            );
        $m = M("research_address");
        // 检测是否重复
        $res = $m -> add($data);
        if($res){
            $info["info"] = "添加成功";
            $info["status"] = 1;
            $info["url"] = "";
        }else{
            $info["info"] = "添加失败";
            $info["status"] = 0;
            $info["url"] = "";
        }
        
        $this->ajaxReturn($info);
    }


    // 编辑查询地点
    public function editaddress(){
        $id = I("categoryid");
        $classname = I("classname");
        $sequence = I("sort")?I("sort"):0;
        $m = M("research_address");
        if($id){
            $data['classname'] = $classname;
            $data['sequence'] = $sequence;
            $save = $m ->where(array('id'=>$id))->save($data);
            if($save){
                $result = array(
                    'status'=>1,
                    'info'=>'修改成功'

                    );
            }else{
                $result = array(
                    'status'=>0,
                    'info'=>'修改失败'

                    );

            }

            echo json_encode($result);exit;


           
        }
    }


     // 删除地点
    public function deladdress(){
        $id = I("cid");
        $where['id'] = $id;
        $m =  M("research_address");
        $data["isdel"] = 1;
        $res = $m->where($where)->save($data);
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }
    }



    //社保查询列表
    public function security(){

        $address = M('research_address')->order('sequence asc')->select();
        foreach ($address as $key => $val) {
            $info[$val['id']] =  $val['classname'];
        }

        $action = M('research');
        $where = array();
        $where['type'] = 1;
        $list = $action->where($where)->select();
        $this->assign('address',$info);
        $this->assign('list',$list);
        $this->display();


    }


    public function addsecurity(){
        $address = M('research_address')->order('sequence asc')->select();
        if(IS_POST){
            $_POST['type'] = 1;
            $res = M('research')->add($_POST);
            if($res){
                $this-> success("添加成功！",U('Admin/Ehome/security'));exit;
            }else{
                $this-> error("添加失败！");exit;
            }
        }

        $this->assign('address',$address);
        $this->display();

    }


    public function editsecurity(){
        $address = M('research_address')->order('sequence asc')->select();
        $id = I('get.id');
        $info = M('research')->find($id);

        if(IS_POST){
            $id = I('post.id');
            $addressid =I('post.addressid');
            $url =I('post.url');
            $data['addressid'] = $addressid;
            $data['url'] = $url;
            $res = M('research')->where(array('id'=>$id))->save($data);

           if($res){
                $this-> success("修改成功！",U('Admin/Ehome/security'));exit;
            }else{
                $this-> success("修改成功！");exit;
            }
        }


        $this->assign('info',$info);
        $this->assign('address',$address);
        $this->display();
    }


    public function delsecurity(){

        $id = I("id");
        $where['id'] = $id;
        $m =  M("research");

        $res = $m->where($where)->delete();
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }


    }




     //公积金查询列表
    public function fund(){

        $address = M('research_address')->order('sequence asc')->select();
        foreach ($address as $key => $val) {
            $info[$val['id']] =  $val['classname'];
        }

        $action = M('research');
        $where = array();
        $where['type'] = 2;
        $list = $action->where($where)->select();
        $this->assign('address',$info);
        $this->assign('list',$list);
        $this->display();


    }


    public function addfund(){
        $address = M('research_address')->order('sequence asc')->select();
        if(IS_POST){
            $_POST['type'] = 2;
            $res = M('research')->add($_POST);
            if($res){
                $this-> success("添加成功！",U('Admin/Ehome/fund'));exit;
            }else{
                $this-> error("添加失败！");exit;
            }
        }

        $this->assign('address',$address);
        $this->display();

    }


    public function editfund(){
        $address = M('research_address')->order('sequence asc')->select();
        $id = I('get.id');
        $info = M('research')->find($id);

        if(IS_POST){
            $id = I('post.id');
            $addressid =I('post.addressid');
            $url =I('post.url');
            $data['addressid'] = $addressid;
            $data['url'] = $url;
            $res = M('research')->where(array('id'=>$id))->save($data);

           if($res){
                $this-> success("修改成功！",U('Admin/Ehome/fund'));exit;
            }else{
                $this-> success("修改成功！");exit;
            }
        }


        $this->assign('info',$info);
        $this->assign('address',$address);
        $this->display();
    }


      public function delfund(){
        $id = I("id");
        $where['id'] = $id;
        $m =  M("research");

        $res = $m->where($where)->delete();
        if($res){
            $this-> success("删除成功！");
        }else{
            $this-> error("删除成功！");
        }

    }








      


	
}