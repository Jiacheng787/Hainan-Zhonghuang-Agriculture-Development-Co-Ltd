<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class TaskOrderController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",3);
    }

    public function index(){

    }

    public function receiveLists(){
        $orderstate = I("orderstate"); // 订单状态
        $telephone  = I("telephone"); // 手机号
        $starttime  = I("starttime"); // 开始时间
        $endtime    = I("endtime"); // 结束时间
        $m = D("receiveOrder");
        // 输出各个类型的数量
        for($i=0;$i<=7;$i++){
            $name  = "counts_type$i";
            $$name = $m->count_type_n($i);
            $this->assign($name,$$name);
        }
        $where["isdel"] = 0;
        $counts = $m -> where($where) ->count();
        $result = $m -> orderlist($p);
        $this->assign("receiveOrder",$result['data']);
        $this->assign("page"        ,$result['page']);
        $this->assign("counts"      ,$counts);
        $this->assign("count"       ,$result['count']);
        $this->assign("dealerid"    ,1);
        $this->assign("orderstate"  ,$orderstate);
        $this->assign("telephone"   ,$telephone);
        $this->assign("order_no"    ,I("order_no"));
        $this->assign("endtime"     ,$endtime);
        $this->assign("starttime"   ,$starttime);
        $this->display();
    }

    public function orderLists(){
        $orderstate = I("orderstate"); // 订单状态
        $telephone  = I("telephone"); // 手机号
        $starttime  = I("starttime"); // 开始时间
        $endtime    = I("endtime"); // 结束时间

        $m = D("orderlist");
        $taskM = D("taskClass");
        // 输出各个类型的数量
        for($i=0;$i<=7;$i++){
            $name = "counts_type$i";
            $map["orderstate"] = $i;
            // $map["isdel"] = 0;
            $$name = $m->where($map)->count();
            $this->assign($name,$$name);
        }
        $where["isdel"] = 0;
        $counts = $m ->where($where)-> count();

        $tasks = $taskM ->where($where)-> select();
        foreach($tasks as $k=>$v){
            $newtasks[$v['id']] = $v["classname"];
        }

        $result = $m->orderlist($newtasks,$userids);
        $this->assign("receiveOrder",$result['data']);
        $this->assign("page"        ,$result['page']);
        $this->assign("counts"      ,$counts);
        $this->assign("tasks"       ,$newtasks);
        $this->assign("orderstate"  ,$orderstate);
        $this->assign("order_no"    ,I("order_no"));
        $this->assign("telephone"   ,$telephone);
        $this->assign("starttime"   ,$starttime);
        $this->assign("dealerid"    ,2);
        $this->assign("endtime"     ,$endtime);
        $this->display();
    }


    /*
        订单下架
    */
    public function delOrder(){
        $id = I("post.id");
        if($id){
            // 将与订单相关的全部下架
            $res = M("orderlist")->where(array("id"=>$id))->find();
            $isdel = $res["isdel"]?0:1;
            if($res){
                $res1 = M("orderlist")->where(array("id"=>$id))->save(array("isdel"=>$isdel));
                $res2 = M("orderLog")->where(array("orderid"=>$id))->save(array("isdel"=>$isdel));
                $res3 = M("receiveOrder")->where(array("orderid"=>$id))->save(array("isdel"=>$isdel));
                if($res1!==false && $res2!==false && $res3!==false){
                    $this->ajaxReturn(array("status"=>1,"info"=>"操作成功"));
                }else{
                    $this->ajaxReturn(array("status"=>0,"info"=>"操作失败"));
                }
            }else{
                $this->ajaxReturn(array("status"=>0,"info"=>"操作失败"));
            }
        }else{
            $this->ajaxReturn(array("status"=>0,"info"=>"操作失败"));
        }
    }

    public function orderdetail(){
        $id = I("get.id");  // 得到orderlist的id
        $m = D("orderlist");
        $user = D("member");
        $task = D("taskClass");
        $map['id'] = $id;
        $map['isdel'] = 0;
        $result = $m->where($map)->find();
        if($result){
            $task_map['id'] = $result['task'];
            $task_map['isdel'] = 0;
            $user_map['id'] = $result['userid'];
            $user_map['isdel'] = 0;
            $result['user'] = $user->where($user_map)->field("person_img,telephone,realname,person_name")->find();
            $result['task'] = $task->where($task_map)->field("classname")->find();
        }else{
            // 出错或没有数据
            $this->error("数据不存在",U('/admin/taskorder/orderlists'));
        }
        $this->assign("orderdetail",$result);
        $this->display();
    }

    public function logList(){
        $m = D("orderLog");
        $cache = $m->getAllLog();
        $orderstate_arr = array(
                    0 =>"待接受",    1 => "申请中",      2=> "发单者同意",    3 => "接单者就位",    4=> "申请完成",
                    5 =>"确认完成",  6 => "评论完成",    7=> "发单人取消任务",8 => "接单人取消任务",9=> "取消成功",
                    10=>"接单人迟到",11=> "循环取消任务后（第三方介入）",     12=> "发单人投诉",  
                    13=> "订单结束", 14=> "接单人已评价"
            );
        foreach($cache["cache"] as $k=>$v){
            $cache["cache"][$k]["orderstate"] = $orderstate_arr[$v["orderstate"]];
        }
        $this->assign("dealerid",3);
        $this->assign("cache",$cache["cache"]);
        $this->assign("page",$cache["page"]);
        $this->display();
    }

    public function logDetail(){
        $oid = I("oid");
        $this->display();
    }

    public function tousulist(){
        $status = I("status");
        $result = I("result");
        if($status!==""){
            $map["status"] = $status;
        }
        if($result!==""){
            $map["result"] = $result;
        }
        $adminlist = M("user")->select();
        $admin_arr = array();
        foreach($adminlist as $k=>$v){
            $admin_arr[$v["id"]] = $v["username"];
        }
        $count = M("complaint")->where($map)->count();
        $weichuli = M("complaint")->where(array("status"=>0))->count();
        $page = getPage($count,8);
        $res = M("complaint")->where($map)->limit($page->firstRow, $page->listRows)->select();
        $user = M("member");
        foreach($res as $k=>$v){
            $user1 = $user->where(array("id"=>$v["from_userid"]))->field("person_name as from_name,person_img as from_img")->find();
            $user2 = $user->where(array("id"=>$v["to_userid"]))->field("person_name as to_name,person_img as to_img")->find();
            $res[$k]["from_img"] = $user1["from_img"];
            $res[$k]["from_name"] = $user1["from_name"];
            $res[$k]["to_img"] = $user2["to_img"];
            $res[$k]["to_name"] = $user2["to_name"];
            $res[$k]["admin_name"] = $admin_arr[$v["adminid"]];
        }
        $page = $page->show();
        $this->assign("status",$status);
        $this->assign("count",$weichuli);
        $this->assign("result",$result);
        $this->assign("cache",$res);
        $this->assign("page",$page);
        $this->assign("dealerid",4);
        $this->display();
    }

    function getSession(){
        dump($_SESSION);
    }

    public function dealtousu(){
        // 找到投诉的id
        if(IS_AJAX){
            $id = I("id");
            $result = I("result");
            $dealmsg = I("dealmsg");
            if(empty($id) || empty($result) || empty($dealmsg)){
                $result = array("status"=>0,"info"=>"缺少必要参数");
                $this->ajaxReturn($result);
            }
            $res = M("complaint")->where(array("id"=>$id))->find();
            if($res["status"]){
                $result = array("status"=>0,"info"=>"这个投诉已经处理过");
                $this->ajaxReturn($result);
            }
            $c = M("complaint");
            $c->startTrans();
            $c_data = array(
                    "deal_msg"  => $dealmsg,
                    "result"    => $result,
                    "status"    => 1,
                    "dealtime"  => time(),
                    "adminid"   => $_SESSION["admin_id"],
                );
            $c->where(array("id"=>$id))->save($c_data);
            // 处理订单
            switch($result){
                case "1":
                    if($this->refund_to_order($res)){
                        $c->commit();
                        $this->ajaxReturn(array("status"=>1,"info"=>"处理成功，将余额{$order["remuneration"]}返回给了发单者"));
                    }
                    break;
                case "2":
                    if($this->refund_to_receive($res)){
                        $c->commit();
                        $this->ajaxReturn(array("status"=>1,"info"=>"处理成功，将余额{$order["remuneration"]}返回给了接单者"));
                    }
                    break;
                default:
                    $result = array("status"=>0,"info"=>"处理方式不正确");
                    $this->ajaxReturn($result);
            }
        }
    }

    /*
        业务逻辑：
            步骤：1.改变订单状态 3.用户增加余额
    */
    // 退钱给发单人
    protected function refund_to_order($data){
        $order = M("orderlist")->where(array("id"=>$data["orderid"]))->find();
        if($order["orderstate"] != 12){
            $this->ajaxReturn(array("status"=>0,"info"=>"这个订单不为投诉订单"));
        }
        $order_data["orderstate"] = 13;
        $order_data["refund_fee"] = $order["remuneration"];
        $order_data["refundtime"] = time();
        $order_data["refund_state"] = 1;
        $order_data["refund_msg"] = "第三方介入后同意退款给您";
        $m = M("orderlist");
        $m->startTrans();
        $res = $m->where(array("id"=>$data["orderid"]))->save($order_data);
        // 得到接单人id
        if($order["userid"] == $data['from_userid']){
            $user_name = "发单者";
        }else{
            $user_name = "接单者";
        }
        if($res){
            // 改变receive的状态
            if(M("receiveOrder")->where(array("id"=>$data["receiveid"]))->setField("status",1)){
                // 设置成功
                $u_res = M("member")->where(array("id"=>$order["userid"]))->setInc("wallet",$order["remuneration"]);
                if($u_res){
                    // 增加余额成功，记入日志
                    $m->commit();
                    $log_data = array(
                            "orderid"      => $order["id"],
                            "userid"       => $order["userid"],
                            "orderstate"   => 13,
                            "title"        => "投诉成功",
                            "msg"          => "管理员处理了{$user_name}的投诉，并将金额".$order["remuneration"]."返还给了发单者",
                            "pay_status"   => 3, // 退款
                            "addtime"      => date("Y-M-d H:i:s",time()),
                        );
                    // 得到接单人id
                    M("orderLog")->add($log_data);
                    // 调用jpush进行通知
                    A("Interface")->jpush_msg($data["from_userid"],"管理员已处理了投诉，请查看");
                    A("Interface")->jpush_msg($data["to_userid"],"管理员已处理了投诉，请查看");
                    return true;
                }
            }else{
                $m->rollBack();
                $this->ajaxReturn(array("status"=>0,"info"=>"修改状态失败,原因：接单为已完成状态"));
            }
        }else{
            $m->rollBack();
            $this->ajaxReturn(array("status"=>0,"info"=>"修改状态失败，原因：修改订单状态失败"));
        }
    }

    // 退钱给接单人
    public function refund_to_receive($data){
        $order = M("orderlist")->where(array("id"=>$data["orderid"]))->find();
        if($order["orderstate"] != 12){
            $this->ajaxReturn(array("status"=>0,"info"=>"这个订单不为投诉订单"));
        }
        $order_data["orderstate"] = 13;
        $order_data["refund_msg"] = "第三方介入后,将款项给了接单者";
        $m = M("orderlist");
        $m->startTrans();
        $res = $m->where(array("id"=>$data["orderid"]))->save($order_data);
        // 得到接单人id
        if($order["userid"] == $data['from_userid']){
            $receive_userid = $data['to_userid'];
            $user_name = "发单者";
        }else{
            $receive_userid = $data['from_userid'];
            $user_name = "接单者";
        }
        if($res){
            // 改变receive的状态
            if(M("receiveOrder")->where(array("id"=>$data["receiveid"]))->setField("status",1)){
                // 设置成功
                $u_res = M("member")->where(array("id"=>$receive_userid))->setInc("wallet",$order["remuneration"]);
                if($u_res){
                    // 增加余额成功，记入日志
                    $m->commit();
                    $log_data = array(
                            "orderid"      => $order["id"],
                            "userid"       => $receive_userid,
                            "orderstate"   => 13,
                            "title"        => "投诉成功",
                            "msg"          => "管理员处理了{$user_name}的投诉，并将金额".$order["remuneration"]."返还给了接单者",
                            "pay_status"   => 3, // 退款
                            "addtime"      => date("Y-M-d H:i:s",time()),
                        );
                    // 得到接单人id
                    M("orderLog")->add($log_data);
                    // 调用jpush进行通知
                    A("Interface")->jpush_msg($data["from_userid"],"管理员已处理了投诉，请查看");
                    A("Interface")->jpush_msg($data["to_userid"],"管理员已处理了投诉，请查看");
                    return true;
                }
            }else{
                $m->rollBack();
                $this->ajaxReturn(array("status"=>0,"info"=>"修改状态失败,原因：接单为已完成状态"));
            }
        }else{
            $m->rollBack();
            $this->ajaxReturn(array("status"=>0,"info"=>"修改状态失败，原因：修改订单状态失败"));
        }

    }
}