<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class DealerController extends CommonController {


	public function index(){
        $action=D('dealer');
        $rsdate=$action->getdealerlist();
		$count=$rsdate['count'];
        $page=$rsdate['page'];

        $this->assign('dealerlist',$rsdate['list']);
		$this->assign('count',$count);
		if($count>10)
		{
		 $this->assign('page',$page);
		}
        $this->assign('munetype',6);
        $this->display();
    }
	
	public function dealerGoods(){
		$action=D('dealer');
        $rsdate=$action->getdealerlist();
		$count=$rsdate['count'];
        $page=$rsdate['page'];

        $this->assign('dealerlist',$rsdate['list']);
		if($count>10)
		{
		 $this->assign('page',$page);
		}
        $this->display();
	}
	public function goodsList(){
		$id = I('get.id',0,'int');
		if($id){
			$goodsModel = M('Goods');
			$p = getpage($goodsModel->where("dealers_id=$id")->count(),20);
			//查询商品
			$goodsList = $goodsModel->field('a.id,a.pic,a.good_name,a.is_show,b.classname')->alias('a')->join('ys_category b on a.classid=b.id')->where("dealers_id=$id")->order('id desc')->limit($p->firstRow, $p->listRows)->select();
			$string = '';
			foreach($goodsList as $val){
				$string .= $val['id'].',';
			}
			$string = substr($string,0,-1);
			if($string){
				//查询规格
				$goodsGuigeList = M('GoodsGuige')->field('goodsid,guige,price,groupprice,weight,old_price')->where("goodsid in($string)")->order('id desc')->select();
				foreach($goodsList as $key => $val){
					foreach($goodsGuigeList as $key_ => $value){
						if($val['id']==$value['goodsid']){
							$goodsList[$key]['guige'][] = array(
								'guige' => $value['guige'],
								'price' => $value['price'],
								'groupprice' => $value['groupprice'],
								'weight' => $value['weight'],
								'old_price' => $value['old_price']
							);
							unset($goodsGuigeList[$key_]);
						}
					}
				}
			}
			$this->assign('goodsList',$goodsList);
			$this->assign('page',$p->show());
		}
		//查询所有经销商
		$dealerList = M('Dealer')->field('id,username')->select();
		foreach($dealerList as $key => $val){
			if($val['id']==$id){
				$dealerName = $val['username'];
				unset($dealerList[$key]);
				break;
			}
		}
		$this->assign('dealerName',$dealerName);
		$this->assign('dealerId',$id);
		$this->assign('dealerList',$dealerList);
		$this->display();
	}
	public function ajaxDealerGoods(){
		$id = I('post.id',0,'int');
		if($id){
			$dealerGoodsList = M('Goods')->where("is_show=1 and dealers_id=".I('post.id',0,'int'))->select();
			$this->assign('dealerGoodsList',$dealerGoodsList);
		}
		echo $this->fetch();
	}
	public function ajaxDealerGoodsAdd(){
		//获得所有需要添加的商品的id
		$ids = substr(I('post.ids'),0,-1);
		$dealers_id = I('post.dealerId',0,'int');
		if($ids && $dealers_id){
			$goodsModel = M('Goods');
			$goodsGuigeModel = M('GoodsGuige');
			//获得所有商品
			$goodsList = $goodsModel->field('id,classid,othercid,parid,good_name,good_name1,resource,pic,pic1,pic2,detail,addtime,group_num,address,group_time,is_restriction,restriction_num,is_restriction2,restriction_num2,is_delivery,buylimit,recommend_g,keeptime,recommend_gnum')->where("id in($ids)")->select();
			$string = '';
			foreach($goodsList as $val){
				$string .= $val['id'].',';
			}
			//获得商品的规格
			$goodsGuigeList = $goodsGuigeModel->field('goodsid,guige,price,groupprice,weight,old_price')->where('goodsid in('.substr($string,0,-1).')')->select();
			foreach($goodsList as $key => $val){
				foreach($goodsGuigeList as $key_ => $value){
					if($val['id']==$value['goodsid']){
						$goodsList[$key]['guige'][] = array(
							'guige' => $value['guige'],
							'price' => $value['price'],
							'groupprice' => $value['groupprice'],
							'weight' => $value['weight'],
							'old_price' => $value['old_price']
						);
						unset($goodsGuigeList[$key_]);
					}
				}
			}
			$date = date('Y-m-d H:i:s');
			foreach($goodsList as $val){
				//添加商品
				$goodsId = $goodsModel->add(array(
					'dealers_id'=>$dealers_id ,'classid'=>$val['classid'] ,'othercid'=>$val['othercid'] ,'parid'=>$val['parid'] ,'good_name'=>$val['good_name'] ,'good_name1'=>$val['good_name1'] ,'resource'=>$val['resource'] ,'pic'=>$val['pic'] ,'pic1'=>$val['pic'] ,'pic2'=>$val['pic2'] ,'detail'=>$val['detail'] ,'addtime'=>$date ,'group_num'=>$val['group_num'] ,'address'=>$val['address'] ,'group_time'=>$val['group_time'] ,'is_restriction'=>$val['is_restriction'] ,'restriction_num'=>$val['restriction_num'] ,'is_restriction2'=>$val['is_restriction2'] ,'restriction_num2'=>$val['restriction_num2'] ,'is_delivery'=>$val['is_delivery'] ,'buylimit'=>$val['buylimit'] ,'recommend_g'=>$val['recommend_g'] ,'keeptime'=>$val['keeptime'] ,'recommend_gnum'=>$val['recommend_gnum'] ,'is_show'=>0
				));
				//echo M()->getlastsql();
				if($goodsId){
					foreach($val['guige'] as $value){
						$goodsGuigeModel->add(array(
							'goodsid'=>$goodsId,'guige'=>$value['guige'],'price'=>$value['price'],'groupprice'=>$value['groupprice'],'weight'=>$value['weight'],'old_price'=>$value['old_price']
						));
						//echo M()->getlastsql();
					}
				}
			}
			echo 1;
		}else{
			echo 0;
		}
	}
	
	public function add(){
		
		$username=I('post.username');
		//print_r($_POST);exit;
		if($username)
		{
			
			$arr['username'] = $username;
			$arr['truename'] = I('post.truename');
			$arr['mobilephone'] = I('post.mobilephone');
			$arr['password'] = md5(I('post.password'));
			$arr['longitude'] = I('post.longitude');
			$arr['latitude'] = I('post.latitude');
			$arr['is_show'] = I('post.is_show');
			$arr['is_tibu'] = I('post.is_tibu');
			$arr['addtime'] = Gettime();
			$arr['erpappid'] = I('post.erpappid');
			$arr['erpkey'] = I('post.erpkey');
            $m=M('dealer');
            $rs=$m->add($arr);
			if($rs)
			{
				$this->success('添加成功',U('/Admin/Dealer/index'));	
			}
			else
			{
				$this->error('添加失败');
			}
		}
		else
		{
			$this->display();
		}
			
    }
	
	public function edit(){

		$id=I('get.id');
		$username=I('post.username');
		if(!$username)
		{
			
			$freightModel = M('freight_copy');
            $m=M('dealer');
            $rs=$m->where("id=".$id)->select();
			$ids = array();
			foreach($rs as $key => $row){
				$temp = $row['city_ids'];
				if(!empty($temp)){
					$city_names = $freightModel->field('id,privonce')->where('id in ('.$temp.')')->select(); 
					foreach($city_names as $value){
						$rs[$key][province][] = $value;
						$ids[] = $value['id'];
					}
				}
			}
			$this->assign('dealer',$rs);
			$this->assign('ids',$ids);
			//print_r($ids);exit;
			
			$freightRecord = $freightModel->field('id,privonce')->select();
			$this->assign('goods', $freightRecord); 
			//print_r($freightRecord);exit;
			$this->display();
		}
		else
		{
			$arr['id'] = I('post.id');
			$arr['username'] = $username;
			$arr['truename'] = I('post.truename');
			$arr['mobilephone'] = I('post.mobilephone');
			$password = I('post.password');
			if($password!="")
			{
			$arr['password'] = md5($password);
			}
			$arr['longitude'] = I('post.longitude');
			$arr['latitude'] = I('post.latitude');
			$arr['is_tibu'] = I('post.is_tibu');
			$arr['sweight'] = I('post.sweight');
			$arr['sprice'] = I('post.sprice');
			$arr['xwprice'] = I('post.xwprice');
			$arr['is_show'] = I('post.is_show');
			$arr['erpappid'] = I('post.erpappid');
			$arr['erpkey'] = I('post.erpkey');
			
			 $province_ids = I('post.province_ids');
			if(!empty($province_ids)){
				$pro_str = implode(',',$province_ids);
				$arr['city_ids'] = $pro_str;
			} 
			
            $m=M('dealer');
            $m->save($arr);
			$this->success('修改成功',U('/Admin/Dealer/index'));	
		}
    }
	
	
	public function del(){

		$id=I('get.id');
        $m = M("dealer"); // 实例化User对象
        $rs=$m->where("id=$id")->delete(); // 删除id为5的用户数据
        if($rs){
            $this->success('删除成功',U('/Admin/Dealer/index'));
        }else{
            $this->error('删除失败');
        }
    }
	
	
	public function store(){
		
        $action=D('store');
        $rsdate=$action->getstorelist();
		$count=$rsdate['count'];
        $page=$rsdate['page'];

		$m = M('dealer');
		foreach ($rsdate['list'] as $key => $value)
		{
			$dealer = $m->field('username')->where('id='.$value['dealerid'])->find();	
			$rsdate['list'][$key]['dealer'] = $dealer['username'];
		}
		
        $this->assign('storelist',$rsdate['list']);
		$this->assign('count',$count);
		if($count>10)
		{
		 $this->assign('page',$page);
		}
        $this->assign('munetype',6);
        $this->display();
    }
	
	public function addstore(){

        
		$storename=I('post.storename');
		if($storename)
		{
			$arr['dealerid'] = I('post.dealerid');
			$arr['storename'] = $storename;
			$arr['truename'] = I('post.truename');
			$arr['telephone'] = I('post.telephone');
			$arr['mobilephone'] = I('post.mobilephone');
			$arr['address'] = I('post.address');
			$arr['opentime'] = I('post.opentime');
			$arr['is_show'] = I('post.is_show');
			$arr['is_ziti'] = I('post.is_ziti');
			$arr['is_delivery'] = I('post.is_delivery');
			$arr['longitude'] = I('post.longitude');
			$arr['latitude'] = I('post.latitude');
			$arr['pic'] = I('post.pic');
			$arr['erpstoreid'] = I('post.erpstoreid');
			$m = M("store");
			$rs = $m->add($arr);
			if($rs)
			{
				$this->success('添加成功',U('/Admin/Dealer/store'));	
			}
			else
			{
				$this->error('添加失败');
			}
		
		}
		else
		{
			
			$m = M("dealer");
			$dealerlist=$m->select();
			$this->assign('dealerlist',$dealerlist);
			$this->display();
		}

		
		
    }
	
	public function editstore(){

		$id=I('get.id');
		$storename=I('post.storename');
		if(!$storename)
		{
			$m = M("dealer");
			$dealerlist=$m->select();
			$this->assign('dealerlist',$dealerlist);
			$m=M('store');
            $rs=$m->where("id=".$id)->select();
			$this->assign('store',$rs);
			$this->display();
		}
		else
		{
			$arr['id'] = I('post.id');
			$arr['dealerid'] = I('post.dealerid');
			$arr['storename'] = $storename;
			$arr['truename'] = I('post.truename');
			$arr['telephone'] = I('post.telephone');
			$arr['mobilephone'] = I('post.mobilephone');
			$arr['address'] = I('post.address');
			$arr['opentime'] = I('post.opentime');
			$arr['is_show'] = I('post.is_show');
			$arr['is_ziti'] = I('post.is_ziti');
			$arr['is_delivery'] = I('post.is_delivery');
			$arr['longitude'] = I('post.longitude');
			$arr['latitude'] = I('post.latitude');
			$arr['pic'] = I('post.pic');
			$arr['erpstoreid'] = I('post.erpstoreid');
            $m=M('Store');
            $m->save($arr);
			$this->success('修改成功',U('/Admin/Dealer/store'));	
		}
    }
	
	public function delstore(){

		$id=I('get.id');
        $m = M("store"); // 实例化User对象
        $rs=$m->where("id=$id")->delete(); // 删除id为5的用户数据
        if($rs){
            $this->success('删除成功',U('/Admin/Dealer/store'));
        }else{
            $this->error('删除失败');
        }
		
    }
	

}