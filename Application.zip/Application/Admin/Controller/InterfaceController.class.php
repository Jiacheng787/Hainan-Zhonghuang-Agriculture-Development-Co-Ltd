<?php
namespace Admin\Controller;
use Think\Controller;
use JPush\Client as JPush;

class InterfaceController extends Controller {
  private $rongyun_appKey = "";
  private $rongyun_appSecret = "";
  private $jpush_appkey = "";
  private $jpush_appsecret = "";

  public function _initialize(){
      $APP = M("system")->where("id=1")->find();
      if($APP===false){
        $result = array(
            "result"  => 0,
            "info"    => "系统错误"
          );
        echo json_encode($result);
      }
      $this->rongyun_appKey     = $APP["rongyun_appkey"];
      $this->rongyun_appSecret  = $APP["rongyun_appsecret"];
      $this->jpush_appkey       = $APP["jpush_appkey"];
      $this->jpush_appsecret    = $APP["jpush_appsecret"];
  }

	public function interactive(){
    switch($_GET['action']){
        case 'changePhone':
            $parArr = D("task_class")->where(array('parid' => 0,"isdel"=>0))->select();
            if ($parArr) {
                $parArr = array();
                foreach ($parArr as $p) {
                    $chirArr = D('task_class')->where(array('parid' => $p['id'],"isdel"=>0))->select();
                    foreach ($chirArr as $c) {
                        $chirName[$p['phonename']][] = array("sortId" => $c['id'], "sortName" => $c['classname']);
                    }
                }
                if (isset($chirName)) {
                    $return = array(
                    "result" => "1",
                    "sort" => $chirName
                    );
                }else{
                    $return = array("result" => "0");
                }
            } else {
                 $return = array("result" => "0");
            }
            echo json_encode($return);
            exit;
            break;
      }
  }


  /*----------------------------------------------------Wang--------------------------------*/
  /*
    $_POST["longitude"]   经度
    $_POST["latitude"]    纬度

  */
  public function index(){
    // $_POST["longitude"] = 1;
    // $_POST["latitude"] = 1;
    $longitude = $_POST["longitude"];
    $latitude = $_POST["latitude"];
    $action=D("Slide");
    $banner=$action->where("isdel=0")->select();
    if ($banner) {
      # 轮播图数组和广告图数组
      foreach($banner as $v){
        if($v['type']==0){
          $info['carouselimgArr'][]=array("pic"=>IMG_URL.$v['pic'],"url"=>$v['url']);
        }else if($v['type']==1){
          $info['touquimgArr'][]=array("pic"=>IMG_URL.$v['pic'],"url"=>$v['url']);
        }
      }
      if (!isset($info['carouselimgArr'])) {
        $info['carouselimgArr']=array();
      }
      if (!isset($info['touquimgArr'])) {
        $info['touquimgArr']=array();
      }
    }else{
      $info=array(
            'carouselimgArr' => array(),
            'touquimgArr'    => array(),
        );
    }

    # 公司招聘
    $company=D("Company")->where("recruitment_nums>0 and isdel=0")->select();
    if ($company) {
      # 构建公司招聘数组
      foreach($company as $c){
        # 公司类别
        $companyClass=D("Company_class")->where(array("id"=>$c['type'],"isdel"=>0))->find();
        switch ($c['list']) {
          case '0':
            $listed="未上市";
            break;
          case '1':
            $listed="已上市";
            break;
          default:
            # code...
            break;
        }
        # 招聘职务
        $recruitment=D("Recruitment")->where(array("company_id"=>$c['id'],"isdel"=>0,"status"=>1))->find();
        $oneCellArr[]=array(
          "logoImg"=>IMG_URL.$c['logo_img'],
          "infoImg"=>IMG_URL.$c['pic'],
          "ompanyName"=>$c['company_name'],
          "introduce"=>$companyClass['classname']."|".$listed."|".$c['people'],
          "position"=>$recruitment['position'],
          "positionID"=>$recruitment['position_id'],
          );
      }
    }else{
      $oneCellArr=array();
    }

    // 未被接单的
    $map["orderstate"] = array(array("egt",0),array("elt",1),"and");
    // 已经支付的
    $map["status"] = 1;
    $map["isdel"] = 0;

    # 任务数组
    $task=D("orderlist")->where($map)->order("addtime desc")->select();
    if ($task) {
      # 构建任务数组
      foreach ($task as $k=>$t) {
        # 遍历范围数组重新组合返回
        # 获取用户信息
        $user=D("member")->where(array('id'=>$t['userid'],"isdel"=>0))->find();
        if(!$user){
          unset($task[$k]);
          continue;
        }
        $type=D("task_class")->where(array('id'=>$t['type'],"isdel"=>0))->find();
        $imgArrOld=array(
          $t['pic1'],
          $t['pic2'],
          $t['pic3'],
          $t['pic4'],
          $t['pic5'],
          $t['pic6'],
          );
        # 去除数组中的空元素
        $imgArrNew=array_filter($imgArrOld);
        $imgArr=array();
        foreach ($imgArrNew as $i) {
          $imgArr[]=IMG_URL.$i;
        }
        // $longitude= '120.125';
        // $latitude = '30.2768';
        $round = getDistance($t["longitude"],$t["latitude"],$longitude,$latitude);
        $personimg=!empty($user['person_img'])?$user['person_img']:'Public/Admin/Upload_pic/header.png';


        // $order = D("orderlist");
        // $distance = $order->getDistance($latitude,$longitude,$t["latitude"],$t["longitude"]);
        $res = round($round/1000,2);
		
		$twoCellArr[]=array(
          "taskID"=>$t['id'],
          "personName"=>$user['person_name'],
          "personImg"=>IMG_URL.$personimg,
          "grade"=>$user['vip'],
          "reward"=>$t['remuneration'],
          "classification"=>$type['classname'],
          "taskTitle"=>$t['title'],
          "descriptionImg"=>$imgArr,
          "taskTime"=>$t['btime'],
          'longitude'=> $t["longitude"],
          'latitude'=> $t["latitude"],
          'place' => $t['place'],            //地图api用经纬度获取
          "round" => $res,  //两点距离
          "time"=>$this->time_tran($t['addtime']),                             
          "distance"=>(String)$res,                           //地图api获取距离
          );
      }
    }else{
      $twoCellArr=array();
    }
    $return=array(
      "result"=>"1",
      "status"=>"1",
      "infoImg"=>$info,
      "oneCellArr"=>$oneCellArr,
      "twoCellArr"=>$twoCellArr,
      );
    echo json_encode($return);
    exit;
  }

  

  //招聘首页
  public function recruitment(){
    # 构建薪资数组
    $salary=D("Salary_class")->where("isdel=0")->order('sequence desc')->select();
    if ($salary) {
      # 重构薪资数组
      foreach ($salary as $s) {
        $salaryArr[]=$s['area'];
      }
    }else{
      $salaryArr=array();
    }

    # 构建一级职位数组
    $positionPar=D("Position_class")->where("parid=0 and isdel=0")->select();
    if ($positionPar) {
      foreach ($positionPar as $pp) {
        # 重构一级职位
        $positionParArr[]=$pp['classname'];
      }
    }else{
      $positionParArr=array();
    }
    # 构建二级职位数组
    $positionChir=D("Position_class")->where("parid>0 and isdel=0")->select();
    if ($positionChir) {
      foreach ($positionChir as $pc) {
        # 重构一级职位
        $positionChirArr[]=$pc['classname'];
      }
    }else{
      $positionChirArr=array();
    }

    # 构建技术数组
    $technology=D("Technology_class")->where("isdel=0")->select();
    if ($technology) {
      foreach ($technology as $te) {
        $technologyArr[]=$te['classname'];
      }
    }else{
      $technologyArr=array();
    }

    # 构建公司招聘数组
    $company=D("Company")->where("recruitment_nums>0 and isdel=0")->select();
    if ($company) {
      # 构建公司招聘数组
      foreach($company as $c){
        # 公司类别
        $companyClass=D("Company_class")->where(array("id"=>$c['type'],"isdel"=>0))->find();
        switch ($c['list']) {
          case '0':
            $listed="未上市";
            break;
          case '1':
            $listed="已上市";
            break;
          default:
            # code...
            break;
        }
        # 公司类型
        switch ($c['type']) {
          case '0':
            $type="未上市";
            break;
          case '1':
            $type="互联网";
            break;
          default:
            # code...
            break;
        }
        # 招聘职务
        $recruitment=D("Recruitment")->where(array("company_id"=>$c['id'],"isdel"=>0,"status"=>1))->find();
        $oneCellArr[]=array(
          "position"=>$recruitment['position'],
          "salary"=>$recruitment['pay'],
          "address"=>$recruitment['place'],
          "experience"=>$recruitment['experience'],
          "logoImg"=>IMG_URL.$c['logo_img'],
          "ompanyName"=>$c['company_name'],
          "introduce"=>$c['company_name']."|".$type."|".$listed,
          "scale"=>"公司规模：".$c['people'],
          "education"=>$recruitment['education'],
          "reward"=>$recruitment['reward'],
          "addtime"=>date('Y-m-d',strtotime($recruitment['addtime'])),
          "positionID"=>$recruitment['position_id'],
          );
      }
    }else{
      $oneCellArr=array();
    }

    $return=array(
      "result"=>"1",
      "salaryArr"=>$salaryArr,
      "positionParArr"=>$positionParArr,
      "positionChirArr"=>$positionChirArr,
      "technologyArr"=>$technologyArr,
      "oneCellArr"=>$oneCellArr,
      );
    echo json_encode($return);
  }

  // 招聘报名（收藏公司招聘）
  public function signUp(){
    # 接收信息
    $userId=$_POST['userId'];                                                   //用户ID
    $recruitId=$_POST['recruitId'];                                             //招聘详情ID
    // $userId=67;                                                   //用户ID
    // $recruitId=1;  
    if ($userId && $recruitId) {
      // 检验是否已经收藏过
      $map["userid"] = $userId;
      $map["taskid"] = $recruitId;
      $map["type"]   = 1;
      $map["isdel"]  = 0;
      $res = D('mycollect')->where($map)->getField("id");
      if($res){
        $return=array(
            "result"=>"2",
            "info"  =>"已经收藏过"
          );
        echo json_encode($return);exit;
      }
      # 添加到收藏表
      $data=array(
        "userid"=>$userId,
        "taskid"=>$recruitId,
        "type"=>1,
        "addtime"=>date('Y-m-d H:i:s',time()),
        );
      $collectID=D('mycollect')->add($data);
      if ($collectID) {
        $return=array("result"=>"1");
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  // 招聘留言
  public function leaveMessage(){
    # 接收信息
    $userId=$_POST['userId'];                                                   //用户ID
    $recruitId=$_POST['recruitId'];                                             //招聘详情ID
    $message=$_POST['message'];                                                 //留言内容


    // $userId=67;                                                   //用户ID
    // $recruitId=1;                                             //招聘详情ID
    // $message=1111; 


    if ($userId && $recruitId) {
      # 添加到留言表
      $data=array(
        "userid"=>$userId,
        "recruitid"=>$recruitId,
        "message"=>$message,
        "addtime"=>date('Y-m-d H:i:s',time()),
        );
      $messageID=D('Message')->add($data);
      if ($messageID) {
        $return=array("result"=>"1");
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  //招聘详情
  public function recruitDetail(){
    # 获取公司招聘的ID
    $userId=$_POST['userId'];                                 //用户ID
    $recruitId=$_POST['recruitId'];                           //招聘ID
    // $userId=1;
    // $recruitId=1;
    if ($userId && $recruitId) {
      # 获取招聘详情
      $recruitment=D("Recruitment")->where(array("id"=>$recruitId,"isdel"=>0,"status"=>1))->find();
      if ($recruitment) {
        # 存在该招聘记录--查询用户是否已报名
        $signUp=D('Mycollect')->where(array("id"=>$recruitId,"userid"=>$userId,"type"=>1,"isdel"=>0))->find();
        if ($signUp) {
          $bitEnroll="1";
        }else{
          $bitEnroll="0";
        }

      # 查询公司详情
      $company=D('Company')->where(array("id"=>$recruitment['company_id'],"isdel"=>0))->find();
      # 公司类型
      $companyClass=D("Company_class")->where(array("id"=>$company['type'],"isdel"=>0))->find();
      # 公司简介数组
      $imgArrOld=array(
          $company['pic'],
          $company['pic1'],
          $company['pic2'],
          $company['pic3'],
          $company['pic4'],
          );
        # 去除数组中的空元素
        array_filter($imgArrOld);
        $corporationImgArr=array();
        foreach ($imgArrOld as $i) {
          $corporationImgArr[]=IMG_URL.$i;
        }
      switch ($company['list']) {
        case '0':
          $listed="未上市";
          break;
        case '1':
          $listed="已上市";
          break;
        default:
          # code...
          break;
      }
      # 任务标签数组
      $recruitment_label=D('Recruitment_label')->where(array("recruitment_id"=>$recruitId,"isdel"=>0))->select();
      if ($recruitment_label) {
        # 构建标签名称数组
        foreach ($recruitment_label as $l) {
          $label=D('Label')->where(array("id"=>$l['label_id'],"isdel"=>0))->find();
          $labelArr[]=$label['labelname'];
        }
      }
      # 报名人数统计
      $signUpNums=D('Mycollect')->where(array("taskid"=>$company['id'],"type"=>1,"isdel"=>0))->count();
      # 报名人数头像数组
      $signUp=D('Mycollect')->order('id')->limit(5)->where(array("taskid"=>$company['id'],"type"=>1,"isdel"=>0))->select();
      if ($signUp) {
        foreach ($signUp as $s) {
          # 查询相应用户信息
          $user=D('Member')->where(array("id"=>$s['userid'],"isdel"=>0,"status"=>0))->find();
          if ($user) {
            $willnumArr[]=IMG_URL.$user['person_img'];
          }
        }
      }else{
        $willnumArr=array();
      }
      # 构造返回信息
      $return=array(
        "result"=>"1",
        "bitEnroll"=>$bitEnroll,
        "corporationImgArr"=>$corporationImgArr,
        "logoImg"=>IMG_URL.$company['logo_img'],
        "corporationWeb"=>$company['url'],
        "companyClass"=>$companyClass['classname'],
        "listed"=>$listed,
        "scale"=>$company['people'],
        "position"=>$recruitment['position'],
        "salary"=>$recruitment['pay'],
        "positionType"=>$recruitment['technology'],
        "address"=>$recruitment['place'],
        "experience"=>$recruitment['experience'],
        "education"=>$recruitment['education'],
        "ompanyName"=>$company['company_name'],
        "companyAddress"=>$company['address'],
        "jobContent"=>$recruitment['describe'],
        "jobRequirements"=>$recruitment['requirement'],
        "textTeam"=>$recruitment['team'],
        "counterMark"=>$labelArr,
        "companyIntroduce"=>$company['content'],
        "reward"=>$recruitment['reward'],
        "willnum"=>$signUpNums,
        "willnumArr"=>$willnumArr,
        );
      }else{
        $return=array(
        "result"=>"0",
        );
      }
    }else{
      $return=array(
        "result"=>"0",
        );
    }
    $return = $this->remove_null($return);
    echo json_encode($return);
  }

  // 判断单子是否已被接
  /*
    $_POST["orderId"]     单子的id
    $result=>0            缺少参数
    $result=>1            可以接取
    $result=>2            不可接取
  */
  public function check_order(){
    $orderid = I("post.orderId");
    if(empty($orderid)){
      $return = array(
          "result" => "0"
        );
      exit(json_encode($return));
    }
    $map = array(
          "id"               => $orderid,
          "receive_order_id" => 0,
          "orderstatus"      => array("lt",2),
      );
    $res = M("orderlist")->where($map)->find();
    if($res){
      $return = array(
          "result" => "1"
        );
      exit(json_encode($return));
    }else{
      $return = array(
          "result" => "2"
        );
      exit(json_encode($return));
    }
  }


  # 立即接单
  /*
    jpush=>2
  */
  public function receiveOrder(){
    // $_POST['userId']=67;                    //用户ID
    // $_POST['orderId']=37;                  //任务ID
    // $_POST['phone']=15737926311;                      //联系电话
    // $_POST['message']="十分钟后到";                  //留言
    // $_POST['charge']=500;                    //要价
    $userId=$_POST['userId'];                    //用户ID
    $orderId=$_POST['orderId'];                  //任务ID
    $phone=$_POST['phone'];                      //联系电话
    $message=$_POST['message'];                  //留言
    $charge=$_POST['charge'];                    //要价
    $data=array(
      "userid"=>$userId,
      "orderid"=>$orderId,
      "phone"=>$phone,
      "message"=>$message?$message:"",
      "charge"=>$charge,
      "addtime"=>date('Y-m-d H:i:s',time()),
      );
    // $data=array(
    //   "userid"=>67,
    //   "orderid"=>37,
    //   "phone"=>15737926311,
    //   "message"=>"十分钟后到",
    //   "charge"=>500,
    //   "addtime"=>date('Y-m-d H:i:s',time()),
    //   );
    // 判断是通过身份审核
    $isexamine = M("member")->where(array("id"=>$userId))->getField("isexamine");
    if($isexamine!=1){
      $return=array(
            "result"=>"2",
            "info"  =>"身份未通过审核"
          );
      echo json_encode($return);
      exit;
    }

    $o_userid = D("orderlist")->where(array('id'=>$orderId,"receive_order_id"=>0,"isdel"=>0))->getField("userid");
    if($o_userid == $userId){
      $return=array("result"=>"2");
      echo json_encode($return);
      exit;
    }
    if(!$o_userid){
      $return=array(
            "result"=>"2",
            "info"  =>"此单无法接取"
          );
      echo json_encode($return);
      exit;
    }
    // 判断是否接过这个单
    $map = array(
        "userid"=>$userId,
        "orderid"=>$orderId,
        "isdel"=>0
      );
    $res = D('Receive_order')->where($map)->getField("id");
    if($res===false){
      $return=array(
          "result"=>"3",
          "info"  =>"数据库查询出错"
        );
      echo json_encode($return);exit;
    }elseif($res){
      $return=array(
          "result"=>"4",
          "info"  =>"你已经接过此单"
        );
      echo json_encode($return);exit;
    }
    $receive_order_id=D('Receive_order')->add($data);
    if ($receive_order_id) {
      $data2["orderstate"] = 1;
      D("orderlist")->where(array('id'=>$orderId,"isdel"=>0))->save($data2);
      // 获取发单人token
      // jpush同意接单人
      $jname = M("member")->where(array("id"=>$userId))->getField("person_name");
      // $jres = $this->jpush_msg($o_userid,"{$jname}申请接单","2");
      $jres = $this->jpush_msg($o_userid,"{$jname}申请接单","4");
      $return=array(
            "result"=>"1",
            "jpushinfo" => $jres
          );
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
    exit;
  }

  # （求职）选择职位
  public function positions(){
    $positionPar=D("Position_class")->where(array('parid'=>0,"isdel"=>0))->select();
    if ($positionPar) {
      $chirArr=array();
      foreach ($positionPar as $p) {
        $chirArr=D("Position_class")->where(array('parid'=>$p['id'],"isdel"=>0))->select();
        $chirSortArr=array();
        foreach ($chirArr as $c) {
          $chirSortArr[]=$c['classname'];
        }
        $chirName[]=array(
          "sortId"=>$p['id'],
          "sortName"=>$p['classname'],
          "chriSort"=>$chirSortArr,
          );
      }
      if (isset($chirName)) {
        $return=array(
          "result"=>"1",
          "sort"=>$chirName
          );
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  // （求职）选择技术--二维
  public function technology(){
    # 1 获取一级职务ID
    $positionID=$_POST['positionID'];                   //一级职务ID
    // $positionID=1;
    # 2 获取其子级元素组成数组
    $positionChir=D("Position_class")->where(array('parid'=>$positionID,"isdel"=>0))->select();
    if ($positionChir) {
      $techArr=array();
      foreach ($positionChir as $p) {
        # 3获取职务-技术表中相对应技术数组
        $pisitionTechArr=D("Position_technology")->where(array('position_id'=>$p['id'],"isdel"=>0))->select();
        foreach ($pisitionTechArr as $t) {
          # 4获取技术的名称
          $techArr=D("Technology_class")->where(array('id'=>$t['tech_id'],"isdel"=>0))->find();
          $tachNameArr[]=array(
            "technologyId"=>$t['id'],
            "technologyName"=>$techArr['classname'],
            );
        }
        $chirName[]=array(
          "title"=>$p['classname'],
          "tachNameArr"=>$tachNameArr,
          );
      }
      if (isset($chirName)) {
        $return=array(
          "result"=>"1",
          "sort"=>$chirName
          );
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }


    echo json_encode($return);
  }


  // 登录
  public function login(){
    # 接收信息
    $phone=isset($_POST['phone'])?$_POST['phone']:'';                                           //手机号码
    $passWord=isset($_POST['passWord'])?$_POST['passWord']:'';                                  //密码
    $thirdPartyID=isset($_POST['thirdPartyID'])?$_POST['thirdPartyID']:'';                      //第三方openid
    $type=$_POST['type'];                    //1微信 2新浪 3QQ 4账号密码登录

    // $_POST["token"] = "171976fa8a88d00f326";

    if(!$_POST["token"]){
      $result = array(
          "result"  => "0",
          "info"    => "缺少设备token"
        );
      echo json_encode($result);exit;
    }
    $token = $_POST["token"];

    // $phone="18814834968";                   //手机号码
    // $phone="18268252687";                   //手机号码
    // $passWord="123456"; 
    // $type=4;
    // $thirdPartyID="333we";                      //第三方openid
    if ($phone && $passWord && $type=="4") {
      # 根据手机号查询用户信息
      $member=D('Member')->where(array("telephone"=>$phone,"isdel"=>0,"status"=>0))->find();
      if ($member) {
        # 对比密码
        $userPassword=$member['password'];
        if (!($userPassword==md5($passWord))) {
          $return=array("result"=>"2");                   //密码不一致
          echo json_encode($return);
          exit;
        }
      }else{
        $return=array("result"=>"3");                   //账号不存在
        echo json_encode($return);
        exit;
      }
    }
    if ($type==1 || $type==2 || $type==3 && $thirdPartyID) {
      switch ($type) {
        case '1':
          # 微信登录
          $typeName="wx_openid";
          break;
        case '2':
          # 新浪登录
          $typeName="xl_openid";
          break;
        case '3':
          # QQ登录
          $typeName="qq_openid";
          break;
        
        default:
          # code...
          break;

      }
      // 查询该openid是否存在
      $member=D('Member')->where(array($typeName=>$thirdPartyID,"isdel"=>0,"status"=>0))->find();
      if (!$member) {
        # 将改用户信息插入数据库


      }
    }
    // 判断用户是否冻结
    if($member["status"]==1){
      $return=array(
        "result" => "2",
        "info"   => "该用户被冻结"
        );
      echo json_encode($return);exit;
    }
    if ($member) {
      # 统计单日登录人数
      $today=date('Y-m-d H:i:s');
      $login=D()->query("SELECT id FROM app_login WHERE Date(what_day)=Date('".$today."') LIMIT 1");
      if ($login) {
        # 已存在今日记录，登录人数自增1
        $login_num=D('Login')->where('id='.$login[0]['id'])->setInc('user_num',1);
      }else{
        $loginArr=array(
          'user_num'=>1,
          'what_day'=>date('Y-m-d'),
          );
        $login_num=D('Login')->add($loginArr);
      }
      # 新增登录详情
      $loginDetailArr=array(
        'uid'=>$member['id'],
        'account'=>$member['telephone'],
        'logintime'=>date('Y-m-d H:i:s'),
        'uip'=>$this->getIP()
        );
      $loginDetail=D('Logindetail')->add($loginDetailArr);

      // 判断用户是否换了手机

      $this->check_if_change_phone($member["id"],$token);
      
      // 判断用户是否换了手机
      # 构建返回信息
      $date=date("Y-m-d",time());
      if ($date==date('Y-m-d',strtotime($member['signtime']))) {
        $signIn="1";
      }else{
        $signIn="0";
      }
      $personimg=!empty($member['person_img'])?$member['person_img']:'Public/Admin/Upload_pic/header.png';
      // 判断个人资料是否完善
      // 判断有没有简历
      $email = M("resume")->where(array("userid"=>$member["id"],"isdel"=>0))->getField("email");
      if($member['card_id'] && $member['country'] && $member['realname'] && $member['idcard_pic1']&& $member['idcard_pic2']&& $member['idcard_pic3']){
        if($member['isexamine'] == 2){
          $isComplateReceive = "0";
        }else{
          $isComplateReceive = "1";
        }
      }else{
        $isComplateReceive = "0";
      }
      $sexarr = array("1"=>"男","2"=>"女");
      $info=array(
        "userId"=>$member['id'],
        "validateOrder"=>$member['perfect'],
        "validateJob"=>"0",
        "validateResume"=>$member['resume']>0?"1":"0",
        "signIn"=>$signIn,
        "cardId"=>$member['card_id'],   // 身份证号
        "chatID"=>$member['chat_id'],   
        "country"=>$member['country'],  // 籍贯
        "sex"=>$sexarr[$member['sex']],
        "personImg"=>IMG_URL.$personimg,
        "personName"=>$member['person_name'],
        "realName"=>$member['realname'], // 真实姓名
        "gender"=>$member['sex'],
        "birthday"=>$member['birth'],
        "signature"=>$member['signature'],
        "specialty"=>$member['specialty'],// 特长
        "integral"=>$member['integral'],
        "wallet"=>$member['wallet'],
        "isComplate"=>$isComplateReceive,   // 是否完善信息
        "isExamine"=>$member['isexamine'],  // 是否信息是否通过审核
        // "isComplateReceive"=>$isComplateReceive  //是否完善信息
        );
      $return=array(
        "result"=>"1",
        "info"=>$info
        );
      // 是否完善简历
      if($email && $member['card_id'] && $member['country'] && $member['realname']){
        $return["isComplate"]="1";
      }else{
        $return["isComplate"]="0";
      }
    }else{
      $return=array("result"=>"0");               
    }
    echo json_encode($return);exit;
  }

  // public function checkSession(){
  //   dump($_SESSION);
  //   echo time();
  // }

  // 发送短信验证码
  /*
    $_POST["phone"]     手机号
    返回参数 result=>0  处理失败
    返回参数 result=>1  处理成功
  */
  public function wap_phone(){
    // $_POST["phone"] = 18268252687;

    // $_SESSION["yzm"] = array(
    //                 "phone" => 18268252687,
    //                 "code"  => 1111,
    //                 "time"  => time(),
    //             );die;

    if($_POST){
      $phone = I('post.phone');
      $code = rand(100000,999999);
      // $_SESSION["yzm"] = array(
      //                       "phone" => $phone,
      //                       "code"  => $code,
      //                       "time"  => time(),
      //                   );
      $msg = "您的验证码：". $code . ",15分钟内有效，工作人员不会向您索取验证码等密码信息，打死都不要告诉任何人，唯一热线：400-998-2558。" ;
      // echo $msg;
      $post_data = array();
      $post_data['account'] = '11l81j';   //帐号
      $post_data['pswd'] = 'iAb96K1e';  //密码
      $post_data['msg'] =urlencode($msg); //短信内容需要用urlencode编码下
      $post_data['mobile'] = $phone; //手机号码， 多个用英文状态下的 , 隔开
      $post_data['product'] = ''; //产品ID  不需要填写
      $post_data['needstatus']='false'; //是否需要状态报告，需要true，不需要false
      $post_data['extno']='';  //扩展码   不用填写
      $url='http://send.18sms.com/msg/HttpBatchSendSM';
      $o='';
      foreach ($post_data as $k=>$v)
      {
         $o.="$k=".urlencode($v).'&';
      }
      $post_data=substr($o,0,-1);
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //如果需要将结果直接返回到变量里，那加上这句。
      $result = curl_exec($ch);
      $ress = explode(',',$result);
      // $this->ajaxReturn($ress);exit;
      if($ress[1]!=0){
          $return['result'] = "0";
          exit(json_encode($return));
      }
      $return['result'] = "1";
      $return['info'] = array(
                "code"     => $code,
                "oldPhone" => $phone,
                "time"     => time()
            );
      exit(json_encode($return));
    } 
  }

  // 手机、验证码注册
  /*
    $_POST['phone']
    $_POST['password']
    $_POST['captcha']
    $_POST["time"]
    $_POST["oldPhone"] 
  */
  public function register(){
    # 接收信息
    $phone=$_POST['phone'];                                           //手机号码
    $password=$_POST['password'];                                     //密码
    $captcha=$_POST['captcha'];                                       //验证码 1 || 0
    $time=$_POST["time"]; 
    $oldphone=$_POST["oldPhone"];                                           //有效时间

    // $phone=15737926311;                                           //手机号码
    // $password="1212";                                     
    // $captcha="2322";   
    if ($phone && $password && $captcha) {
      # 查看该手机号是否已注册
      $register=D('Member')->where(array("telephone"=>$phone,"isdel"=>0,"status"=>0))->find();
      if ($register) {
        $return=array("result"=>"2");
        echo json_encode($return);
        exit;
      }
      // 配置项
      // $api = 'https://webapi.sms.mob.com';
      // $appkey = '16f302097ae9e';
      
      // // 发送验证码到SDK服务器
      // $response =$this->postRequest( $api . '/sms/verify', array(
      //   'appkey' => $appkey,
      //   'phone' => $phone,
      //   'zone' => '86',
      //   'code' => $captcha,
      // ));
      // // 转换json数据
      // $status=json_decode($response,ture);
      // if ($status['status']==200){
      //   # 验证成功
      //   $return=array("result"=>"1");
      // }else{
      //   // $return=array("result"=>"1");
      //   $return=array("result"=>"3");
      // }

      // 验证短信验证码
      if(time() - $time > 15*60){
        // 验证码过期
        $return=array(
              "result" => "2",
              "info"   => "验证码过期"
            );
        echo json_encode($return);exit;
      }else{
        if($captcha && $oldphone == $phone){
          $return=array(
                "result" => "1",
                "info"   => "验证码成功"
              );
          echo json_encode($return);exit;
        }else{
          $return=array(
                "result" => "3",
                "info"   => "验证码失败，信息错误"
              );
          echo json_encode($return);exit;
        }
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  //完善个人信息
  /*
    $_POST["headimgState"]        
  */
  public function perfectInformation(){
    # 获取信息
    $phone=$_POST['phone'];                                     //手机号码
    $password=md5($_POST['password']);                          //密码
    // $userId=$_POST['userId'];                                   //用户id
    $person_name=$_POST['personName'];                          //用户昵称
    $real_name=$_POST['realName'];                              //真实姓名
    $gender=$_POST['gender'];                                   //性别
    $birth=$_POST['birthday'];                                  //生日
    $signature=$_POST['signature'];                             //签名
    $headimgState=$_POST["headimgState"];

    // $phone=18268252687;                                     
    // $password=md5("12131288");                                                      
    // $person_name="测试";
    // $real_name="汪洋";
    // $gender="女";
    // $birth="1992-10-03";
    // $signature="到此一游";
    if ($phone && $password && $person_name && $real_name && $gender && $birth) {
      if ($gender=="男") {
        $sex=1;
      }elseif ($gender=="女") {
        $sex=2;
      }
      $is_zhuce = M("member")->where(array("telephone"=>$phone,"isdel"=>0))->find();
      if($is_zhuce){
          $return=array("result"=>"0");
          echo json_encode($return);exit;
      }
      $signature = $signature?$signature:"";
      $data=array(
        "telephone"=>$phone,
        "password"=>$password,
        "person_name"=>$person_name,
        "realname"=>$real_name,
        "sex"=>$sex,
        "birth"=>$birth,
        "signature"=>$signature,
        );
      if($headimgState){
        // 使用默认头像
        $img = M("defaultHeadimg")->where(array("id"=>$headimgState))->getField("path");
        $data['person_img'] = $img;
      }else{
        // 上传头像
        if ($_FILES['personImg']) {
          if ($_FILES['personImg']['error']==0) {
            # 配置上传目录
            $cfg=array(
              'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
              );
            $up=new \Think\Upload($cfg);
            $move=$up->uploadOne($_FILES['personImg']);
            $picPath=$up->rootPath.$move['savepath'].$move['savename'];
            $data['person_img']="/".trim(trim($picPath,"."),"/");;
          }
        }
      }
      $userId=D('Member')->add($data);  
      if ($userId) {
        # 信息完善成功--构建返回信息
        $member=D('Member')->where(array("id"=>$userId,"isdel"=>0,"status"=>0))->find();
        $date=date("Y-m-d",time());
        if ($date==date('Y-m-d',strtotime($member['signtime']))) {
          $signIn="1";
        }else{
          $signIn="0";
        }
        $personimg=!empty($member['person_img'])?$member['person_img']:'Public/Admin/Upload_pic/header.png';
        // 保存token
        $res = $this->rongyun_token($member["id"],$member["person_name"],$personimg);
        if($res){
          // 得到token 存数据库
          $rongyun = json_decode($res);
          $token = $rongyun->token;
          $res2 = D('Member')->save(array("id"=>$userId,"chat_id"=>$token));
        }
        if ($member) {
          # 构建返回信息
          $info=array(
            "userId"=>$member['id'],
            "validateOrder"=>$member['perfect'],
            "validateJob"=>"0",
            "validateResume"=>$member['resume']>0?"1":"0",
            "signIn"=>$signIn,
            "chatID"=>isset($member['chat_id'])?$member['chat_id']:'',
            "personImg"=>IMG_URL.$personimg,
            "sex"=>$member['sex']==1?"男":"女",
            "personName"=>$member['person_name'],
            "realName"=>$member['realname'],
            "gender"=>$member['sex']==1?"男":"女",
            "birthday"=>$member['birth'],
            "signature"=>$member['signature'],
            "integral"=>$member['integral'],
            "wallet"=>$member['wallet'],
            );
          if($res && $res2){
            $info["chatID"] = $token;
          }else{
            $info["chatID"] = 0;
          }
          $return=array(
            "result"=>"1",
            "info"=>$info
            );
        }else{
          $return=array("result"=>"0");
        }
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    
    echo json_encode($return);
  }

  //找回密码
  /*
    $_POST["phone"]           用户的手机号
    $_POST["oldPhone"]        发送验证码的手机号
    $_POST["newPassword"]     密码
    $_POST["captcha"]         前台验证是否成功  1 成功 0 不成功
    $_POST["time"]            调用短信接口时返回的时间
  */
  public function findPassword(){
    # 接收信息
    $phone=$_POST['phone'];                                                 //手机号码
    $newPassword=$_POST['newPassword'];                                     //新密码
    $captcha=$_POST['captcha'];                                             //验证码
    $time = $_POST["time"];                                                 //有效时间
    $oldphone = $_POST["oldPhone"];                                            
    // exit(json_encode($_SESSION));

    // $phone=18268252687;                                           //手机号码
    // $newPassword="123456";                                     
    // $captcha="1111";
    // dump($phone && $newPassword && $captcha);
    // dump("$phone  $newPassword  $captcha");
    if ($phone && $newPassword && $captcha) {
      # 查看该手机号是否已注册
      $register=D('Member')->where(array("telephone"=>$phone,"isdel"=>0,"status"=>0))->find();
      if (!$register) {
        $return=array("result"=>"2");         //该用户不存在
        echo json_encode($return);
        exit;
      }
      // 配置项
      /*$api = 'https://webapi.sms.mob.com';
      $appkey = '16f302097ae9e';
      
      // 发送验证码到SDK服务器
      $response =$this->postRequest( $api . '/sms/verify', array(
        'appkey' => $appkey,
        'phone' => $phone,
        'zone' => '86',
        'code' => $captcha,
      ));
      // 转换json数据
      $status=json_decode($response,ture);
      if ($status['status']==200){
        # 验证成功--更新用户密码
        $change=D('Member')->where(array('telephone'=>$phone,"isdel"=>0,"status"=>0))->save(array('password'=>md5($newPassword)));
        if ($change) {
          $return=array("result"=>"1");
        }else{
          $return=array(
            "result"=>"0",
            "info"  =>"修改密码失败"
            );
        }
      }else{
        $return=array("result"=>"3");
      }*/
      // 验证短信验证码
      // dump($_SESSION);
      // dump(time() - $_SESSION["yzm"]["time"]);
      if(time() - $time > 15*60){
        // 验证码过期
        $return=array(
              "result" => "2",
              "info"   => "验证码过期"
            );
        echo json_encode($return);exit;
      }else{
        if($captcha && $oldphone == $phone){
          $change=D('Member')->where(array('telephone'=>$phone,"isdel"=>0,"status"=>0))->save(array('password'=>md5($newPassword)));
          if ($change) {
            $return=array("result"=>"1");
            echo json_encode($return);
            exit;
          }else{
            $return=array(
              "result"=>"3",
              "info"  =>"修改密码失败"
              );
            echo json_encode($return);
            exit;
          }
        }else{
          $return=array(
                "result" => "2",
                "info"   => "验证码失败，信息错误"
              );
          echo json_encode($return);exit;
        }
      }
    }else{
      $return=array(
          "result"=>"0",
          "info"  =>"缺少必要参数"
        );
      echo json_encode($return);
      exit;
    }
  }

  //签到
  public function getPoint(){
    $userid = $_POST["userId"];                                     // 用户Id 
    // $userid = 56; // 用户Id userid

    $addtime = date("Y-m-d H:i:s",time());
    $date= date("Y-m-d",time());
    if(!$userid){
      $return['result'] = "0"; //提交失败
      echo json_encode($return);
      exit;
    }
    $sign=D('Sign')->where(array('userid'=>$userid,"DATE(addtime)"=>$date,"isdel"=>0))->find();
    if($sign){
      $return['result'] = "2";                //已签到
    }else{
      $signData=array(
        "userid"=>$userid,
        "addtime"=>$addtime,
        );
      $signId=D('Sign')->add($signData);
      if($signId){
        # 签到成功给用户增加积分
        # 获取用户信息
        $user=D('Member')->where(array('id'=>$userid,"isdel"=>0,"status"=>0))->find();
        $addJifen=5;
        $integral = $user['integral']+$addJifen; //签到成功后的积分
        $endDate=date('Y-m-d',strtotime($user['signtime']));
        $tt=date('Y-m-d',strtotime('+1 day '.$endDate));
        $nowDate = date("Y-m-d",time());
        $integralDetailData=array(
          "userid"=>$userid,
          "operation"=>'签到',
          "before_integral"=>$user['integral'],
          "integral_num"=>$addJifen,
          "now_integral"=>$integral,
          "operation_type"=>'+',
          "addtime"=>$addtime,
          );
        $integrald=D('Integral')->where(array('id'=>$userid,"isdel"=>0))->add($integralDetailData);
        if($tt == $now_date){
          # 连续签到
          $userSignData=array(
            "signtime"=>$addtime,
            "sign_nums"=>$user['sign_nums']+1,
            "integral"=>$integral,
            );
          $res=D('Member')->where(array('id'=>$userid,"isdel"=>0,"status"=>0))->save($userSignData);
        }else{
          # 断签或第一次签到
          $userSignData=array(
            "signtime"=>$addtime,
            "sign_nums"=>1,
            "integral"=>$integral,
            );
          $res=D('Member')->where(array('id'=>$userid,"isdel"=>0,"status"=>0))->save($userSignData);
        }
        if ($res) {
          # 构建返回信息
          $return=array(
            "result"=>"1",
            // "integral"=>$integral,
            "integral"=>$userSignData,
            );
        }
      }else{
        $return['result'] = "0"; //操作失败
      }
    }
    echo json_encode($return);
  }

  //提现界面
  public function extract(){
    # 接收信息
    $userId=$_POST['userId'];                           //用户id
    // $userId=1;                          
    $user=D('Member')->where(array('id'=>$userId,"isdel"=>0,"status"=>0))->find();
    $min_take = "100";
    if ($user) {
      if ($user['withdraw_nums']>0) {
        $info=array(
          "realName"         =>$user['realname'],
          "cardID"           =>$user['card_id'],
          "withdrawType"     =>$user['withdraw_type'],
          "withdrawAccount"  =>$user['withdraw_account'],
          "minTake"          =>$min_take,
          );
        $return=array(
          "result"=>"1",
          "wallet" => $user['wallet'],
          "withdraw"=> "1",
          "info"=>$info,
          "minTake"=>$min_take,
          );
      }else{
        $return=array(
          "result"=>"1",
          "wallet" => $user['wallet'],
          "withdraw"=> "0",
          "minTake"=>$min_take,
          );
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  //提现操作
  public function extractOperation(){
    # 获取信息
    $userId=$_POST['userId'];                                       //用户id
    $realName=$_POST['realName'];                                   //真实姓名
    $cardID=$_POST['cardID'];                                       //身份证号
    $withdrawType=$_POST['withdrawType'];                           //提现方式
    $withdrawAccount=$_POST['withdrawAccount'];                     //提现账号
    $withdrawAmount=$_POST['withdrawAmount'];                       //提现金额
    $addtime=date('Y-m-d H:i:s',time());
    // $userId=1;                                       //用户id
    // $realName="忽然";                                   //真实姓名
    // $cardID="121212";                                       //身份证号
    // $withdrawType=1;                           //提现方式
    // $withdrawAccount="2321223";                     //提现账号
    // $withdrawAmount=400;                       //提现金额
    if ($userId && $realName &&  $cardID && $withdrawType && $withdrawAccount) {
      # 构建数组更新用户提现数据
      $data=array(
        "realname"=>$realName,
        "card_id"=>$cardID,
        "withdraw_type"=>$withdrawType,
        "withdraw_account"=>$withdrawAccount,
        );
      $res=D('Member')->where(array('id'=>$userId,"isdel"=>0,"status"=>0))->save($data);
      # 判断用户钱包余额是否大于提现金额
      $member=D('Member')->where(array('id'=>$userId,"isdel"=>0,"status"=>0))->find();
      if ($member['wallet']<$withdrawAmount) {
        # 余额小于提现金额
        $return=array(
            "result"=> "2",
            "info"  => "提现失败，钱包余额不足"
          );
        echo json_encode($return);exit;
      }
      # 构建提现信息数组生成提现记录
      $data['userid']=$userId;
      $data['withdraw_amount']=$withdrawAmount;
      $data['addtime']=$addtime;
      $withdrawId=D('Withdrawal')->add($data);
      if ($withdrawId) {
        $wallet=D('Member')->where(array('id'=>$userId,"isdel"=>0,"status"=>0))->setDec('wallet',$withdrawAmount);
        $withdrawNums=D('Member')->where(array('id'=>$userId,"isdel"=>0,"status"=>0))->setInc('withdraw_nums',1);
        $return=array("result"=>"1");
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  //账单明细(收入)
  public function bill(){
    $userId=$_POST['userId'];                     //用户id
    // $userId=3;
    # 查询用户接单信息
    $m = M("orderlist");
    $DB_PREFIX = C("DB_PREFIX");
    $join_str = "inner join {$DB_PREFIX}orderlist as o on o.id=r.orderid and o.receive_order_id = r.id";
    $receive=D('Receive_order')->alias("r")->join($join_str)->where(array('r.userid'=>$userId,'r.status'=>1,"r.isdel"=>0))->field("r.id,r.orderid,r.addtime,o.title,o.remuneration")->select();
    foreach($receive as $v){
      $w = array();
      $w["title"] = "完成 ".$v['title']." 任务获得";
      $w["status"] = "交易成功";
      $w["money"]= $v['remuneration'];
      $w["time"]= date('Y-m-d',strtotime($v['addtime']));
      $arr1[]  = $w;
      $sort1[] = strtotime($v['addtime']);
    }
    $orderlists1=$m->where(array("userid"=>$userId,"status"=>1,"refund_state"=>1,"isdel"=>0))->field("id,title,refund_fee,addtime")->select();
    foreach($orderlists1 as $v){
      $w = array();
      $w["title"] = "取消 {$v[title]} 任务后退款获得";
      $w["status"] = "退款成功";
      $w["money"]= $v['refund_fee'];
      $w["time"]= date('Y-m-d',strtotime($v['addtime']));
      $arr1[]  = $w;
      $sort1[] = strtotime($v['addtime']);
    }
    // 排序
    arsort($sort1);
    $newarr1 = array();
    foreach($sort1 as $k=>$v){
      $newarr1[] = $arr1[$k];
    }
    $withdrawal=D('withdrawal')->where(array('userid'=>$userId,'status'=>0,"isdel"=>0))->field("id,addtime,withdraw_amount")->select();
    foreach($withdrawal as $v){
      $w = array();
      $w["title"] = "提现";
      $w["status"] = "交易成功";
      $w["money"]= $v['withdraw_amount'];
      $w["time"]= date('Y-m-d',strtotime($v['addtime']));
      $arr[]  = $w;
      $sort[] = strtotime($v['addtime']);
    }
    $orderlists=$m->where(array("userid"=>$userId,"status"=>1,"isdel"=>0))->field("id,real_pay,addtime")->select();
    foreach($orderlists as $v){
      $w = array();
      $w["title"] = "发布任务";
      $w["status"] = "支付成功";
      $w["money"]= $v['real_pay'];
      $w["time"]= date('Y-m-d',strtotime($v['addtime']));
      $arr[]  = $w;
      $sort[] = strtotime($v['addtime']);
    }
    // 排序
    arsort($sort);
    $newarr = array();
    foreach($sort as $k=>$v){
      $newarr[] = $arr[$k];
    }
    $return=array(
      "result"=>"1",
      "income"=>$newarr1,
      "disburse"=>$newarr,
      );
    echo json_encode($return);
  }

  //招聘搜索
  public function positionSearch($key=""){
    $keyword=$_POST['keyword'];             //关键字
    // $keyword="php";                 
    if ($key) {
      $keyword=$key;
    }
    # 职位搜索
    $data['position']=array('like',"%$keyword%");
    $data['technology']=array('like',"%$keyword%");
    $data['_logic']='or';
    $map['_complex'] = $data;
    $map['isdel']  = 0;
    $map['status']  = 1;
    $m = D('Recruitment');
    $recruitments=$m->where($map)->order("addtime desc")->select();
    // echo $m->getLastSql();
    if ($recruitments) {
      foreach ($recruitments as $r) {
        # 查询对应的公司详情构建返回数组
        $company=D('Company')->where(array('id'=>$r['company_id'],"isdel"=>0))->find();
        switch ($company['list']) {
          case '0':
            $listed="未上市";
            break;
          case '1':
            $listed="已上市";
            break;
          default:
            # code...
            break;
        }
         # 公司类型
        switch ($company['type']) {
          case '0':
            $type="未上市";
            break;
          case '1':
            $type="互联网";
            break;
          default:
            # code...
            break;
        }
        $searchArr[]=array(
          "position"=>$r['position'],
          "salary"=>$r['pay'],
          "address"=>$r['place'],
          "experience"=>$r['experience'],
          "logoImg"=>IMG_URL.$company['logo_img'],
          "ompanyName"=>$company['company_name'],
          "introduce"=>$company['company_name']."|".$type."|".$listed,
          "scale"=>"公司规模：".$company['people'],
          "education"=>$r['education'],
          "reward"=>$r['reward'],
          "addtime"=>date('Y-m-d',strtotime($r['addtime'])),
          "positionID"=>$r['position_id'],
          );
      }
      $return=array(
        "result"=>"1",
        "searchArr"=>$searchArr,
        );
    }else{
      $return=array("result"=>"0");
    }
    if ($key) {
      return $searchArr;
    }else{
      echo json_encode($return);
    }
  }

  //任务搜索
  public function taskSearch($key=""){
    $keyword=$_POST['keyword'];             //关键字
    if ($key) {
      $keyword=$key;
    }
    // $keyword="php";                 
    # 职位搜索
    $data['title']=array('like',"%$keyword%");
    $data['isdel']=0;
    // $data['technology']=array('like',"%$keyword%");
    // $data['_logic']='or';
    # 任务数组
    $task=D("orderlist")->where($data)->order("addtime desc")->select();
    if ($task) {
      # 构建任务数组
      foreach ($task as $t) {
        # 遍历范围数组重新组合返回
        # 获取用户信息
        $user=D("member")->where(array('id'=>$t['userid'],"isdel"=>0,"status"=>0))->find();
        $type=D("task_class")->where(array('id'=>$t['type'],"isdel"=>0))->find();
        $imgArrOld=array(
          $t['pic1'],
          $t['pic2'],
          $t['pic3'],
          $t['pic4'],
          $t['pic5'],
          $t['pic6'],
          );
        # 去除数组中的空元素
        array_filter($imgArrOld);
        $imgArr=array();
        foreach ($imgArrOld as $i) {
          $imgArr[]=IMG_URL.$i;
        }
        $personimg=!empty($user['person_img'])?$user['person_img']:'Public/Admin/Upload_pic/header.png';
        $taskSearchArr[]=array(
          "taskID"=>$t['id'],
          "personName"=>$user['person_name'],
          "personImg"=>IMG_URL.$personimg,
          "grade"=>$user['vip'],
          "reward"=>$t['remuneration'],
          "classification"=>$type['classname'],
          "taskTitle"=>$t['title'],
          "descriptionImg"=>$imgArr,
          "taskTime"=>$t['btime'],
          "place"=>$t['place'],                             //地图api用经纬度获取
          "time"=>$this->time_tran($t['addtime']),                             
          "distance"=>"5km",                           //地图api获取距离
          );
      }
      $return=array(
        "result"=>"1",
        "searchArr"=>$taskSearchArr,
        );
    }else{
      $return=array("result"=>"0");
    }
    if ($key) {
      return $taskSearchArr;
    }else{
      echo json_encode($return);exit;
    }
  }

  //主页搜索
  public function indexSearch(){
    $keyword=$_POST['keyword'];             //关键字
    // $keyword="php";             
    $positionSearch=$this->positionSearch($keyword);
    $taskSearch=$this->taskSearch($keyword);
    $return=array(
      "return"=>"1",
      "positionArr"=>isset($positionSearch)?$positionSearch:array(),
      "taskArr"=>isset($taskSearch)?$taskSearch:array(),
      );
    $return=array(
      "return"=>"1",
      "positionArr"=>array(),
      "taskArr"=>array(),
      );
    echo json_encode($return);exit;
  }

  //我的收藏
  /*
    $_POST["longitude"]     
    $_POST["latitude"]      
  */
  public function myCollect(){
    $userId=$_POST['userId'];             //用户id
    $type=$_POST['type'];                 //0任务 1招聘
    $longitude = $_POST["longitude"];
    $latitude = $_POST["latitude"];
    // $userId=3;             //用户id
    // $type=0;  
    $collects=D('Mycollect')->where(array('userid'=>$userId,"type"=>$type,"isdel"=>0))->order("addtime desc")->select();
    # 用户收藏任务
    if ($collects && $type==0) {
      # 查询用户详细信息
      foreach ($collects as $tc) {
        # 查询相应任务信息
        # 任务数组
        $map["id"]         = $tc['taskid'];
        $map["isdel"]      = 0;
        $map["orderstate"] = array("elt",1);
        $task=D("Orderlist")->where($map)->find();
        if ($task) {
          # 构建任务数组
          # 获取用户信息
          $user=D("member")->where(array('id'=>$task['userid'],"isdel"=>0,"status"=>0))->find();
          $type=D("task_class")->where(array('id'=>$task['type'],"isdel"=>0))->find();
          $imgArrOld=array(
            $task['pic1'],
            $task['pic2'],
            $task['pic3'],
            $task['pic4'],
            $task['pic5'],
            $task['pic6'],
            );
          # 去除数组中的空元素
          $imgArrNew=array_filter($imgArrOld);
          $imgArr=array();
          foreach ($imgArrNew as $i) {
            $imgArr[]=IMG_URL.$i;
          }
          $personimg=!empty($user['person_img'])?$user['person_img']:'Public/Admin/Upload_pic/header.png';

          $round = getDistance($task["longitude"],$task["latitude"],$longitude,$latitude);
          $res = round($round/1000,2);

          $twoCellArr[]=array(
            "collectID"=>$tc["id"],
            "taskID"=>$task['id'],
            "personName"=>$user['person_name'],
            "personImg"=>IMG_URL.$personimg,
            "grade"=>$user['vip'],
            "reward"=>$task['remuneration'],
            "classification"=>$type['classname'],
            "taskTitle"=>$task['title'],
            "descriptionImg"=>$imgArr,
            "taskTime"=>$task['btime'],
            'longitude'=> $task["longitude"],
            'latitude'=> $task["latitude"],
            'place' => $task['place'],                 //地图api用经纬度获取
            "time"=>$this->time_tran($task['addtime']),                             
            "distance"=>(String)$res,                     //地图api获取距离
            );
        }
      }
      if(empty($twoCellArr)){
        $return=array(
          "result"=>"2",
          "info"=>"没有数据",
          );
        echo json_encode($return);exit;
      }
      $return=array(
        "result"=>"1",
        "twoCellArr"=>$twoCellArr,
        );

    }else if ($collects && $type==1) {          # 用户收藏招聘
      foreach ($collects as $pc) {
        # 获取招聘详情
        $recruitment=D("Recruitment")->where(array("id"=>$pc['taskid'],"isdel"=>0,"status"=>1))->find();
        if ($recruitment) {
          # 查询公司详情
          $company=D('Company')->where(array("id"=>$recruitment['company_id'],"isdel"=>0))->find();
          # 公司类型
          $companyClass=D("Company_class")->where(array("id"=>$company['type'],"isdel"=>0))->find();
          switch ($company['list']) {
            case '0':
              $listed="未上市";
              break;
            case '1':
              $listed="已上市";
              break;
            default:
              # code...
              break;
          }
          # 公司类型
          switch ($c['type']) {
            case '0':
              $type="未上市";
              break;
            case '1':
              $type="互联网";
              break;
            default:
              # code...
              break;
          }
        # 构造返回信息
        $oneCellArr[]=array(
          "collectID"=>$pc["id"],
          "position"=>$recruitment['position'],
          "salary"=>$recruitment['pay'],
          "address"=>$recruitment['place'],
          "experience"=>$recruitment['experience'],
          "logoImg"=>IMG_URL.$company['logo_img'],
          "ompanyName"=>$company['company_name'],
          "introduce"=>$company['company_name']."|".$type."|".$listed,
          "scale"=>"公司规模：".$company['people'],
          "education"=>$recruitment['education'],
          "reward"=>$recruitment['reward'],
          "addtime"=>date('Y-m-d',strtotime($recruitment['addtime'])),
          "positionID"=>$recruitment['position_id'],
          );
        }
      }
      if(empty($oneCellArr)){
        $return=array(
          "result"=>"2",
          "info"=>"没有数据",
          );
        echo json_encode($return);exit;
      }
      $return=array(
        "result"=>"1",
        "oneCellArr"=>$oneCellArr,
        );
    }else{
      $return=array("result"=>"0");
    }

    echo json_encode($return);exit;
  }

  // 判断手机是否被注册
  public function check_regist_phone(){
    $phone = I("phone");
    // $phone = 18268252687;
    $m = D("member");
    $map['telephone'] = $phone;
    $map['isdel'] = 0;
    $map['status'] = 0;
    $res = $m->where($map)->find();
    if($res){
      $return = array("result"=>"1");
    }else{
      $return = array("result"=>"0");
    }
    echo json_encode($return);
    exit;
  }

  
  

  // 我的资料
  /*
    $_POST['userId']   登录者的id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  数据库中没有数据
  */
  public function my_information_list(){
    // $_POST["userId"] = "57";
    $userid = $_POST["userId"];
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    $map["id"] = $userid;
    $map["isdel"] = 0;
    $map["status"] = 0;
    $m_m = M("member");
    $res = $m_m->where($map)->field("
          person_name,person_img,realname,
          sex,birth,country,card_id,
          signature,qq_number,wx_number
      ")->find();
    if($res){
      $data["result"] = "1";
      $mysex = array(1=>"男",2=>"女");
      $presonimg = $res["person_img"]?trim($res["person_img"],"."):'Public/Admin/Upload_pic/header.png';
      $res['person_img'] = IMG_URL.$presonimg;
      $res['sex'] = $mysex[$res['sex']];
      $res["birth"] = date("Y-m-d",strtotime($res["birth"]));
      $data["info"] = $res;
      $data = $this->remove_null($data);
      echo json_encode($data);
      exit;

    }else{
      // 缺少参数
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }

  // 修改我的资料
  /*
    $_POST["userId"]   登陆者的id
    $_POST过来需要修改的字段
    字段包含：
    person_name,realname,
    sex,birth,country,card_id,
    signature,qq_number,wx_number
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  没有修改权限
    返回参数 result=>3  修改失败
  */
  public function edit_my_infomation(){
    // $_POST["userId"] = 67;
    // $_POST["sex"] = "1";
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    // 修改权限列表
    $quanxian = array(
      "person_name","realname",
      "sex","birth","country","card_id",
      "signature","qq_number","wx_number"
      );
    $userid = $_POST["userId"];
    unset($_POST["userId"]); // 删除id剩下其他的
    $data = $_POST;
    foreach($data as $k=>$v){
      if(!in_array($k,$quanxian)){
        $result = array("result" => "2");
        echo json_encode($result);
        exit;
      }
    }
    $map['id'] = $userid;
    $map['isdel'] = 0;
    $map['status'] = 0;
    $res = M("member")->where($map)->setField($data);
    if($res !== false){
      $result = array("result" => "1");
    }else{
      $result = array("result" => "3");
    }
    echo json_encode($result);
    exit;
  }

  // 修改资料  —— 修改头像
  /*
    $_FILES["person_img"]   用户头像
    $_POST["userId"]        用户Id
    $_POST["headimgState"]  
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  修改失败
    返回参数 result=>3  缺少上传的头像

  */
  public function edit_my_header(){
    if((!isset($_FILES["person_img"]) && !$_POST["headimgState"]) || !isset($_POST["userId"])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    $map["id"] = $_POST["userId"];
    $map["isdel"] = 0;
    $map["status"] = 0;
    $headimgState = $_POST["headimgState"];
    if($headimgState){
      // 使用默认头像
      $img = M("defaultHeadimg")->where(array("id"=>$headimgState))->getField("path");
      $data['person_img'] = $img;
    }else{
      if($_FILES["person_img"]){
        if ($_FILES["person_img"]['error']==0) {
            # 配置上传目录
            $cfg=array(
              'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
              );
            $up=new \Think\Upload($cfg);
            $move=$up->uploadOne($_FILES["person_img"]);
            $picPath=$up->rootPath.$move['savepath'].$move['savename'];
            $data["person_img"]="/".trim(trim($picPath,"."),"/");;
        }
      }else{
        // 缺少上传数据
        $result = array("result"=>"3");
        echo json_encode($result);
        exit;
      }
    }
    $res = M("member") -> where($map) ->save($data);
    if($res){
      // 修改头头像成功
      $result = array("result"=>"1");
      echo json_encode($result);
      exit;
    }else{
      // 修改失败
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }

  // 添加技能认证
  /*
    $_POST["memberId"]      用户id
    $_POST["trueName"]      真实姓名
    $_POST["title"]         称号名称
    $_POST["card"]          证书编号
    $_FILES["pic1"]         证书照片页图片
    $_FILES["pic2"]         证书编号页图片
    $_FILES["pic3"]         手持证件头部照
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  保存数据失败
  */
  public function credential_upload(){
    if(!isset($_POST["memberId"]) || 
       !isset($_POST["trueName"]) || 
       !isset($_POST["card"]) ||
       !isset($_POST["title"]) ||
       !isset($_FILES)){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);exit;
    }
    $data["memberid"] = $_POST["memberId"]?$_POST["memberId"]:"";
    $data["truename"] = $_POST["trueName"]?$_POST["trueName"]:"";
    $data["card"]     = $_POST["card"]?$_POST["card"]:"";
    $data["title"]     = $_POST["title"]?$_POST["title"]:"";
    // 上传图片
    if ($_FILES) {
      foreach ($_FILES as $key=>$file) {
        if ($file['error']==0) {
          # 配置上传目录
          $cfg=array(
            'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
            );
          $up=new \Think\Upload($cfg);
          $move=$up->uploadOne($_FILES[$key]);
          $picPath=$up->rootPath.$move['savepath'].$move['savename'];
          $data[$key]="/".trim(trim($picPath,"."),"/");;
        }
      }
    }
    $res = M("credential")->add($data);
    if($res){
      // 保存数据失败
      $result = array("result"=>"1");
      echo json_encode($result);exit;
    }else{
      // 保存数据失败
      $result = array("result"=>"2");
      echo json_encode($result);exit;
    }
  }

  // 技能认证 ———— 列表
  /*
    $_POST["userId"]    登录用户的id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  请求成功
    返回参数 result=>2  数据库无数据
  */
  public function credential_list(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $map["memberid"] = $userid;
    $map["isdel"] = 0;
    $res = M("credential") -> field("id,title,pic1") -> where($map) ->select();
    if($res){
      $data = array("result"=>"1");
      foreach($res as $k=>$v){
        $data["info"][] = array(
            "credentialId"  => $v['id'],
            "title"         => $v['title'],
            "pic1"  => $this->deal_img($v['pic1'])
          );
      }
      $data = $this->remove_null($data);
      echo json_encode($data);exit;
    }else{
      // 没有数据
      $result = array("result"=>"2");
      echo json_encode($result);exit;
    }
  }

  
  // 简历 ———— 简历列表
  /*
    $_POST["userId"]  用户id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  请求成功
    返回参数 result=>2  该用户没有简历
    返回参数 result=>3  获取工作经验失败
    返回参数 result=>4  获取项目经验失败
    返回参数 result=>5  获取教育经历失败
  */
  public function resume_list(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $r_m = M("resume");
    $map["userid"] = $userid;
    $map["isdel"] = 0;
    $res = $r_m -> where($map) -> find();
    if($res){
      // $range = M("workingLife")->where(array("id"=>$res["worklifeid"],"isdel"=>0))->getField("range");
      $data = array(
          "resumeid" => $res["id"],
          "email" => $res["email"],
          "personalNote" => $res["personalnote"],
          "workingLife"  => $res["worklifeid"]
        );
      // 表前缀
      $DB_PREFIX = C("DB_PREFIX");
      // 简历关联id
      $map2["resumeid"] = $res['id'];
      // 获取工作经验
      $ex_m = M("resumeExperience");
      // 获取companyClass
      $comp_class = M("companyClass")->where("isdel=0")->field("id,classname")->select();
      $comp_class_arr = array();
      foreach($comp_class as $v){
        $comp_class_arr[$v["id"]] = $v["classname"];
      }
      // 及时释放资源
      unset($comp_class);
      // 此处用join
      $join_str = "inner join {$DB_PREFIX}experience as ex on r_ex.experienceid = ex.id and ex.isdel=0 and r_ex.isdel=0";
      $res2 = $ex_m -> alias("r_ex") -> where($map2) -> 
              join($join_str) -> order("addtime desc") -> 
              field("ex.id as experienceid,job,startTime,endTime,trade,post,jobDescription")->
              select();
      if($res2 === false){
        $result = array(
            "result"=>"3",
            "info"  =>"获取工作经验失败"
          );
        echo json_encode($result);exit;
      }else{
        foreach($res2 as $k=>$v){
          $res2[$k]["startTime"] = $v["starttime"]?date("Y-m",strtotime($v["starttime"])):"";
          $res2[$k]["endTime"]   = $v["endtime"]?date("Y-m",strtotime($v["endtime"])):"";
          $res2[$k]["tradeid"]   = $v["trade"];
          $res2[$k]["trade"]     = $comp_class_arr[$v["trade"]];
          unset($res2[$k]["starttime"]);
          unset($res2[$k]["endtime"]);
        }
        $data["experienceArr"] = $res2;
        // 释放资源
        unset($ex_m);
      }
      // 获取项目经验
      $r_p_m = M("resumeProject");
      // 此处用join
      $join_str = "inner join {$DB_PREFIX}project as p on r_p.projectid = p.id and r_p.isdel=0 and p.isdel=0";
      $res3 = $r_p_m -> alias("r_p") -> where($map2) -> 
              join($join_str) -> order("addtime desc") -> 
              field("p.id as projectid,projectName,startTime,endTime,projectdescription")->
              select();

      if($res3 === false){
        $result = array(
            "result"=>"4",
            "info"  =>"获取项目经验失败"
          );
        echo json_encode($result);exit;
      }else{
        foreach($res3 as $k=>$v){
          $res3[$k]["startTime"] = $v["starttime"]?date("Y-m",strtotime($v["starttime"])):"";
          $res3[$k]["endTime"]   = $v["endtime"]?date("Y-m",strtotime($v["endtime"])):"";
          unset($res3[$k]["starttime"]);
          unset($res3[$k]["endtime"]);
        }
        $data["projectExperienceArr"] = $res3;
        // 释放资源
        unset($r_p_m);
      }
      // 获取教学经历
      $r_e_m = M("resumeEducation");
      // 此处用join
      $join_str = "inner join {$DB_PREFIX}education as e on r_e.educationid = e.id and r_e.isdel=0 and e.isdel=0";
      $res4 = $r_e_m -> alias("r_e") -> where($map2) -> 
              join($join_str) -> order("addtime desc") -> 
              field("e.id as educationid,school,startTime,endTime,specialty,education")->
              select();

      if($res4 === false){
        $result = array(
            "result"=>"5",
            "info"  =>"获取教育经历失败"
          );
        echo json_encode($result);exit;
      }else{
        $edu_arr = array();
        foreach($res4 as $k=>$v){
          $res4[$k]["startTime"] = $v["starttime"]?date("Y-m",strtotime($v["starttime"])):"";
          $res4[$k]["endTime"]   = $v["endtime"]?date("Y-m",strtotime($v["endtime"])):"";
          $edu_arr[] = array(
              "education" => $v["education"],
              "endTime"   => strtotime($v["endtime"])
            );
          unset($res4[$k]["starttime"]);
          unset($res4[$k]["endtime"]);
        }
        if($edu_arr){
          $max_edu = array(
              "key"=>0,
              "endTime"=>0
            );
          foreach($edu_arr as $k => $v){
            if($v["endTime"]===false){
              $max_edu["key"] = $k;
              break;
            }elseif($v["endTime"]>$max_edu["endTime"]){
              $max_edu["key"] = $k;
              $max_edu["endTime"] = $v["endTime"];
            }
          }
          $data["education"] = $edu_arr[$max_edu["key"]]["education"];
        }else{
          $data["education"] = "0";
        }
        $data["educationExperienceArr"] = $res4;
        // 释放资源
        unset($r_e_m);
      }
      $data = $this->remove_null($data);
      echo json_encode($data);exit;
    }elseif($res !== false){
      // 没有简历则创建简历
      $data = array(
          "userid" => $userid,
          "addtime"=> date("Y-m-d H:i:s",time())
        );
      $res2 = $r_m->add($data);
      if($res2){
        $result = array(
            "resumeid" => $res2
          );
        $result = $this->remove_null($result);
        echo json_encode($result);exit;
      }else{
        $result = array(
            "result"=>"2",
            "info"  =>"创建该简历失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result"=>"6",
          "info"  =>"数据库操作失败"
        );
      echo json_encode($result);exit;
    }
  }


  // 简历 ———— 修改邮箱和个人信息和工作年限
  /*
    $_POST["userId"]    用户id
    $_POST["resumeId"]  简历Id
    $_POST 以下字段：
      email、personalNote,workLifeId;
    返回参数 result=>0  缺少参数
    返回参数 result=>1  修改成功
    返回参数 result=>2  修改参数错误
    返回参数 result=>3  修改失败
  */
  public function edit_email_note(){
    // $_POST["userId"] = 1;
    // $_POST["resumeId"] = 1;
    // $_POST["email"] = "555@qq.com";
    // $_POST["personalNote"] = "aaaa";
    // $_POST["workLifeId"] = "111";
    if(!isset($_POST["userId"]) || !isset($_POST["resumeId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid   = $_POST["userId"];
    $resumeid = $_POST["resumeId"];
    unset($_POST["userId"]);
    unset($_POST["resumeId"]);
    $data = $_POST;
    // 权限数组
    $quanxian = array("email","personalNote","workLifeId");
    foreach($data as $k=>$v){
      if(!in_array($k,$quanxian)){
        $result = array(
            "result"=>"2",
            "info"  =>"修改参数错误"
          );
        echo json_encode($result);exit;
      }
    }
    $map['userid'] = $userid;
    $map['id'] = $resumeid;
    $map['isdel'] = 0;
    $m = M("resume");
    $res = $m -> where($map) ->save($data);
    if($res){
      $result = array(
          "result"=>"1",
          "info"  =>"修改成功"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"3",
          "info"  =>"修改失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 简历 ———— 添加修改删除工作经验
  /*
    $_POST["resumeId"]         简历id，添加 的时候发送
    $_POST["userId"]           用户id，添加 的时候发送
    $_POST["experienceId"]     工作经验表的id，修改 和 删除 的时候发送
    $_POST["gesture"]          1表示添加  2表示修改 3表示删除
    以下是 添加 和 修改 的时候发送
    $_POST["job"]              工作的公司
    $_POST["startTime"]        开始时间
    $_POST["endTime"]          结束时间
    $_POST["trade"]            行业：companyClass的id
    $_POST["post"]             岗位名称
    $_POST["jobDescription"]   工作描述
    返回参数 result=>0  缺少参数
    返回参数 result=>1  成功
    返回参数 result=>2  参数错误
    返回参数 result=>3  添加失败
    返回参数 result=>4  添加关联表失败
    返回参数 result=>5  修改失败
    返回参数 result=>6  删除失败
    返回参数 result=>7  删除工作经验成功，删除关联字段失败
  */
  public function edit_experience(){
    // $_POST = array(
    //     "userId"           => 67,
    //     "gesture"          => 1,
    //     "resumeId"         => 1,
    //     // "experienceId"     => ,
    //     "job"              => "测试添加",
    //     "startTime"        => "2016-9-21",
    //     // "endTime"          => ,
    //     "trade"            => 1,
    //     "post"             => "aaaaa",
    //     "jobDescription"   => "bbbbb"
    //   );

    // $_POST = array(
    //     // "userId"           => 67,
    //     "gesture"          => 2,
    //     // "resumeId"         => 1,
    //     "experienceId"     => 1,
    //     "job"              => "测试修改",
    //     "startTime"        => "2015-9-21",
    //     "endTime"          => "2016-2-21",
    //     "trade"            => 1,
    //     "post"             => "aaaaa",
    //     "jobDescription"   => "bbbbb"
    //   );

    // $_POST = array(
    //     "gesture"          => 3,
    //     "experienceId"     => 5
    //   );
    if(!isset($_POST["gesture"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    // $quanxian = array("job,startTime","endTime","trade","post","jobDescription");
    $resumeid     = $_POST["resumeId"];
    $userid       = $_POST['userId'];
    $experienceid = $_POST['experienceId'];
    $gesture      = $_POST['gesture'];
    $data         = $_POST;
    $m            = M("experience");
    switch($gesture){
      case 1:
        // 1表示添加
        $add_data = array(
            "job"              => $data["job"],
            "startTime"        => $data["startTime"],
            "endTime"          => $data["endTime"],
            "trade"            => $data["trade"],
            "post"             => $data["post"],
            "jobDescription"   => $data["jobDescription"],
            "addtime"          => date("Y-m-d H:i:s",time())
          );
        $res = $m->add($add_data);
        if($res){
          $new_r_e = array(
              "resumeid"     => $resumeid,
              "experienceid" => $res
            );
          $res2 = M("resumeExperience") -> add($new_r_e);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"添加成功"
              );
            echo json_encode($result);exit;
          }else{
            $result = array(
                "result"=>"4",
                "info"  =>"添加关联表失败"
              );
            $m->where("id=$res")->delete();
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"3",
              "info"  =>"添加失败"
            );
          echo json_encode($result);exit;
        }
        break;
      case 2:
        //2表示修改
        // 处理时间
        $data["startTime"] = date("Y-m-d H:i:s",strtotime($data["startTime"]));
        $newendTime = date("Y-m-d H:i:s",strtotime($data["endTime"]));
        $edit_data = array(
            "job"              => $data["job"],
            "startTime"        => $data["startTime"],
            "endTime"          => $data["endTime"]?$newendTime:null,
            "trade"            => $data["trade"],
            "post"             => $data["post"],
            "jobDescription"   => $data["jobDescription"]
          );
        $res = $m ->where(array("id"=>$experienceid,"isdel"=>0))-> save($edit_data);
        if($res!==false){
          $result = array(
              "result"=>"1",
              "info"  =>"修改成功"
            );
          echo json_encode($result);exit;
        }else{
          $result = array(
              "result"=>"5",
              "info"  =>"修改失败"
            );
          echo json_encode($result);exit;

        }
        break;
      case 3:
        //3表示删除
        $data["isdel"] = 1;
        $res = $m -> where("id=$experienceid") ->save($data);
        if($res){
          $res2 = M("resumeExperience") -> where("experienceid=$experienceid") ->save($data);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"删除成功"
              );
            echo json_encode($result);exit;

          }else{
            $result = array(
                "result"=>"7",
                "info"  =>"删除工作经验成功，删除关联字段失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"6",
              "info"  =>"删除失败"
            );
          echo json_encode($result);exit;
        }
        break;
      default:
        $result = array(
            "result"=>"2",
            "info"  =>"参数错误"
          );
        echo json_encode($result);exit;
    }
  }

  // 简历 ———— 添加修改删除项目经验
  /*
    $_POST["resumeId"]         简历id，添加 的时候发送
    $_POST["userId"]           用户id，添加 的时候发送
    $_POST["projectId"]        项目经验表的id，修改 和 删除 的时候发送
    $_POST["gesture"]          1表示添加  2表示修改 3表示删除
    以下是 添加 和 修改 的时候发送

    $_POST["projectName"]         项目名称
    $_POST["startTime"]           开始时间
    $_POST["endTime"]             结束时间
    $_POST["projectdescription"]  项目描述

    返回参数 result=>0  缺少参数
    返回参数 result=>1  成功
    返回参数 result=>2  参数错误
    返回参数 result=>3  添加失败
    返回参数 result=>4  添加关联表失败
    返回参数 result=>5  修改失败
    返回参数 result=>6  删除失败
    返回参数 result=>7  删除项目经验成功，删除关联字段失败
  */
  public function edit_project(){
    // $_POST = array(
    //     "userId"           => 67,
    //     "gesture"          => 1,
    //     "resumeId"         => 1,
    //     "projectName"              => "测试添加",
    //     "startTime"        => "2016-9-21",
    //     // "endTime"          => ,
    //     "projectdescription"   => 1,
    //   );

    // $_POST = array(
    //     "gesture"          => 2,
    //     "projectId"     => 2,
    //     "projectName"              => "测试修改",
    //     "startTime"        => "2016-9-21",
    //     // "endTime"          => ,
    //     "projectdescription"   => 1,
    //   );

    // $_POST = array(
    //     "gesture"          => 3,
    //     "projectId"     => 3
    //   );
    if(!isset($_POST["gesture"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    // $quanxian = array("job,startTime","endTime","trade","post","jobDescription");
    $resumeid     = $_POST["resumeId"];
    $userid       = $_POST['userId'];
    $projectid    = $_POST['projectId'];
    $gesture      = $_POST['gesture'];
    $data         = $_POST;
    $m            = M("project");
    switch($gesture){
      case 1:
        // 1表示添加
        $add_data = array(
            "projectName"        => $data["projectName"],
            "startTime"          => $data["startTime"],
            "endTime"            => $data["endTime"],
            "projectdescription" => $data["projectdescription"],
            "addtime"            => date("Y-m-d H:i:s",time())
          );
        $res = $m->add($add_data);
        if($res){
          $new_r_e = array(
              "resumeid"     => $resumeid,
              "projectid" => $res
            );
          $res2 = M("resumeProject") -> add($new_r_e);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"添加成功"
              );
            echo json_encode($result);exit;
          }else{
            $result = array(
                "result"=>"4",
                "info"  =>"添加关联表失败"
              );
            $m->where("id=$res")->delete();
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"3",
              "info"  =>"添加失败"
            );
          echo json_encode($result);exit;
        }
        break;
      case 2:
        //2表示修改
        // 处理时间
        $data["startTime"] = date("Y-m-d H:i:s",strtotime($data["startTime"]));
        $newendTime = date("Y-m-d H:i:s",strtotime($data["endTime"]));
        $edit_data = array(
            "projectName"        => $data["projectName"],
            "startTime"          => $data["startTime"],
            "endTime"            => $data["endTime"]?$newendTime:null,
            "projectdescription" => $data["projectdescription"]
          );
        $res = $m ->where(array("id"=>$projectid,"isdel"=>0))-> save($edit_data);
        if($res!==false){
          $result = array(
              "result"=>"1",
              "info"  =>"修改成功"
            );
          echo json_encode($result);exit;
        }else{
          $result = array(
              "result"=>"5",
              "info"  =>"修改失败"
            );
          echo json_encode($result);exit;

        }
        break;
      case 3:
        //3表示删除
        $data["isdel"] = 1;
        $res = $m -> where("id=$projectid") ->save($data);
        if($res){
          $res2 = M("resumeProject") -> where("projectid=$projectid") ->save($data);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"删除成功"
              );
            echo json_encode($result);exit;

          }else{
            $result = array(
                "result"=>"7",
                "info"  =>"删除项目经验成功，删除关联字段失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"6",
              "info"  =>"删除失败"
            );
          echo json_encode($result);exit;
        }
        break;
      default:
        $result = array(
            "result"=>"2",
            "info"  =>"参数错误"
          );
        echo json_encode($result);exit;
    }
  }



  // 简历 ———— 添加修改删除教育经历
  /*
    $_POST["resumeId"]         简历id，添加 的时候发送
    $_POST["userId"]           用户id，添加 的时候发送
    $_POST["educationId"]      教育经历表的id，修改 和 删除 的时候发送
    $_POST["gesture"]          1表示添加  2表示修改 3表示删除
    以下是 添加 和 修改 的时候发送

    $_POST["school"]         学校名称
    $_POST["startTime"]      开始时间
    $_POST["endTime"]        结束时间
    $_POST["specialty"]      专业
    $_POST["education"]      学历

    返回参数 result=>0  缺少参数
    返回参数 result=>1  成功
    返回参数 result=>2  参数错误
    返回参数 result=>3  添加失败
    返回参数 result=>4  添加关联表失败
    返回参数 result=>5  修改失败
    返回参数 result=>6  删除失败
    返回参数 result=>7  删除教育经历成功，删除关联字段失败
  */
  public function edit_education(){
    // $_POST = array(
    //     "userId"           => 67,
    //     "gesture"          => 1,
    //     "resumeId"         => 1,
    //     "school"           => "测试添加",
    //     "startTime"        => "2012-9-21",
    //     "endTime"          => "2016-6-21",
    //     "specialty"        => "adasdasdad",
    //     "education"        => "asdasd阿萨德撒大所1321",
    //   );

    // $_POST = array(
    //     "gesture"          => 2,
    //     "educationId"     => 1,
    //     "school"              => "测试修改",
    //     "startTime"        => "2016-9-21",
    //     "endTime"          =>  "2015-9",
    //     "specialty"   => 1,
    //     "education"   => 1,
    //   );

    // $_POST = array(
    //     "gesture"          => 3,
    //     "educationId"     => 2
    //   );
    if(!isset($_POST["gesture"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    // $quanxian = array("job,startTime","endTime","trade","post","jobDescription");
    $resumeid     = $_POST["resumeId"];
    $userid       = $_POST['userId'];
    $educationid  = $_POST['educationId'];
    $gesture      = $_POST['gesture'];
    $data         = $_POST;
    $m            = M("education");
    switch($gesture){
      case 1:
        // 1表示添加
        $add_data = array(
            "school"             => $data["school"],
            "startTime"          => $data["startTime"],
            "endTime"            => $data["endTime"],
            "specialty"          => $data["specialty"],
            "education"          => $data["education"],
            "addtime"            => date("Y-m-d H:i:s",time())
          );
        $res = $m->add($add_data);
        if($res){
          $new_r_e = array(
              "resumeid"     => $resumeid,
              "educationid"  => $res
            );
          $res2 = M("resumeEducation") -> add($new_r_e);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"添加成功"
              );
            echo json_encode($result);exit;
          }else{
            $result = array(
                "result"=>"4",
                "info"  =>"添加关联表失败"
              );
            $m->where("id=$res")->delete();
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"3",
              "info"  =>"添加失败"
            );
          echo json_encode($result);exit;
        }
        break;
      case 2:
        //2表示修改
        // 处理时间
        $data["startTime"] = date("Y-m-d H:i:s",strtotime($data["startTime"]));
        $newendTime = date("Y-m-d H:i:s",strtotime($data["endTime"]));
        $edit_data = array(
            "school"             => $data["school"],
            "startTime"          => $data["startTime"],
            "endTime"            => $data["endTime"]?$newendTime:null,
            "specialty"          => $data["specialty"],
            "education"          => $data["education"],
          );
        $res = $m ->where(array("id"=>$educationid,"isdel"=>0))-> save($edit_data);
        if($res!==false){
          $result = array(
              "result"=>"1",
              "info"  =>"修改成功"
            );
          echo json_encode($result);exit;
        }else{
          $result = array(
              "result"=>"5",
              "info"  =>"修改失败"
            );
          echo json_encode($result);exit;

        }
        break;
      case 3:
        //3表示删除
        $data["isdel"] = 1;
        $res = $m -> where("id=$educationid") ->save($data);
        if($res){
          $res2 = M("resumeEducation") -> where("educationid=$educationid") ->save($data);
          if($res2){
            $result = array(
                "result"=>"1",
                "info"  =>"删除成功"
              );
            echo json_encode($result);exit;

          }else{
            $result = array(
                "result"=>"7",
                "info"  =>"删除教育经历成功，删除关联字段失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"6",
              "info"  =>"删除失败"
            );
          echo json_encode($result);exit;
        }
        break;
      default:
        $result = array(
            "result"=>"2",
            "info"  =>"参数错误"
          );
        echo json_encode($result);exit;
    }
  }
  // 什么时候有空了把上面三个接口合并

  // 第三方登录



  // 所在行业列表
  public function company_class_list(){
    $m = M("companyClass");
    $res = $m->field("id,classname")->where("isdel=0")->order("sequence asc")->select();
    $res = $this->remove_null($res);
    echo json_encode($res);exit;
  }


  // 积分明细
  /*
    $_POST["userId"]    登陆者id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  成功
    返回参数 result=>2  数据库无数据
  */
  public function integral_detail_list(){
    // $_POST["userId"] = 1;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $m = M("integral");
    $map["userid"] = $userid;
    $map["isdel"] = 0;
    $integral = $m->where($map)->field("operation,integral_num,now_integral,operation_type,addtime")->order("addtime desc")->select();
    if($integral){
      $result["result"] = "1";
      foreach($integral as $v){
        $data[] = array(
            "operation"     => $v["operation"],             // 积分事件
            "now_integral"  => $v["now_integral"],          // 操作后的积分
            "operation_num" => $v["operation_type"].$v["integral_num"], // 积分变化
            "addtime"       => $v["addtime"]                // 积分操作时间
          );
      }
      $data = $this->remove_null($data);
      $result["info"] = $data;
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"数据库无数据"
        );
      echo json_encode($result);exit;
    }
  }

  // 取消收藏
  /*
    $_POST["collectId"]   收藏的id
    $_POST["userId"]      用户id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  操作失败
  */
  public function cancel_collect(){
    // $_POST["userId"] = 67;
    // $_POST["collectId"] = 12;
    if(!isset($_POST["userId"]) || !isset($_POST["collectId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $map["userid"] = $_POST["userId"];
    $map["id"] = $_POST["collectId"];
    $data["isdel"] = 1;
    $res = M("mycollect")->where($map)->save($data);
    if($res){
      $result = array(
          "result"=>"1",
          "info"  =>"操作成功"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"操作失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 删除技能认证
  /*
    $_POST["userId"]          登录用户id
    $_POST["credentialId"]    技能认证id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  删除失败
  */
  public function del_credential(){
    // $_POST["userId"] = 67;
    // $_POST["credentialId"] = 1;
    if(!isset($_POST["userId"]) || !isset($_POST["credentialId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $map["memberid"] = $_POST["userId"];
    $map["id"] = $_POST["credentialId"];
    $data["isdel"] = 1;
    $res = M("credential")->where($map)->save($data);
    if($res){
      $result = array(
          "result"=>"1",
          "info"  =>"操作成功"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"删除失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 工作年限 列表接口
  /*
    返回参数 result=>1  操作成功
    返回参数 result=>2  查看失败
  */
  public function working_life_list(){
    $res = M("workingLife")->where(array("isdel"=>0))->field("id,range")->order("squence desc")->select();
    if($res){
      $result = array(
          "result"=>"1",
          "info"  =>$res
        );
      echo json_encode($result);exit;

    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"查看失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 修改工作年限 接口
  /*
    $_POST["resumeId"]      简历id
    $_POST["userId"]        登录用户的id
    $_POST["workLifeId"]    工作年限的id
    返回参数 result=>1  操作成功
    返回参数 result=>2  查看失败
  */
  public function edit_working_life(){
    // $_POST["userId"] = 67;
    // $_POST["resumeId"] = 1;
    // $_POST["workLifeId"] = 2;
    if(!isset($_POST["userId"]) || !isset($_POST["resumeId"]) || !isset($_POST["workLifeId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $map["userid"] = $userId;
    $map["resumeid"] = $resumeId;
    $map["isdel"] = 0;
    $data["workLifeId"] = $workLifeId;
    $res = M("resume")->where($map)->save($data);
    if($res===false){
      $result = array(
          "result"=>"0",
          "info"  =>"修改失败"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"1",
          "info"  =>"修改成功"
        );
      echo json_encode($result);exit;
    }
  }

  // 个人详情
  /*
    $_POST["userId"]        登陆者的id
    $_POST["memberId"]     查看资料的id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  获取失败
  */
  public function user_detail(){
    // $_POST["memberId"] = 2;
    // $_POST["userId"]   = 56;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid         = $_POST["userId"];
    $memberid       = $_POST["memberId"];
    $m_m            = M("member");
    $map["id"]      = $memberid;
    $map["isdel"]   = 0;
    $map["status"]  = 0;

    $userdetail = $m_m->where($map)->field("id as memberid,person_img,
          person_name,sex,country,signature,credit
        ")->find();
    if($userdetail){
      $data = array(
            "memberid"    => $userdetail["memberid"],
            "person_img"  => $this->deal_img($userdetail["person_img"]),
            "person_name" => $userdetail["person_name"],
            "sex"         => $userdetail["sex"]==2?"女":"男",
            "signature"   => $userdetail["signature"],
            "country"     => $userdetail["country"],
            "credit"      => $userdetail["credit"]
          );
      // 发单数
      $o_m  = M("orderlist");
      $map2["userid"] =  $memberid;
      $map2["isdel"] =  0;
      $order_num = $o_m->where($map2)->count();
      $data["order_num"] = $order_num;
      // 接单数
      $r_o_m  = M("receiveOrder");
      $map2["userid"] =  $memberid;
      $map2["isdel"]  =  0;
      $map2["status"] =  1;
      $recevie_num = $r_o_m->where($map2)->count();
      $data["recevie_num"] = $recevie_num;
      // 证书数
      $c_m  = M("credential");
      $map3["memberid"] =  $memberid;
      $map3["isdel"] =  0;
      $credential_num = $c_m->where($map3)->count();
      $data["credential_num"] = $credential_num;
      // 双方评价总数
      $DB_PREFIX = C('DB_PREFIX');
      $count1 = $o_m->where(array("userid"=>$memberid,"orderstate"=>6))->count();
      $count2 = $o_m->alias("o")->where(array("o.userid"=>$memberid))->
          join("inner join {$DB_PREFIX}receive_order as r on r.id = o.receive_order_id and r.status=1")->count();
      $data["comment_num"] = (String)($count1+$count2);
      // 判断是否为好友
      if($userid != $memberid){
        $data["isfriend"] = $this->is_friend($userid,$memberid);
      }
      $data = $this->remove_null($data);
      $result = array(
          "result"=>"1",
          "info"  =>$data
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"获取失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 填写简历————展示接口
  /*
    $_POST["userId"]
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  查询简历出错
    返回参数 result=>3  创建简历失败
    返回参数 result=>4  统计简历数量失败
    返回参数 result=>5  查询用户失败
    返回参数 result=>6  没有该用户
  */
  public function edit_resume(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    // 获取用户信息
    $member = M("member")->where(array("id"=>$userid,"isdel"=>0,"status"=>0))->
              field("realname,country,card_id,specialty,qq_number,wx_number")->
              find();
    if($member===false){
      $result = array(
          "result"=>"5",
          "info"  =>"查询用户失败"
        );
      echo json_encode($result);exit;
    }elseif(!$member){
      $result = array(
          "result"=>"6",
          "info"  =>"没有该用户"
        );
      echo json_encode($result);exit;
    }
    // 是否有简历 - 有则读取，没有则创建
    $m = M("resume");
    $map["userid"] = $userid;
    $map["isdel"] = 0;
    $res = $m->where($map)->field("id,email,workLifeId")->find();
    if($res === false){
      // 查询出错
      $result = array(
          "result"=>"2",
          "info"  =>"查询简历出错"
        );
      echo json_encode($result);exit;
    }elseif($res){
      $data = $member;
      $data["resumeid"]      = $res["id"];
      $data["email"]         = $res["email"];
      $data["workLifeId"]    = $res["worklifeid"];
    }else{
      // 没有简历，创建简历
      $data = $member;
      $res2 = $m->add(array("userid"=>$userid));
      if($res2){
        // 创建成功
        $data["resumeid"]      = $res2;
        $data["email"]         = "";
        $data["workLifeId"]    = "";
      }else{
        $result = array(
            "result"=>"3",
            "info"  =>"创建简历失败"
          );
        echo json_encode($result);exit;

      }
    }
    // 获取技能证书的数量
    $res3 = M("credential")->where(array("memberid"=>$userid,"isdel"=>0))->count();
    if($res3===false){
        $result = array(
            "result"=>"4",
            "info"  =>"统计简历数量失败"
          );
        echo json_encode($result);exit;
    }else{
      $data["credential_num"] = $res3;
    }
    $data = $this->remove_null($data);
    $result = array(
        "result"  => 1,
        "info"    => $data
      );
    echo json_encode($result);exit;
  }


  // 填写简历————修改接口
  /*
    $_POST["userId"]        登录者的id
    $_POST["realname"]      真实姓名
    $_POST["email"]         邮箱
    $_POST["country"]       籍贯
    $_POST["card_id"]       身份证号
    以上必填
    $_POST["specialty"]     特长
    $_POST["qq_number"]     qq号        
    $_POST["wx_number"]     微信号
  */
  public function edit_my_resume(){
    // $_POST["userId"]   = 67;
    // $_POST["realname"] = "郑伊凡";
    // $_POST["email"]    = "519525@qq.com";
    // $_POST["wallet"]   = 1000000000;
    // $_POST["country"]  = "ruian";
    // $_POST["card_id"]  = "122333";
    // $_POST["specialty"]= "奥奥奥奥";
    // $_POST["qq_number"]= "333333";  
    // $_POST["wx_number"]= "wx2333";
    if(!isset($_POST["userId"]) || 
       !isset($_POST["realname"]) ||
       !isset($_POST["email"]) ||
       !isset($_POST["country"]) ||
       !isset($_POST["card_id"])
      ){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    if(!$_POST["userId"]||
       !$_POST["realname"]||
       !$_POST["email"]||
       !$_POST["country"]||
       !$_POST["card_id"]
    ){
      $result = array(
          "result"=>"2",
          "info"  =>"缺少必填参数"
        );
      echo json_encode($result);exit;
    }

    $userid = $_POST["id"] = $_POST["userId"];
    $m = M("Member");
    $data = array(
        "id"        => $userid,
        "realname"  => $_POST["realname"],
        "country"   => $_POST["country"],
        "realname"  => $_POST["realname"],
        "card_id"   => $_POST["card_id"],
        "specialty" => $_POST["specialty"],
        "qq_number" => $_POST["qq_number"],
        "wx_number" => $_POST["wx_number"]
      );
    $res = $m->create($data);
    if($res){
      // 修改邮箱
      $map["userid"] = $userid;
      $map["isdel"]  = 0;
      $res2 = M("resume")->where($map)->setField("email",$_POST["email"]);
      if($res2!==false){
        $m->save();
        $result = array(
            "result"=>"1",
            "info"  =>"修改成功"
          );
        echo json_encode($result);exit;
      }else{
        $result = array(
            "result"=>"3",
            "info"  =>"修改邮箱失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      // 无法修改
      $result = array(
          "result"=>"4",
          "info"  =>"修改失败"
        );
      echo json_encode($result);exit;
    }
  }

  
  // 评论

  // [任务模块]  


  // 发布的任务列表的接口  讨论后已完成 9-23 17:35
  /*
    0待接受 1 申请中 2 同意     3 就位（任务开始）  4 申请完成 

    5 确认完成（随时可以确认完成）  6 评论完成（订单结束） 

    7 发单人取消任务    8 接单人取消任务  

    9 取消成功（需要双方互评）  10接单人迟到，发单人取消任务（发单人可以评价）

    11 循环取消任务后（第三方介入）  12 发单人投诉  13 取消后完成评论互评（订单结束）
   *
   *  app参数： 1:待接受=>01; 2:待完成=>2345; 3:待评价=>5 9 10; 
                4:已完成=>6 13;  5:取消/退款=>78 11 12
   */

  public function tasks_list(){
    // 接收状态标识
    // $_POST['state'] = 1;
    // $_POST['userId'] = 67;
    $userid = $_POST['userId'];
    $state = $_POST['state'];
    if(!isset($_POST['state']) || !isset($_POST['userId'])){
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;

    }
    $where["userid"] = $userid;
    $where["isdel"] = 0;
    switch($state){
      case "1":
        $where["orderstate"] = array(array('egt',0),array('elt',1),'and');
        $where["status"] = array("neq","0");
        break;
      case "2":
        $where["orderstate"] = array(array('egt',2),array('lt',5),'and');
        break;
      case "3":
        $where["orderstate"] = array(array('eq',5),array('eq',10),'or');
        break;
      case "4":
        $where["orderstate"] = array('eq',6);
        break;
      case "5":
        $where["orderstate"] = array(array('eq',7),array('eq',8),array('eq',9),array('eq',11),array('eq',12),array('eq',13),'or');
        break;
      default:
        // 参数错误
        $result = array("result"=>"3");
        echo json_encode($result);
        exit;
    }
    // 返回参数：type，title，addtime,
    $m = D("orderlist");
    $r_o_m = D("receiveOrder");
    $res = $m->where($where)->field("id,type,title,addtime")->order("addtime desc")->select();
    if($res){
      $t_c_m = D("taskClass");
      foreach($res as $v){
        $taskparid = $t_c_m->where(array('id'=>$v['type']))->getField("parid");
        $taskimg = $t_c_m->where(array('id'=>$taskparid))->getField("pic");
        if($state==1){
          $map['orderid'] = $v['id'];
          $map['isdel'] = 0;
          $map['islooked'] = 0;
          $v["receive_num"] = $r_o_m->where($map)->count();// 未读
        }else{
          $v["receive_num"] = "0";
        }
        // taskimg默认图片
        $newimg=!empty($taskimg)?trim($taskimg,"."):'Public/Admin/Upload_pic/header.png';
        $data["data"][] = array(
              "taskid"     => $v['id'],
              "taskimg"     => IMG_URL.$newimg,
              "title"       => $v["title"],
              "addtime"     => $v["addtime"],
              "receive_num" => $v["receive_num"]
          );
      }
      $data["result"] = "1";
      $data = $this->remove_null($data);
      echo json_encode($data);
      exit;
    }else{
      // 没有数据，或操作失败
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }


  // 接取的订单的列表接口  讨论后已完成 9-23 17:40
  /*
    $_POST["userId"]   登录者的ID
    $_POST["state"]    请求的状态
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  数据库中没有数据
    返回参数 result=>3  参数错误

  
    0待接受 1 申请中 2 同意     3 就位（任务开始）  4 申请完成 

    5 确认完成（随时可以确认完成）  6 评论完成（订单结束） 

    7 发单人取消任务    8 接单人取消任务  

    9 取消成功（需要双方互评）  10接单人迟到，发单人取消任务（发单人可以评价）

    11 循环取消任务后（第三方介入）  12 发单人投诉  13 取消后完成评论互评（订单结束）
   
     app参数： 1:待接受=>01; 2:待完成=>2345; 3:待评价=>5 9 10; 
               4:已完成=>6 13;  5:取消/退款=>78 11 12

    state=1 => 待确认  ok
    state=2 => 待完成  ok
    state=3 => 待评价
    state=4 => 已完成
    state=5 => 取消/退款
  */
  public function my_apply_order_list(){
    // $_POST["userId"] = 56;
    // $_POST["state"] = 1;
    $userid = $_POST["userId"];
    $state  = $_POST["state"];
    if(!isset($_POST['userId']) || !isset($_POST['state'])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    $r_o_m = D("receiveOrder");
    // join来写
    // 获取表前缀
    $DB_PREFIX = C("DB_PREFIX");
    $join_str = "left join {$DB_PREFIX}orderlist as o on ro.orderid = o.id";
    $join_str2 = "left join {$DB_PREFIX}member as m on m.id = o.userid";
    $map = "ro.userid = $userid and o.userid != $userid";
    switch($state){
      case 1:
        $map.= " and ro.id != o.receive_order_id and ro.status=0 and o.orderstate<2";
        break;
      case 2:
        $map.= " and ro.id = o.receive_order_id";
        $map.= " and o.orderstate >= 2 and o.orderstate< 5";
        break;
      case 3:
        $map.= " and ro.id = o.receive_order_id";
        $map.= " and (o.orderstate = 5 or o.orderstate = 10 or o.orderstate = 13 or o.orderstate = 6) and ro.status=0";
        break;
      case 4:
        $map.= " and ro.id = o.receive_order_id ";
        $map.= " and (o.orderstate = 6  or o.orderstate = 5 ) and ro.status = 1";
        break;
      case 5:
        $map.= " and ro.id = o.receive_order_id and ( ro.status = 2 or o.orderstate = 13
or o.orderstate = 12 or o.orderstate = 9)";
        break;
      default:
        // 参数错误
        $result = array("result"=>"3");
        echo json_encode($result);
        exit;
        break;
    }
    $map.=" and o.isdel=0 and ro.isdel=0 and  m.isdel=0 and m.status=0 ";
    $res = $r_o_m->alias("ro")->where($map)
                 ->join($join_str)->join($join_str2)
                 ->field("o.orderstate,o.addtime,o.place,ro.charge,
                      ro.id as receiveid,
                      o.userid,o.title,m.person_img,m.person_name,
                      o.receive_order_id,o.id as taskid
                  ")
                 ->order("ro.addtime desc")->select();
    if($res){
      $data["result"] = "1";
      $data["info"] = array();
      foreach($res as $k=>$v){
        $personimg=!empty($v['person_img'])?trim($v['person_img'],"."):'Public/Admin/Upload_pic/header.png';
        $data["info"][] = array(
              "receiveid"  => $v["receiveid"],
              "taskid"     => $v["taskid"],
              "person_img" => IMG_URL.$personimg,
              "person_name"=> $v["person_name"],
              "addtime"    => $v["addtime"],  // 发单人创建任务的时间
              "place"      => $v["place"],
              "charge"     => $v["charge"],
              "userid"     => $v["userid"],  // 发单人的id
              "title"      => $v["title"]
            );
      }
      $data = $this->remove_null($data);
      echo json_encode($data);
      exit;
    }else{
      // 缺少参数
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }


  // 待接受点击查看申请的receive_order:任务信息接口  讨论后已完成 添加查看消息 9-23 17:45
  /*
    $_POST['orderId']   orderlist的id：订单id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  请求成功
    返回参数 result=>2  没有数据
  */
  public function receive_order_list(){
    // $_POST['orderId'] = 37;
    $orderid = $_POST['orderId'];
    if(!isset($_POST['orderId'])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    $where['orderid'] = $orderid;
    $where['status']  = 0;
    $where['isdel']   = 0;
    $m = D("receiveOrder");
    $res = $m->where($where)->field("id,charge,userid,addtime")->order("addtime desc")->select();
    if($res){
      // 查看了之后把未查看都变成已查看
      $res1 = $m->where($where)->setField(array("islooked"=>1));
      if($res1===false){
        // 设置成已查看失败
        $result = array(
            "result" => "0",
            "info"   => "设置成已查看失败"
          );
        echo json_encode($result);exit;
      }
      $user_m = D("member");
      $data["data"] = array();
      foreach($res as $v){
        $userinfo = $user_m -> field("person_name,person_img")-> where(array("id"=>$v['userid'],"isdel"=>0,"status"=>0)) -> find();

        $personimg=!empty($userinfo['person_img'])?trim($userinfo['person_img'],"."):'Public/Admin/Upload_pic/header.png';
        $data["data"][] = array(
            "receiveid" => $v['id'],
            "userid" => $v['userid'],
            "charge" => $v['charge']?$v['charge']:"0.00",
            "nickname" => $userinfo["person_name"], // 昵称
            "headimg" => IMG_URL.$personimg, // 头像
            // "orderid" => $v["orderid"],
            "addtime" => $v["addtime"]
          );
      }
      $data["result"] = "1";
      $data = $this->remove_null($data);
      echo json_encode($data);
      exit;
    }else{
      // 没有数据
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }

  // 任务状态：  讨论后已修改  待测试  9-23 22:05
  /*
    $_POST["taskId"]  传来要查看的订单id
    $_POST["userId"]  传来登录用户id用于验证
    $_POST["state"]   1:来自发布的任务  2:来自接取的订单
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  数据库中没有数据
    返回参数 result=>3  接单人不存在
    返回参数 result=>4  没有接单用户数据
    返回参数 result=>5  接单的人不是登陆者
    0待接受 1 申请中 2 任务开始 3 任务完成  4 确认任务完成 5 取消任务 6 退款  7 任务结束 
  */
  public function task_status(){
    // $_POST["taskId"] = 36;
    // $_POST["userId"] = 85;
    // $_POST["state"] = 2;
    $state  = $_POST["state"];
    $taskid = $_POST["taskId"];
    $userid = $_POST["userId"];
    if(!isset($_POST['taskId'])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);exit;
    }
    $o_m = D("orderlist");
    $map["id"] = $taskid;
    if($state == 1){
      // 走发布的任务  那么发布任务的人就是登陆者
      $map['userid'] = $userid;
    }
    $map['isdel'] = 0;
    // 任务数据
    $res = $o_m->where($map)->find();
    if($res){
      // 有数据，从receive_order表中读取数据
      $r_o_m = D("receiveOrder");
      $map2['id'] = $res["receive_order_id"];
      $map2['isdel'] = 0;
      // 接单表数据
      $res2 = $r_o_m -> where($map2) ->field("userid,charge,status,comment,assesstime") ->find();
        if($state == 2 && $res2["userid"]!=$userid){
          // 走接取的订单  那么接单的人就是登陆者
          $result = array(
              "result" => "5",
              "info"   => "接单的人不是登陆者"
            );
          echo json_encode($result);exit;
        }
      if($res2){
        // 有正确的接单人
        if($state == 1){
          // 走发布的任务  那么发布任务的人就是登陆者
          $map3["id"] = $res2["userid"];
        }elseif($state == 2){
          // 走接取的订单  那么接单的人就是登陆者
          $map3["id"] = M("orderlist")->where(array("id"=>$taskid,"isdel"=>0))->getField("userid");
        }else{
          $result = array(
              "result" => "6",
              "info"   => "state状态错误"
            );
          echo json_encode($result);exit;
        }
        $map3["isdel"] = 0;
        $map3["status"] = 0;
        // dump($map3);
        // 接单人数据
        $res3 = M("member") -> where($map3) ->field("id,person_name,person_img") -> find();
        if($res3){
          // 有用户数据
          $data["result"] = "1";
          // 接单人数据

          $personimg=!empty($res3['person_img'])?trim($res3['person_img'],"."):'Public/Admin/Upload_pic/header.png';
          $data["userinfo"] = array(
                "person_name" => $res3["person_name"],
                "person_img"  => IMG_URL.$res3["person_img"],
                "charge"      => $res2["charge"],
                "userid"      => $res3["id"]
            );


          $data["orderinfo"] = array(
              "orderid"        => $res["id"],
              "receiveOrderId" => $res["receive_order_id"],
              "orderstate"     => $res["orderstate"]
            );

          // 简历任务日志 order_log
          $log_map["orderid"] = $taskid;
          $log_map["orderstate"] = array("gt",1);
          $log_map["isdel"] = 0;
          $logs = M("orderLog")->where($log_map)->order("addtime")->select();
          if($logs===false){
            $result = array(
                "result" => "7",
                "info"   => "读取订单日志失败"
              );
            echo json_encode($result);exit;
          }
          foreach($logs as $k=>$v){
              $arr = array(
                "title" => $v["title"],
                "time"  => date("m-d H:i",strtotime($v["addtime"]))
              );
              // 如果是发单者
              if($state==1){
                // 登录者就是发单者  就是雇主
                  switch($v["orderstate"]){
                    case 2:
                      $arr["msg"] = "您正在等待{$res3['person_name']}就位";
                      break;
                    case 3:
                      $arr["msg"] = "{$res3['person_name']}已就位，任务开始";
                      break;
                    case 4:
                      $arr["msg"] = "{$res3['person_name']}向您申请完成任务";
                      break;
                    case 5:
                      $arr["msg"] = "您确认已{$res3['person_name']}完成任务";
                      break;
                    case 6:
                      $arr["msg"] = "您完成评论，订单已完成";
                      break;
                    case 7:
                      $arr["msg"] = "您申请取消任务";
                      break;
                    case 8:
                      $arr["msg"] = "{$res3['person_name']}向您申请取消任务";
                      break;
                    case 9:
                      $arr["msg"] = "任务已取消";
                      break;
                    case 10:
                      $arr["msg"] = "因为{$res3['person_name']}迟到，您已取消任务";
                      break;
                    case 11:
                      $arr["msg"] = "由于取消任务超过上限，第三方以介入您的任务";
                      break;
                    case 12:
                      $arr["msg"] = "您已对{$res3['person_name']}发起投诉";
                      break;
                    case 13:
                      if($v["is_disanfang"]){
                        // 第三方介入
                        $arr["msg"] = $v["msg"];
                      }else{
                        $arr["msg"] = "取消订单后，您已完成评论";
                      }
                      break;
                    case 14:
                      $arr["msg"] = "{$res3['person_name']}已完成评价";
                      break;
                  }
              $data["taskinfo"][] = $arr;
              }else{
                // 登录者接单者
                  switch($v["orderstate"]){
                    case 2:
                      $arr["msg"] = "雇主正在等待您就位";
                      break;
                    case 3:
                      $arr["msg"] = "您已就位，任务开始";
                      break;
                    case 4:
                      $arr["msg"] = "您正在申请完成任务";
                      break;
                    case 5:
                      $arr["msg"] = "雇主确认已完成任务，快去评价吧";
                      break;
                    case 6:
                      $arr["msg"] = "雇主已完成评论";
                      break;
                    case 7:
                      // $arr["msg"] = "雇主申请取消任务";
                      $arr["msg"] = "雇主取消任务";
                      break;
                    case 8:
                      $arr["msg"] = "您向雇主申请取消任务";
                      break;
                    case 9:
                      $arr["msg"] = "任务已取消";
                      break;
                    case 10:
                      $arr["msg"] = "由于您迟到，此任务已被雇主取消";
                      break;
                    case 11:
                      $arr["msg"] = "取消任务超过上限，第三方以介入您的任务";
                      break;
                    case 12:
                      $arr["msg"] = "雇主已对您发起投诉";
                      break;
                    case 13:
                      if($v["is_disanfang"]){
                        // 第三方介入
                        $arr["msg"] = $v["msg"];
                      }else{
                        $arr["msg"] = "取消订单后，雇主已完成评论";
                      }
                      break;
                    case 14:
                      $arr["msg"] = "您已完成评论";
                      break;
                  }
                  if($v["orderstate"]!=6 && $v["orderstate"]!=13){
                    $data["taskinfo"][] = $arr;
                  }
              }
          }
          if($state!=1){
            if($res2["status"]==0 && $res["orderstate"]==6){
              $data["orderinfo"]["orderstate"] = "5";
            }elseif($res2["status"]==0 && $res["orderstate"]==13){
              $data["orderinfo"]["orderstate"] = "9";
            }
          }
          $data = $this->remove_null($data);
          echo json_encode($data);exit;
        }else{
          // 没有用户数据
          $result = array(
              "result"=> "4",
              "info"  => "没有用户数据"
            );
          echo json_encode($result);
          exit;
        }
      }else{
        // 接单数据不存在
        $result = array(
              "result"=>"3",
              "info"  => "接单数据不存在"
            );
        echo json_encode($result);
        exit;
      }
    }else{
      // 没有数据
      $result = array(
          "result"=>"2",
          "info"  => "没有数据"
        );
      echo json_encode($result);
      exit;
    }
  }

  // 申请取消任务的接口
  /*
    业务逻辑：
        前提：在没有同意别人接单前。   orderstate=0|1
        操作：订单取消，退还余额
    $_POST["orderId"]       任务id
    $_POST["userId"]        登陆者的id（发单者）
    $_POST["cancel_msg"]    撤销原因
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  操作失败
  */
  public function cancel_order_before_agree(){
    // $_POST["orderId"] = 37;
    // $_POST["userId"]  = 67;
    // $_POST["cancel_msg"]  = "老子要撤销";
    if(!isset($_POST['userId']) || !isset($_POST['orderId']) || !isset($_POST['cancel_msg'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $cancel_msg = $_POST["cancel_msg"];
    if(!$cancel_msg){
      $result = array(
          "result" => "3",
          "info"   => "请填写撤销原因"
        );
      echo json_encode($result);exit;
    }
    $orderid    = $_POST["orderId"];
    $userid     = $_POST["userId"];
    $o_map = array(
        "id"         => $orderid,
        "userid"     => $userid,
        "orderstate" => array(array("egt",0),array("elt",1),"and"),
        "isdel"      => 0
      );
    // 退款 ， refund_state => 1, 
    $data = array(
        "orderstate"  => 13,
        "cancel_msg"  => $cancel_msg,
        "refund_state"=> 1
      );
    $this->refund($o_map,$data,$userid);
  }


  
  // 任务信息中，同意某个接单请求的接口   讨论后已更新 9-23 19:16
  /*
    jpush=>3
    $_POST['receiveOrderId']  传来要同意的接单请求id
    $_POST["userId"]          传来登陆者的id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  数据库没有找到
    返回参数 result=>3  操作失败
    返回参数 result=>4  查无订单
    返回参数 result=>5  订单的酬金不足，需要用户继续支付差价
    返回参数 result=>6  增加用户余额失败
    返回参数 result=>7  添加日志失败
  */
  public function agree_receive_order(){
    // $_POST['userId'] = 67;
    // $_POST['receiveOrderId'] = 2;
    $userid =  $_POST['userId'];
    $receive_oid = $_POST['receiveOrderId'];
    if(!isset($_POST['receiveOrderId'])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);
      exit;
    }
    $r_o_m = D("receiveOrder");
    $map['id'] = $receive_oid;
    $map['isdel'] = 0;
    $res = $r_o_m->where($map)->field("orderid,charge,userid")->find();
    if($res){
      $map2["id"] = $orderid = $res['orderid'];
      $map2["userid"] = $userid;     // 验证用户与订单是否对应
      $map2["receive_order_id"] = 0; // 用于防止用户多次同意接单者
      $map2["isdel"] = 0; 
      // 判断用户的订单是否在可接受用户申请的范围内
      $map2["orderstate"] = array(array('egt',0),array('elt',1),'and');
      $o_m = D("orderlist");
      $res3 = $o_m -> where($map2) ->field("remuneration,prepay,diff_money,real_pay") ->find();
      if(!$res3){
        // 缺少参数
        $result = array(
            "result" => "4",
            "info"   => "查无订单"
          );
        echo json_encode($result);
        exit;
      }
      $charge = $res["charge"];
      $remuneration = $res3["remuneration"];
      // 判断接单者的报价和发单者的酬金
      if($charge > $remuneration){
        // 1.接单者的报价>发单者的酬金  重新支付
        $result = array(
            "result" => "5",
            "info"   => "订单的酬金不足，需要用户继续支付差价"
          );
        echo json_encode($result);exit;
      }elseif($charge < $remuneration){
        // 2.接单者的报价<发单者的酬金  退还部分款
        $data2["diff_money"]   = floor(($remuneration - $charge)*100)/100;//差价
        $data2["realpay"]      = $res3["prepay"] - $diff_money;// 真实支付时间
        $data2["remuneration"] = $charge;
        $data2["pay_msg"]      = "退还差价成功";
        $o_m->startTrans();
        $res4 = $o_m->where($map2)->save($data2);
        if($res4){
          // 增加用户余额
          $res5 = M("member")->where(array("id"=>$userid,"isdel"=>0,"status"=>0))->setInc("wallet",$data2["diff_money"]);
          if($res5){
            $o_m->commit();
          }else{
            $o_m->rollback();
            $result = array(
                "result" => "6",
                "info"   => "增加用户余额失败"
              );
            echo json_encode($result);exit;
          }
        }
      }
      // 3.相等，直接继续走
      $data = array(
          "orderstate" => "2",  // 2 任务开始
          "receive_order_id" => $receive_oid, // 接单对应的id
          "agreetime" => date("Y-m-d H:i:s",time())//任务开始的时间
        );
      $o_m->startTrans();
      $res2 = $o_m -> where($map2) -> setField($data);
      if($res2 && $res2 !== false){
        // 写入日志
        $log_date = array(
            "title" => "等待就位",
            "msg"   => "同意了接单id为{$receive_oid}的人",
            "userid"=> $userid,
            "orderid"=> $orderid,
            "orderstate"=>2,
            "pay_status"=>1,
            "addtime"=>date("Y-m-d H:i:s",time())
          );
        $log_res = M("orderLog")->add($log_date);
        if($log_res===false){
          $o_m->rollback();
          $result = array(
              "result" => "7",
              "info"   => "添加日志失败"
            );
          echo json_encode($result);exit;
        }
        $o_m->commit();
        // jpush同意接单人
        $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
        // $jres = $this->jpush_msg($res["userid"],"{$jname}同意的您的接单申请","2");
        $jres = $this->jpush_msg($res["userid"],"{$jname}同意的您的接单申请","3");
        $result = array(
            "result"  =>"1",
            "info"    =>"操作成功",
            "jpushinfo" => $jres
          );
      }else{
        $result = array("result"=>"3");
      }
      echo json_encode($result);
      exit;
    }else{
      // 数据库没有找到这个参数
      $result = array("result"=>"2");
      echo json_encode($result);
      exit;
    }
  }

  // 接单者申请就位
  /*
    jpush=>4
    orderstate：2->3
    就位（任务开始）
    title=>确认就位
    $_POST["userId"]   => 登陆者id,也就是接单者id
    $_POST["orderId"]  => 任务id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  没有接单数据
    返回参数 result=>3  登陆者不为接单者
    返回参数 result=>4  改变订单状态失败
    返回参数 result=>5  保存订单日志失败    
  */
  public function arrive(){
    // $_POST["userId"]  = 56;
    // $_POST["orderId"] = 37;
    if(!isset($_POST['userId']) || !isset($_POST['orderId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $orderid = $_POST["orderId"];
    $o_map = array(
        "id"         => $orderid,
        "orderstate" => 2,
        "isdel"      => 0
      );
    $o_m = M("orderlist");
    $o_r = $o_m->where($o_map)->field("receive_order_id,userid")->find();
    $receiveid = $o_r["receive_order_id"];
    if($receiveid){
      $r_o_m = M("receiveOrder");
      $r_o_map = array(
          "id"      => $receiveid,
          "orderid" => $orderid,
          "isdel"   => 0,
        );
      $r_userid = $r_o_m->where($r_o_map)->getField("userid");
      if($r_userid == $userid){
        // 信息确认无误
        $data = array(
            "id"         => $orderid,
            "orderstate" => 3
          );
        $o_m->startTrans();
        $o_res = $o_m->save($data);
        if($o_res){
          $log = array(
              "title" => "确认就位",
              "orderid" => $orderid,
              "userid" => $userid,
              "orderstate" => 3,
              "msg" => "用户id为{$userid}的用户确认就位，订单id为{$orderid}的任务开始",
              "pay_status" => 1,
              "addtime" => date("Y-m-d H:i:s",time())
            );
          $log_res = M("order_log")->add($log);
          if($log_res){
            $o_m->commit();
            // jpush接单人就位
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            $jres = $this->jpush_msg($o_r["userid"],"{$jname}已经就位，您的任务开始","4");
            $result = array(
                "result"  =>"1",
                "info"    =>"操作成功",
                "jpushinfo" => $jres
              );
            echo json_encode($result);exit;
          }else{
            $o_m->rollback();
            $result = array(
                "result" => "5",
                "info"   => "保存订单日志失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $o_m->rollback();
          $result = array(
              "result" => "4",
              "info"   => "改变订单状态失败"
            );
          echo json_encode($result);exit;
        }
      }else{
        $result = array(
            "result" => "3",
            "info"   => "登陆者不为接单者"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "没有接单数据"
        );
      echo json_encode($result);exit;
    }
  }

  // 接单者就位后
  // 申请任务完成的接口  讨论后已更新 9-23 18:07
  /*
    jpush=>5
    业务逻辑：
        前提：任务开始 orderstate=3时后才能申请完成 orderstate=>4
      
    0待接受 1 申请中 2 同意     3 就位（任务开始）  4 申请完成 

    5 确认完成（随时可以确认完成）  6 评论完成（订单结束） 

    7 发单人取消任务    8 接单人取消任务  

    9 取消成功（需要双方互评）  10接单人迟到，发单人取消任务（发单人可以评价）

    11 循环取消任务后（第三方介入）  12 发单人投诉  13 取消后完成评论互评（订单结束）
    
    $_POST["userId"]          登陆者的id  用于验证 接单人的id
    $_POST["receiveId"]       接单id      用于验证
    $_POST["taskId"]          任务id      用于验证
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  查询订单出错
    返回参数 result=>3  申请完成任务失败，用户可能已经申请过
    返回参数 result=>4  登录用户不为接单用户
    返回参数 result=>5  申请完成任务失败
  */
  public function apply_complate_task(){
    // $_POST['userId'] = 56;
    // $_POST['receiveId'] = 4;
    // $_POST['taskId'] = 40;
    if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid    = $_POST['userId'];
    $receiveid = $_POST['receiveId'];
    $taskid    = $_POST['taskId'];
    $map["id"]         = $taskid;
    $map["status"]     = 1;  // 已支付
    $map["orderstate"] = 3;  // 在有人申请的状态
    $map["isdel"]      = 0;  // 未被删除
    $map2["userid"]    = $userid;
    $map2["id"]        = $receiveid;
    $map2["status"]    = 0; 
    $map2["isdel"]     = 0;
    $o_m   = M("orderlist");
    // 得到接单者的id用于验证
    $o_r = $o_m->where($map)->field("receive_order_id,userid")->find();
    $order_r_id = $o_r["receive_order_id"];
    if($order_r_id===false){
      $result = array(
          "result" => "2",
          "info"   => "查询订单出错"
        );
      echo json_encode($result);exit;
    }elseif($order_r_id && $order_r_id==$receiveid){
      // 为相关联的订单
      // 验证是否为同一个用户
      $res = M("receiveOrder")->where($map2)->getField("id");
      if($res){
        // 可以改变状态
        $data["orderstate"] = 4;
        $data["applytime"]  = date("Y-m-d H:i:s",time());
        $res2 = $o_m->where($map)->setField($data);
        if($res2){
          // jpush申请任务完成
          $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
          $log = array(
              "title" => "申请完成任务",
              "orderid" => $taskid,
              "userid" => $userid,
              "orderstate" => 3,
              "msg" => "用户id为{$userid}的用户{$jname}申请完成任务",
              "pay_status" => 1,
              "addtime" => date("Y-m-d H:i:s",time())
            );
          M("order_log")->add($log);
          $jres = $this->jpush_msg($o_r["userid"],"{$jname}申请完成任务","5");
          $result = array(
              "result" => "1",
              "info"   => "申请完成任务成功",
              "jpushinfo" => $jres
            );
          echo json_encode($result);exit;
        }else{
          $result = array(
              "result" => "5",
              "info"   => "申请完成任务失败"
            );
          echo json_encode($result);exit;
        }
      }else{
        $result = array(
            "result" => "4",
            "info"   => "登录用户不为接单用户"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "3",
          "info"   => "申请完成任务失败，用户可能已经申请过"
        );
      echo json_encode($result);exit;
    }
  }


  // 确认任务完成的接口,任何情况下都能确认完成
  /*
    jpush=>6
    业务逻辑：
        前提：有任务完成申请 orderstate=3 的时候才能确认完成 orderstate=>4
        确认完成后，钱将以余额的方式打到接单者的账号上
    $_POST["userId"]          登陆者id  发单者的id
    $_POST["receiveId"]       接单id      用于验证
    $_POST["taskId"]          任务id      用于验证
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  操作失败
    返回参数 result=>3  获取接单人数据失败
    返回参数 result=>4  增加接单人余额失败
    返回参数 result=>5  申请完成任务失败
  */
  public function aggree_complate_task(){
    // $_POST["userId"]    = 67;
    // $_POST["receiveId"] = 2;
    // $_POST["taskId"]    = 37;
    if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid    = $_POST['userId'];
    $receiveid = $_POST['receiveId'];
    $orderid   = $_POST['taskId'];
    // 验证order
    $o_map = array(
        "id"               => $orderid,
        "receive_order_id" => $receiveid,
        "userid"           => $userid,
        "isdel"            => 0
      );
    $o_m = M("orderlist");
    $order = $o_m->where($o_map)->field("orderstate,remuneration")->find();
    if($order['orderstate']>=2 && $order['orderstate']<=4){
      // 在允许确认完成的范围内
      $o_m->startTrans();
      $res = $o_m->where($o_map)->setField(array("orderstate"=>5));
      if($res){
        // 给用户打钱
        // 获取接单者id
        $r_userid = M("receiveOrder")->where(array("id"=>$receiveid,"orderid"=>$orderid,"isdel"=>0))->getField("userid");
        if($r_userid){
          $mem_res = M("member")->where(array("id"=>$r_userid,"isdel"=>0,"status"=>0))->setInc("wallet",$order["remuneration"]);
          if($mem_res){
            $o_m->commit();
            // 记入日志
            $log_data = array(
                "title"      => "确认完成",
                "orderid"    => $orderid,
                "userid"     => $userid,
                "orderstate" => 5,
                "msg"        => "已将酬金{$order["remuneration"]}打给id为{$r_userid}的用户，双方未评价",
                "addtime"    => date("Y-m-d H:i:s",time())
              );
            $log_res = M("orderLog")->add($log_data);
            // jpush确认任务完成
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            $jres = $this->jpush_msg($r_userid,"{$jname}已经确认任务完成","6");
            if($log_res){
              $result = array(
                  "result" => "1",
                  "info"   => "任务完成",
                  "jpushinfo" => $jres
                );
              echo json_encode($result);exit;
            }else{
              $result = array(
                  "result" => "1",
                  "info"   => "任务完成，记录日志失败",
                  "jpushinfo" => $jres
                );
              echo json_encode($result);exit;
            }
          }else{
            $o_m->rollback();
            $result = array(
                "result" => "4",
                "info"   => "增加接单人余额失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result" => "3",
              "info"   => "获取接单人数据失败"
            );
          echo json_encode($result);exit;
        }
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "操作失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 接单人申请完成任务，发单人选择投诉的接口
  // 逻辑：orderstate=>4   投诉后   orderstate=>12
  /*
    jpush=>7
    $_POST["userId"]          登陆者id  发单者的id
    $_POST["receiveId"]       接单id      用于验证
    $_POST["taskId"]          任务id      用于验证
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  申请投诉失败
    返回参数 result=>3  申请投诉失败,查询接单人失败
    返回参数 result=>4  保存日志失败
    返回参数 result=>5  申请完成任务失败
  */
  public function complaint(){
    // $_POST["userId"]    = 67;
    // $_POST["receiveId"] = 2;
    // $_POST["taskId"]    = 37;
    if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid    = $_POST['userId'];
    $receiveid = $_POST['receiveId'];
    $orderid   = $_POST['taskId'];
    // 验证order
    $o_map = array(
        "id"               => $orderid,
        "receive_order_id" => $receiveid,
        "userid"           => $userid,
        "orderstate"       => 4,
        "isdel"            => 0
      );
    $o_m = M("orderlist");
    $o_m->startTrans();
    $o_res = $o_m->where($o_map)->setField(array("orderstate"=>12));
    if($o_res){
      $r_userid = M("receiveOrder")->where(array("id"=>$receiveid,"isdel"=>0,"orderid"=>$orderid))->getField("userid");
      if($r_userid){
        $log_data = array(
            "title"      => "申请投诉",
            "orderid"    => $orderid,
            "userid"     => $userid,
            "orderstate" => 12,
            "msg"        => "用户申请投诉用户id为{$r_userid}的接单人",
            "addtime"    => date("Y-m-d H:i:s",time())
          );
        $tousu_data = array(
            "orderid"      => $orderid,
            "receiveid"    => $receiveid,
            "from_userid"  => $userid,
            "to_userid"    => $r_userid,
            "title"        => "发单者发起投诉",
            "msg"          => "发单者发起投诉",
            "pic1"         => "",
            "pic2"         => "",
            "pic3"         => "",
            "addtime"      => time(),
          );
        $tousu_res = M("complaint")->add($tousu_data);
        $log_res = M("orderLog")->add($log_data);
        if($log_res && $tousu_res){
          $o_m->commit();
          // jpush发单者投诉
          $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
          $jres = $this->jpush_msg($r_userid,"{$jname}已对本次任务发起了投诉","7");
          $result = array(
              "result" => "1",
              "info"   => "操作成功",
              "jpushinfo" => $jres
            );
          echo json_encode($result);exit;
        }else{
          $o_m->rollback();
          $result = array(
              "result" => "4",
              "info"   => "保存日志失败"
            );
          echo json_encode($result);exit;
        }
      }else{
        $o_m->rollback();
        $result = array(
            "result" => "3",
            "info"   => "申请投诉失败,查询接单人失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      $o_m->rollback();
      $result = array(
          "result" => "2",
          "info"   => "申请投诉失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 接单人被发单人同意了之后  发单人|接单人 选择取消任务
  // 业务逻辑：发单人取消任务/接单人取消任务 -> 同意后，将酬金退给发单人，不同意3次，变成第三方介入
  // orderstate 2=>发单人取消:7|接单人取消:8 cancal_num ++ ;
  /*
    jpush=>8          发单人申请取消任务
    jpush=>9          接单人申请取消任务
    $_POST["userId"]          登陆者id
    $_POST["taskId"]          任务id
    $_POST["receiveId"]       接单id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  没有这个订单
    返回参数 result=>3  没有对应的接单信息
    返回参数 result=>4  用户错误
    返回参数 result=>5  申请次数已满三次
    返回参数 result=>6  申请失败
    返回参数 result=>7  申请失败
  */
  public function cancel_order_after_agree(){
    // $_POST["userId"]    = 67;
    // $_POST["taskId"]    = 37;
    // $_POST["receiveId"] = 1;
    $max_cancel_num = 3;  //最大取消次数
    if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid    = $_POST['userId'];
    $receiveid = $_POST['receiveId'];
    $orderid   = $_POST['taskId'];
    // 验证order
    $o_m = M("orderlist");
    $order = $o_m->where(array("id"=>$orderid,"isdel"=>0,"orderstate"=>2,"receive_order_id"=>$receiveid))->field("userid,orderstate,cancel_num")->find();
    if($order){
      // 获取接单信息
      $r_o_m = M("receiveOrder");
      $receive = $r_o_m->where(array("id"=>$receiveid,"orderid"=>$orderid,"isdel"=>0))->field("userid,cancel_num")->find();
      if($receive){
      // 判断来着是发单人还是接单人
        if($order["userid"]==$userid){
          // 是发单人
          // 判断是否申请满三次
          if($order["cancel_num"]>=$max_cancel_num){
            $result = array(
                "result" => "5",
                "info"   => "申请次数已满三次"
              );
            echo json_encode($result);exit;
          }
          $order["cancel_num"]++;
          $o_data = array(
              "id"         =>$orderid,
              "orderstate" =>7,
              "cancel_num" =>$order["cancel_num"]
            );
          $o_m->startTrans();
          $o_res = $o_m->save($o_data);
          if($o_res){
            // 保存日志
            $log_data = array(
                "title"      => "申请取消",
                "orderid"    => $orderid,
                "userid"     => $userid,
                "orderstate" => 7,
                "msg"        => "用户申请取消用户id为{$receive['userid']}的接单人的任务订单,第{$order["cancel_num"]}次",
                "addtime"    => date("Y-m-d H:i:s",time())
              );
            $log_res = M("orderLog")->add($log_data);
            if($log_res){
              $o_m->commit();
              // jpush申请取消任务
              $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
              $jres = $this->jpush_msg($receive["userid"],"{$jname}申请取消本次任务","8");
              $result = array(
                  "result" => "1",
                  "info"   => "操作成功",
                  "jpushinfo" => $jres
                );
              // 这里直接调用同意接口
              $this->agree_cancel_order($receive["userid"],$receiveid,$orderid,1);
              echo json_encode($result);exit;
            }else{
              $o_m->rollback();
              $result = array(
                  "result" => "7",
                  "info"   => "申请失败"
                );
              echo json_encode($result);exit;
            }
          }else{
            $result = array(
                "result" => "6",
                "info"   => "申请失败"
              );
            echo json_encode($result);exit;
          }
        }elseif($receive["userid"]==$userid){
          // 是接单人
          // 判断是否申请满三次
          if($receive["cancel_num"]>=$max_cancel_num){
            $result = array(
                "result" => "5",
                "info"   => "申请次数已满三次"
              );
            echo json_encode($result);exit;
          }
          $receive["cancel_num"]++;
          $o_data = array(
              "id"         =>$orderid,
              "orderstate" =>8
            );
          $o_m->startTrans();
          $o_res = $o_m->save($o_data);
          if($o_res){
            // 保存接单人的申请次数
            $r_res = $r_o_m->where(array("id"=>$receiveid))->setField("cancel_num",$receive["cancel_num"]);
            if(!$r_res){
              $o_m->rollback();
              $result = array(
                  "result" => "7",
                  "info"   => "申请失败"
                );
              echo json_encode($result);exit;
            }
            $o_m->commit();
            // jpush申请取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            $jres = $this->jpush_msg($order["userid"],"{$jname}申请取消本次任务","9");
            // 保存日志
            $log_data = array(
                "title"      => "申请取消",
                "orderid"    => $orderid,
                "userid"     => $userid,
                "orderstate" => 8,
                "msg"        => "用户申请取消用户id为{$order['userid']}的发单人的任务订单,第{$receive["cancel_num"]}次",
                "addtime"    => date("Y-m-d H:i:s",time())
              );
            $log_res = M("orderLog")->add($log_data);
            if($log_res){
              $result = array(
                  "result" => "1",
                  "info"   => "操作成功",
                  "jpushinfo" => $jres
                );
              $this->agree_cancel_order($order["userid"],$receiveid,$orderid,1);
              echo json_encode($result);exit;
            }else{
              $result = array(
                  "result" => "1",
                  "info"   => "申请成功，记录日志失败",
                  "jpushinfo" => $jres
                );
              echo json_encode($result);exit;
            }
          }else{
            $result = array(
                "result" => "6",
                "info"   => "申请失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result" => "4",
              "info"   => "用户错误"
            );
          echo json_encode($result);exit;
        }
      }else{
        $result = array(
            "result" => "3",
            "info"   => "没有对应的接单信息"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "没有这个订单"
        );
      echo json_encode($result);exit;
    }
  }

  // 用户申请取消后选择同意  同意取消订单
  // 业务逻辑：用户选择同意取消后，orderstate7|8=> 9 取消成功，将酬金退还给接单人，需要双方互评
  /*
    jpush=>10           发单人同意取消任务
    jpush=>11           接单人同意取消任务
    $_POST["userId"]          登陆者id
    $_POST["taskId"]          任务id
    $_POST["receiveId"]       接单id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  没有这个订单|退还酬金失败
    返回参数 result=>3  没有对应的接单信息
    返回参数 result=>4  用户错误
    返回参数 result=>5  自己没有权利同意自己的取消订单
  */
  public function agree_cancel_order($userid = "",$receiveid="",$orderid="",$type="0"){
    // $_POST["userId"]    = 67;
    // $_POST["taskId"]    = 37;
    // $_POST["receiveId"] = 1;   
    if(!$type){
      if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
        // 缺少参数
        $result = array(
            "result" => "0",
            "info"   => "缺少参数"
          );
        echo json_encode($result);exit;
      }
      $userid    = $_POST['userId'];
      $receiveid = $_POST['receiveId'];
      $orderid   = $_POST['taskId'];
    }
    // 验证order
    $o_m = M("orderlist");
    $order = $o_m->where(array("id"=>$orderid,"isdel"=>0,"receive_order_id"=>$receiveid))->field("userid,orderstate")->find();
    if($order["orderstate"]<7 || $order["orderstate"]>8){
      $result = array(
          "result" => "5",
          "info"   => "此订单不在取消的范围内"
        );
      echo json_encode($result);exit;
    }
    if($order){
      // 获取接单信息
      $r_o_m = M("receiveOrder");
      $receive = $r_o_m->where(array("id"=>$receiveid,"orderid"=>$orderid,"isdel"=>0))->field("userid")->find();
      if($receive){
      // 判断来着是发单人还是接单人
        if($order["userid"]==$userid){
          // 是发单者  对应状态8的时候才能同意，都是退款
          if($order["orderstate"]==8){
            $map = array(
                "id" => $orderid
              );
            $data = array(
                "orderstate"   => 9,
                "refund_state" => 1
              );
            // jpush同意取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($receive["userid"],"{$jname}同意取消本次任务","10");
            $this->refund($map,$data,$userid);
          }else{
            $result = array(
                "result" => "5",
                "info"   => "用户为发单者没有权利同意自己的取消订单"
              );
            echo json_encode($result);exit;
          }
        }elseif($receive["userid"]==$userid){
          // 是接单者  对应状态7的时候才能同意，都是退款
         if($order["orderstate"]==7){
            $map = array(
                "id" => $orderid
              );
            $data = array(
                "orderstate" => 9
              );
            // jpush同意取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($order["userid"],"{$jname}同意取消本次任务","11");
            $this->refund($map,$data,$userid);
          }else{
            $result = array(
                "result" => "5",
                "info"   => "用户为接单者没有权利同意自己的取消订单"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result" => "4",
              "info"   => "用户错误"
            );
          echo json_encode($result);exit;
        }
      }else{
        $result = array(
            "result" => "3",
            "info"   => "没有对应的接单信息"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "没有这个订单"
        );
      echo json_encode($result);exit;
    }
  }
  // 用户申请取消后选择不同意  拒绝取消订单
  // 业务逻辑：用户选择不同意取消后，orderstate7|8=> 2 cancel_num ++ 
  // 如果申请第三次取消任务后仍然不同意：orderstate=>11 第三方介入
  /*
    jpush=>12           接单人拒绝
    jpush=>13           发单人拒绝
    $_POST["userId"]          登陆者id
    $_POST["taskId"]          任务id
    $_POST["receiveId"]       接单id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  处理成功
    返回参数 result=>2  没有这个订单|退还酬金失败
    返回参数 result=>3  没有对应的接单信息
    返回参数 result=>4  用户错误
    返回参数 result=>5  自己没有权利同意自己的取消订单
  */
  public function disagree_cancel_order(){
    // $_POST["userId"]    = 56;
    // $_POST["taskId"]    = 37;
    // $_POST["receiveId"] = 1;
    $max_cancel_num = 3;  //最大取消次数
    if(!isset($_POST['userId']) || !isset($_POST['receiveId']) || !isset($_POST['taskId'])){
      // 缺少参数
      $result = array(
          "result" => "0",
          "info"   => "缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid    = $_POST['userId'];
    $receiveid = $_POST['receiveId'];
    $orderid   = $_POST['taskId'];
    // 验证order
    $o_m = M("orderlist");
    $order = $o_m->where(array("id"=>$orderid,"isdel"=>0,"receive_order_id"=>$receiveid))->field("userid,orderstate,cancel_num")->find();
    if($order["orderstate"]<7 || $order["orderstate"]>8){
      $result = array(
          "result" => "5",
          "info"   => "此订单不在拒绝的范围内"
        );
      echo json_encode($result);exit;
    }
    if($order){
      // 获取接单信息
      $r_o_m = M("receiveOrder");
      $receive = $r_o_m->where(array("id"=>$receiveid,"orderid"=>$orderid,"isdel"=>0))->field("userid,cancel_num")->find();
      if($receive){
      // 判断来着是发单人还是接单人
        if($order["userid"]==$userid && $order["orderstate"]==8){
          // 是发单人
          // 判断是否申请满三次
          if($receive["cancel_num"]>=$max_cancel_num){
            // 将orderstate=>11 
            $title = "第三方介入";
            $msg = "用户拒绝用户id为{$receive['userid']}的接单人的取消任务请求,超过{$max_cancel_num}次,请求第三方介入";
            // jpush拒绝取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($receive["userid"],"{$jname}拒绝取消本次任务，已满3次，第三方介入","12");
            $this->do_disagree($orderid,$userid,11,$msg,$title);
          }else{
            // jpush拒绝取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($receive["userid"],"{$jname}拒绝取消本次任务","12");
            $title = "拒绝取消";
            $msg = "用户拒绝用户id为{$receive['userid']}的发单人的取消任务请求,第{$receive["cancel_num"]}次";
            $this->do_disagree($orderid,$userid,11,$msg,$title);
          }
        }elseif($receive["userid"]==$userid && $order["orderstate"]==7){
          // 是接单人
          // 判断是否申请满三次
          if($order["cancel_num"]>=$max_cancel_num){
            // 申请满3次
            $title = "第三方介入";
            $msg = "用户拒绝用户id为{$order['userid']}的发单人的取消任务请求,超过{$max_cancel_num}次,请求第三方介入";
            // jpush拒绝取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($order["userid"],"{$jname}拒绝取消本次任务","13");
            $this->do_disagree($orderid,$userid,11,$msg,$title);
          }else{
            // 不满3次
            $title = "拒绝取消";
            $msg = "用户拒绝用户id为{$order['userid']}的发单人的取消任务请求,第{$order["cancel_num"]}次";
            // jpush拒绝取消任务
            $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
            // $jres = $this->jpush_msg($order["userid"],"{$jname}拒绝取消本次任务","13");
            $this->do_disagree($orderid,$userid,2,$msg);
          }
        }else{
          $result = array(
              "result" => "4",
              "info"   => "用户错误"
            );
          echo json_encode($result);exit;
        }
      }else{
        $result = array(
            "result" => "3",
            "info"   => "没有对应的接单信息"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "没有这个订单"
        );
      echo json_encode($result);exit;
    }
  }

  // 在发单人同意之前 接单人取消接单
  /*
    $_POST["receiveId"]       接单id
    $_POST["userId"]          登陆者id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  请求成功
    返回参数 result=>2  数据库没有数据
    返回参数 result=>3  登录用户不为接单用户本人
    返回参数 result=>4  此订单无法取消
    返回参数 result=>5  取消失败
  */
  /*public function cancel_receive_before_agree(){
    if(!isset($_POST["userId"]) || !isset($_POST["receiveId"]) || !$_POST["userId"] || !$_POST["receiveId"]){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $receiveid = $_POST["receiveId"];
    $userid    = $_POST["userId"];
    // 验证接单id和登陆者关系
    $map1 = array(
        "id"    => $receiveid,
        "isdel" => 0
      );
    $m = M("receiveOrder");
    $r_res = $m->where($map1)->field("orderid,userid,status")->find();
    if($r_res){
      if($r_res["userid"] !== $userid){
        $result = array(
            "result"=>"3",
            "info"  =>"登录用户不为接单用户本人"
          );
        echo json_encode($result);exit;
      }
      if($r_res["status"]==1){
        $result = array(
            "result"=>"4",
            "info"  =>"此订单无法取消"
          );
        echo json_encode($result);exit;
      }
      // 得到orderid
      $map2 = array(
          "id"    => $r_res["orderid"],
          "isdel" =>0
        );
      $o_res = M("orderlist")->where($map2)->getField("receive_order_id");
      if($o_res !== $receiveid){
        // 可以取消 status=>2
        $res = $m->where($map1)->setField(array("status"=>2));
        if($res){
          $result = array(
              "result"=>"1",
              "info"  =>"取消成功"
            );
          echo json_encode($result);exit;
        }else{
          $result = array(
              "result"=>"5",
              "info"  =>"取消失败"
            );
          echo json_encode($result);exit;
        }
      }
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"数据库没有数据"
        );
      echo json_encode($result);exit;
    }
  }*/
  public function cancel_receive_before_agree(){
    $this->cancel_order_after_agree();
  }

  // 发单 ———— 余额支付
  /*
    $_POST["userId"]    登录用户的id
    $_POST["orderId"]   订单id
    返回参数 result=>0  缺少请求参数
    返回参数 result=>1  请求成功
    返回参数 result=>2  用户与订单不匹配
    返回参数 result=>3  订单数据错误
    返回参数 result=>4  订单状态错误
    返回参数 result=>5  余额不足
    返回参数 result=>6  支付失败
    返回参数 result=>7  返回余额失败，请联系客服
  */
  public function wallet_pay(){
    // $_POST["userId"] = 67;
    // $_POST["orderId"] = 54;
    if(!isset($_POST["userId"]) || !isset($_POST["orderId"])){
      // 缺少参数
      $result = array("result"=>"0");
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $orderid = $_POST["orderId"];
    $m_m = M("member");
    $o_m = M("orderlist");
    $map2['id'] = $orderid;
    $map2['isdel'] = 0;
    $order = $o_m->where($map2)->field("userid,prepay,orderstate,status,pay_time")->find();
    $map["id"] = $userid;
    $map["isdel"] = 0;
    $map["status"] = 0;
    $user = $m_m->where($map)->field("id,wallet")->find();
    // 验证用户是否正确
    if($order["userid"] != $userid){
      $result = array(
          "result"=>"2",
          "info"  =>"用户与订单不匹配"
        );
      echo json_encode($result);exit;
    }
    if($order["status"] != 0){
      $result = array(
          "result"=>"3",
          "info"  =>"订单数据错误"
        );
      echo json_encode($result);exit;
    }
    if($order["orderstate"]>0){
      $result = array(
          "result"=>"4",
          "info"  =>"订单状态错误"
        );
      echo json_encode($result);exit;
    }
    // 这里要处理手续费
    if($user["wallet"]<$order["prepay"]){
      $result = array(
          "result"=>"5",
          "info"  =>"余额不足"
        );
      echo json_encode($result);exit;
    }
    // 进入支付流程
    $o_m -> startTrans();
    $data = array(
        "status" => 1,
        "pay_type" => 2,
        "orderstate" => 0,
        "real_pay"   => $order["prepay"],
        "pay_time" =>date("Y-m-d H:i:s",time())
      );
    $res = $o_m->where($map2)->setField($data);
    if($res){
      $money = $order["prepay"];
      $res2 = $m_m->where($map)->setDec("wallet",$money);
      if($res2 !== false){
        $yue = $m_m->where($map)->getField("wallet");
        $o_m->commit();
        $result = array(
            "result"=> "1",
            "info"  => "支付成功",
            "wallet"=> $yue
          );
        echo json_encode($result);exit;
      }else{
        $o_m->rollback();
        $result = array(
            "result"=>"7",
            "info"  =>"支付失败，扣除余额失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result"=>"6",
          "info"  =>"支付失败"
        );
      echo json_encode($result);exit;
    }
  }

  // 完善详细信息——接单
  /*
    $_POST["userId"]        登录者的id
    $_POST["realname"]      真实姓名
    $_POST["country"]       籍贯
    $_POST["card_id"]       身份证号
    $_POST["specialty"]     特长
    以上必填
    $_POST["qq_number"]     qq号        
    $_POST["wx_number"]     微信号
    要判断
    是否完成身份证上传
  */
  public function edit_my_info(){
    // $_POST["userId"]   = 67;
    // $_POST["realname"] = "郑伊凡1";
    // // $_POST["wallet"]   = 1000000000;
    // $_POST["country"]  = "ruian";
    // $_POST["card_id"]  = "122333";
    // $_POST["specialty"]= "奥奥奥奥";
    // $_POST["qq_number"]= "333333";  
    // $_POST["wx_number"]= "wx2333";
    if(!isset($_POST["userId"]) || 
       !isset($_POST["realname"]) ||
       // !isset($_POST["specialty"]) ||
       !isset($_POST["country"]) ||
       !isset($_POST["card_id"])
      ){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    if(!$_POST["userId"]||
       !$_POST["realname"]||
       !$_POST["country"]||
       // !$_POST["specialty"]||
       !$_POST["card_id"]
    ){
      $result = array(
          "result"=>"2",
          "info"  =>"缺少必填参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["id"] = $_POST["userId"];
    $m = M("Member");
    // 判断是否提交完整的身份证照
    $idcard_pic = $m->where(array("id"=>$userid,"status"=>0,"isdel"=>0))->field("idcard_pic1,idcard_pic2,idcard_pic3")->find();
    if(!$idcard_pic["idcard_pic1"] || !$idcard_pic["idcard_pic2"] || !$idcard_pic["idcard_pic3"]){
      $result = array(
          "result"=>"5",
          "info"  =>"身份证照片不完整"
        );
      echo json_encode($result);exit;
    }

    $data = array(
        "id"        => $userid,
        "realname"  => $_POST["realname"],
        "country"   => $_POST["country"],
        "realname"  => $_POST["realname"],
        "card_id"   => $_POST["card_id"],
        "specialty" => $_POST["specialty"]?$_POST["specialty"]:"",
        "qq_number" => $_POST["qq_number"],
        "wx_number" => $_POST["wx_number"],
        "isexamine" => 3,
      );
    $res = $m->save($data);
    if($res===false){
      // 无法修改
      $result = array(
          "result"=>"4",
          "info"  =>"修改失败"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"1",
          "info"  =>"修改成功"
        );
      echo json_encode($result);exit;
    }
  }


  // 上传身份证照片
  /*
    $_POST["userId"]               用户id
    $_FILES["idcard_pic1"]         证书照片页图片
    $_FILES["idcard_pic2"]         证书编号页图片
    $_FILES["idcard_pic3"]         手持证件头部照
    返回参数 result=>0             缺少请求参数
    返回参数 result=>1             上传身份证成功
    返回参数 result=>2             没有这个用户
    返回参数 result=>3             上传身份证失败
  */
  public function upload_card_id(){
    if(!isset($_POST["userId"]) || 
       !isset($_FILES)){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少请求参数"
        );
      echo json_encode($result);exit;
    }
    if($_POST["userId"]){
      $map["id"] = $_POST["userId"];
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"没有这个用户"
        );
      echo json_encode($result);exit;
    }
    // 上传图片
    if ($_FILES) {
      foreach ($_FILES as $key=>$file) {
        if ($file['error']==0) {
          # 配置上传目录
          $cfg=array(
            'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
            );
          $up=new \Think\Upload($cfg);
          $move=$up->uploadOne($_FILES[$key]);
          $picPath=$up->rootPath.$move['savepath'].$move['savename'];
          $data[$key]="/".trim(trim($picPath,"."),"/");;
        }
      }
    }
    $res = M("member")->where($map)->save($data);
    if($res){
      // 保存数据成功
      $result = array(
          "result"=>"1",
          "info"  =>"上传身份证成功"
        );
      echo json_encode($result);exit;
    }else{
      // 保存数据失败
      $result = array(
          "result"=>"3",
          "info"  =>"上传身份证失败"
        );
      echo json_encode($result);exit;
    }
  }


  // 发布任务【添加敏感词汇过滤】
  public function task(){

    if(!isset($_POST["classification"]) || 
       !isset($_POST["description"]) || 
       !isset($_POST["taskTime"]) || 
       !isset($_POST["minute"]) || 
       // !isset($_POST["audio"]) || 
       // !isset($_POST["audiotime"]) || 
       // !isset($_POST["descriptionImg"]) || 
       // !isset($_POST["specialRequirement"]) || 
       // !isset($_POST["commission"]) || 
       !isset($_POST["prepay"]) || 
       !isset($_POST["place"]) || 
       !isset($_POST["userId"])  || 
       !isset($_POST["longitude"]) || 
       !isset($_POST["latitude"]) ){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $classification=$_POST['classification'];                                                       //任务类型
    $description=$_POST['description'];                                                             //任务描述
    $taskTime=$_POST['taskTime'];                                                                   //任务时间
    $minute=isset($_POST['minute'])?$_POST['minute']:'';                                            //任务详情
    $audio=$_POST['audio'];                                                                         //音频文件
    $audiotime=$_POST['audiotime'];                                                                 //音频时间
    $descriptionImg=$_POST['descriptionImg'];                                                       //图片数组
    $specialRequirement=isset($_POST['specialRequirement'])?$_POST['specialRequirement']:"";        //特殊需求
    // $remuneration=$_POST['commission'];                                                             //任务酬金
    $prepay=$_POST['prepay'];                                                                       //预支付
    $place=$_POST['place'];                                                                         //任务地点
    $userid=$_POST['userId'];                                                                       //用户ID
    $longitude=$_POST['longitude'];                                                                  //经度
    $latitude=$_POST['latitude'];                                                                    //维度
    $remuneration = $prepay;
    // $classification=11;                                                       //任务类型
    // $description=11;                                                             //任务描述
    // $taskTime=11;                                                                   //任务时间
    // $minute=11;                                            //任务详情
    // // $audio=11;                                                                         //音频文件
    // // $descriptionImg=11;                                                       //图片数组
    // // $specialRequirement=11;        //特殊需求
    // $remuneration=11;                                                             //任务酬金
    // $prepay=11;                                                                       //预支付
    // $place=11;                                                                         //任务地点
    // $userid=67;                                                                       //用户ID
    // $longitude=11;                                                                  //经度
    // $latitude=11;
    // // $audiotime=11;

    // 此处过滤 minute 和 $description 
    $words = M("sensitive_words")->where(array("status"=>1))->select();

    foreach($words as $v){
      $minute = str_replace($v["word"], "*", $minute);
      $description = str_replace($v["word"], "*", $description);
    }

    # 生成订单
    $addtime=date('Y-m-d H:i:s');
    $order_no=time().rand(100,999);
    $orderlist=M('orderlist');  
    $data = array(  
        'type' => $classification,  
        'title' => $description,  
        'addtime' => $addtime,  
        'content' => $minute,  
        'special' => $specialRequirement,  
        'remuneration' => $remuneration,  
        'prepay' => $prepay,  
        'userid' => $userid,  
        'btime' => $addtime,  
        'order_no' => $order_no,
        'longitude'=> $longitude,
        'place' => $place,
        'latitude'=> $latitude,
        'audiotime'=> $audiotime,
         );  
    # 接收音频
    if($_FILES['audio']){
    	if ($_FILES['audio']['error']==0) {
     	 # 配置上传目录
      	$cfg=array(
        'rootPath' => './Public/Admin/Upload_audio/', //保存根路径
       	 );
	      $up=new \Think\Upload($cfg);
	      $move=$up->uploadOne($_FILES['audio']);
	      $audioPath=$up->rootPath.$move['savepath'].$move['savename'];

        if(strpos($move['savename'], ".mp3")===false){
          $amr=IMG_URL.$audioPath;//你amr文件路径

          $file=base64_encode(base64_encode($amr));//对文件路径进行base64加密
           
          $back=file_get_contents("http://api.yizhancms.com/video/index.php?i=1&f=$file");
           
          $result=(array)json_decode($back);//接口返回status和f'参数,f为转换后mp3的文件路径:
           
          if($result["status"]){
            @unlink($audioPath);
            $audioPath = $audioPath.".mp3";
            copy($result['f'],$audioPath);//把接口返回的mp3文件重命名为new.mp3保存到当目录
          }
        }


	      $data['audio']="/".trim(trim($audioPath,"."),"/");
    	}
    }
    
    # 接收图片
    unset($_FILES['audio']);
    if ($_FILES) {
      foreach ($_FILES as $key=>$file) {
        if ($file['error']==0) {
          # 配置上传目录
          $cfg=array(
            'rootPath' => './Public/Admin/Upload_pic/', //保存根路径
            );
          $up=new \Think\Upload($cfg);
          $move=$up->uploadOne($_FILES[$key]);
          $picPath=$up->rootPath.$move['savepath'].$move['savename'];
          $data[$key]="/".trim(trim($picPath,"."),"/");;
        }
      }
    }
    $order_id=$orderlist->add($data);  
    
    if ($order_id) {
      $return=array(
        "result"  => "1",
        "orderId" => $order_id
        );
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);exit;
  }

  // 任务图片音频提交测试
  public function form111(){
    $this->display();
  }
  public function taskSort(){
    # 任务类型 --获取一级分类--遍历一级数组查询子数组
    $parArr=D("task_class")->where(array('parid'=>0,"isdel"=>0))->select();
    if ($parArr) {
      $chirArr=array();
      foreach ($parArr as $p) {
        $chirArr=D("task_class")->where(array('parid'=>$p['id'],"isdel"=>0))->select();
        foreach ($chirArr as $c) {
          $chirName[$p['classname']][]=array(
            "sortId"=>$c['id'],
            "sortName"=>$c['classname'],
            );
        }
      }
      if (isset($chirName)) {
        $return=array(
          "result"=>"1",
          "sort"=>$chirName
          );
      }else{
        $return=array("result"=>"0");
      }
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  // 接单
  public function receive(){
    # 接收用户经纬度信息
    $longitude=$_POST['longitude'];       
    $latitude=$_POST['latitude'];

    // $longitude=11;       
    // $latitude=22;
    # 分类数组
    $parArr=D("task_class")->where(array('parid'=>0,"isdel"=>0))->select();
    if ($parArr) {
      $chirArr=array();
      foreach ($parArr as $p) {
        $chirArr=D("task_class")->where(array('parid'=>$p['id'],"isdel"=>0))->select();
        foreach ($chirArr as $c) {
          $chirName[$p['classname']][]=array("sortId"=>$c['id'],"sortName"=>$c['classname']);
        }
      }
      if (isset($chirName)) {
        $typeDic=$chirName;
      }else{
        $typeDic=array();
      }
    }else{
      $typeDic=array();
    }

    # 获取地理范围数组
    $range=D("range")->select();
    if ($range) {
      foreach ($range as $r) {
        # 遍历范围数组重新组合返回
        $rangeArr[]=array(
          "rangeId"=>$r['id'],
          "rangeName"=>$r['range'],
          );
      }
    }else{
      $rangeArr=array();
    }

    # 获取时间范围
    $time=D("timearea")->where("isdel=0")->select();
    if ($time) {
      foreach ($time as $r) {
        # 遍历范围数组重新组合返回
        $timeArr[]=array(
          "timeId"=>$r['id'],
          "timeName"=>$r['timearea'],
          );
      }
    }else{
      $timeArr=array();
    }

    # 条件
    $conditionArr=array("条件1", "条件2", "条件3", "条件4");
    # 附近人数
    $nearbyNnt="50";

    // 未被接单的
    $map["orderstate"] = array(array("egt",0),array("elt",1),"and");
    // 已经支付的
    $map["status"] = 1;
    $map["isdel"] = 0;

    # 任务数组
    $task=D("orderlist")->where($map)->order("addtime desc")->select();

    if ($task) {
      # 构建任务数组
      foreach ($task as $k=>$t) {
        # 遍历范围数组重新组合返回
        # 获取用户信息
        $user=D("member")->where(array('id'=>$t['userid'],"isdel"=>0,"status"=>0))->find();
        if(!$user){
          continue;
        }
        $type=D("task_class")->where(array('id'=>$t['type'],"isdel"=>0))->find();
        $imgArrOld=array(
          $t['pic1'],
          $t['pic2'],
          $t['pic3'],
          $t['pic4'],
          $t['pic5'],
          $t['pic6'],
          );
        # 去除数组中的空元素
        $imgArrNew=array_filter($imgArrOld);
        $imgArr=array();
        foreach ($imgArrNew as $i) {
          $imgArr[]=IMG_URL.$i;
        }
        $round = getDistance($t["longitude"],$t["latitude"],$longitude,$latitude);
        $res = round($round/1000,2);
        $personimg=!empty($user['person_img'])?$user['person_img']:'Public/Admin/Upload_pic/header.png';
        $twoCellArr[]=array(
          "taskID"=>$t['id'],
          "personName"=>$user['person_name'],
          "personImg"=>IMG_URL.$personimg,
          "grade"=>$user['vip'],
          "reward"=>$t['remuneration'],
          "classification"=>$type['classname'],
          "taskTitle"=>$t['title'],
          "descriptionImg"=>$imgArr,
          "taskTime"=>$t['btime'],
          // "place"=>"华星时代广场",                             //地图api用经纬度获取
          'longitude'=> $t["longitude"],
          'latitude'=> $t["latitude"],
          'place' => $t['place'],
          "time"=>$this->time_tran($t['addtime']),                             
          "distance"=>(String)$res,                           //地图api获取距离
          );
      }
    }else{
      $twoCellArr=array();
    }
    $return=array(
      'result'=>'1',
      'typeDic'=>$typeDic,
      'rangeArr'=>$rangeArr,
      'timeArr'=>$timeArr,
      'conditionArr'=>$conditionArr,
      'nearbyNnt'=>$nearbyNnt,
      'twoCellArr'=>$twoCellArr,
      );
    echo json_encode($return);
  }
  
  //任务详情      
  public function taskDetail(){
    // $_POST['taskID']=37;                       //测试数据
    // $_POST['userId']=67;                       //测试数据
    if(!isset($_POST['userId']) || !isset($_POST['taskID'])){
      $return=array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($return);exit;
    }
    $userid = $_POST["userId"];
    $taskID=$_POST['taskID'];                       //任务id


    $collectid = M("mycollect")->where(array("userid"=>$userid,"taskid"=>$taskID,"isdel"=>0))->getField("id");


    $task=D("orderlist")->where(array('id'=>$taskID,"isdel"=>0))->find();
    if ($task) {
      // 判断是否已经结果单
      $isreceive = M("receiveOrder")->where(array("orderid"=>$task["id"],"userid"=>$userid,"isdel"=>0))->getField("id");
      $type=D("task_class")->where(array('id'=>$task['type'],"isdel"=>0))->field('classname')->find();
      $user=D("member")->where(array('id'=>$task['userid'],"isdel"=>0))->find();
      // $userinfo=D("memberinfo")->where(array('memberid'=>$task['userid']))->find();
      $specialRequirement=isset($task['special'])?$task['special']:"无";
      $imgArrOld=array(
          $task['pic1'],
          $task['pic2'],
          $task['pic3'],
          $task['pic4'],
          $task['pic5'],
          $task['pic6'],
          );
        # 去除数组中的空元素
        $imgArrNew=array_filter($imgArrOld);
        $imgArr=array();
        foreach ($imgArrNew as $i) {
          $imgArr[]=IMG_URL.$i;
        }
      $personimg=!empty($user['person_img'])?$user['person_img']:'Public/Admin/Upload_pic/header.png';
	 
      $return=array(
        "result"=>"1",
        "userId"=>$task['userid'],
        "chatID"=>$user['chat_id'],                                                   //融云聊天ID
        "personImg"=>IMG_URL.$personimg,
        "personName"=>$user['person_name'],
        "evaluate"=>$user['evaluate'],
        "classification"=>$type['classname'],
        "taskDescription"=>$task['title'],
        "taskTime"=>$task['addtime'],
        "descriptionImg"=>$imgArr,
        "reward"=>$task['remuneration'],
        "audio"=>isset($task['audio'])?IMG_URL.$task['audio']:"1",
        "audiotime"=>isset($task['audio'])?$task['audiotime']:"0",
        'longitude'=> $task["longitude"],
        'latitude'=> $task["latitude"],
        'place' => $task['place'],
        "minute"=>$task['content'],
        "specialRequirement"=>$specialRequirement,
        "isreceive"=>$isreceive?"1":"0"   //判断是否接过单
        );
      if($collectid === false){
        $return=array(
            "result"=>"2",
            "info"  =>"查询收藏失败"
          );
        echo json_encode($return);exit;
      }elseif($collectid){
        $return["collectid"] = $collectid;
        echo json_encode($return);exit;
      }else{
        $return["collectid"] = "0";
        echo json_encode($return);exit;
      }
    }else{
      $return=array("result"=>'0');
    }
    echo json_encode($return);exit;
  }

  //任务收藏
  public function collect(){
    // $_POST['taskID']=38;
    // $_POST['userID']=67;
    $taskID=$_POST['taskID'];
    $userID=$_POST['userID'];
    if(!isset($_POST['taskID']) || !isset($_POST['userID'])){
      $return=array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($return);exit;
    }
    // 判断是否已经收藏过
    $map=array(
      "userid"=>$userID,
      "taskid"=>$taskID,
      "isdel"=> 0,
      );
    $m = D('mycollect');
    $res = $m->where($map)->getField("id");
    if($res){
      $return=array(
          "result"=>"2",
          "info"  =>"已经收藏过"
        );
      echo json_encode($return);exit;
    } 
    $map2=array(
      "userid"=>$userID,
      "taskid"=>$taskID,
      "isdel"=> 1,
      );
    $res2 = $m->where($map2)->field("id")->find();
    if($res2){
      $data["isdel"] = 0;
      $map2['id'] = $res2["id"];
      $res3 = $m->where($map2)->save($data);
      if($res3){
        $return=array("result"=>"1");
        echo json_encode($return);exit;
      }else{
        $return=array(
            "result"=>"2",
            "info"  =>"收藏失败"
          );
        echo json_encode($return);exit;
      }
    } 
    $data=array(
      "userid"=>$userID,
      "taskid"=>$taskID,
      "addtime"=>date('Y-m-d H:i:s',time()),
      );
    $collectID=$m->add($data);
    if ($collectID) {
      $return=array("result"=>"1");
    }else{
      $return=array("result"=>"0");
    }
    echo json_encode($return);
  }

  // 补差价
  /*
    业务逻辑  orderstate = 1；
    real_pay订单同意后的实付金额   diff_money差价  prepay预支付 支付的总金额 酬金+手续费  remuneration酬金
    pay_diff_time支付差价，退还差价时间
    支付成功  status=>1(已支付)          pay_msg=>2(有差价已支付)  
    支付失败  status=>2(2差价支付失败)   pay_msg=>6(支付差价失败)  
    $_POST["userId"]          登陆者的id
    $_POST["orderId"]         任务订单的id
    $_POST["receiveId"]       接单id
    $_POST["paytype"]         补差价标识   0 微信支付 1 支付宝支付 2余额
    返回参数 result=>0             缺少请求参数
    返回参数 result=>1             请求成功
    返回参数 result=>2             没有此订单的内容
    返回参数 result=>3             没有此接单的信息
    返回参数 result=>4             此订单不符合补差价的条件
    返回参数 result=>5             用户余额不足
    返回参数 result=>6             保存订单失败
    返回参数 result=>7             扣除余额失败
  */
  public function fill_the_difference(){
    // $_POST["orderId"]   = 36;
    // $_POST["userId"]    = 80;
    // $_POST["receiveId"] = 37;
    if(!isset($_POST["userId"]) ||
       !isset($_POST["orderId"]) ||
       !isset($_POST["paytype"]) ||
       !isset($_POST["receiveId"])){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少请求参数"
        );
      echo json_encode($result);exit;
    }
    $userid      = $_POST["userId"];
    $orderid     = $_POST["orderId"];
    $receiveid   = $_POST["receiveId"];
    $diffpaytype = $_POST["paytype"];
    // 拿到订单的 酬金 预支付  和 实际支付
    $o_map = array(
        "id"          => $orderid,
        "orderstate"  => 1,
        "userid"      => $userid,
        "isdel"       => 0
      );
    $r_o_map = array(
        "id"      => $receiveid,
        "orderid" => $orderid,
        "status"  => 0,          // 处于未完成状态
        "isdel"   => 0
      );
    $m_m     = M("member");
    $user    = $m_m->where(array("id"=>$userid,"isdel"=>0))->find();
    $o_m     = M("orderlist");
    $o_res   = $o_m->where($o_map)->field("orderstate,order_no,prepay,remuneration,real_pay")->find();
    if(!$o_res){
      // 缺少参数
      $result = array(
          "result"=>"2",
          "info"  =>"没有此订单的内容"
        );
      echo json_encode($result);exit;
    }
    $r_o_m   = M("receiveOrder");
    $r_o_res = $r_o_m->where($r_o_map)->field("charge")->find();
    if(!$r_o_res){
      // 缺少参数
      $result = array(
          "result"=>"3",
          "info"  =>"没有此接单的信息"
        );
      echo json_encode($result);exit;
    }
    $charge = $r_o_res["charge"];
    // 符合补差价的要求
    if($charge>=0 && $charge>$o_res["remuneration"]){
      $dif = $charge - $o_res["remuneration"];// 差价
      // 符合补差价条件
      // $diffpaytype     补差价标识   0 微信支付 1 支付宝支付 2余额
      // 判断补差价的方式
      if($diffpaytype == 0){
        $param = array(
              "receiveid"  => $receiveid,
              "charge"     => $charge,
              "dif"        => $dif,
          );
        $order_no = "BCJ".$o_res["order_no"];
        $this->wxpay_diff_api($order_no,$dif,$param);
      }elseif($diffpaytype == 1){
        $param = array(
              "receiveid"  => $receiveid,
              "charge"     => $charge,
              "dif"        => $dif,
          );
        $order_no = "BCJ".$o_res["order_no"];
        $this->alipay_diff_api($order_no,$dif,$param);
      }elseif($diffpaytype == 2){
        if($user["wallet"]>=$dif){
          $o_m->startTrans();
          $o_data = array(
              "status"            => 1,
              "orderstate"        => 2,
              "receive_order_id"  => $receiveid,
              "pay_msg"           => 2,
              "remuneration"      => $charge,
              "diff_money"        => $dif,
              "diff_pay_type"     => 2,     // 表示余额支付
              "real_pay"          => $o_res["real_pay"] + $dif,
              "pay_diff_time"     => date("Y-m-d H:i:s",time())
            );
          $o_res2 = $o_m->where(array("id"=>$orderid))->save($o_data);
          if($o_res2){
            // 扣除用户余额
            $m_res2 = $m_m->where(array("id"=>$userid))->setDec("wallet",$dif);
            if($m_res2){
              $o_m->commit();
              $wallet=$m_m->where(array('id'=>$userid))->getField("wallet");
              $result = array(
                  "result"=>"1",
                  "info"  =>"操作成功",
                  "wallet"=>$wallet,
                );
              echo json_encode($result);exit;
            }else{
              $o_m->rollback();
              $result = array(
                  "result"=>"7",
                  "info"  =>"扣除余额失败"
                );
              echo json_encode($result);exit;
            }
          }else{
            // 余额不足
            $o_m->rollback();
            $result = array(
                "result"=>"6",
                "info"  =>"保存订单失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          // 余额不足
          $result = array(
              "result"=>"5",
              "info"  =>"用户余额不足"
            );
          echo json_encode($result);exit;
        }
      }
    }else{
      // 缺少参数
      $result = array(
          "result"=>"4",
          "info"  =>"此订单不符合补差价的条件"
        );
      echo json_encode($result);exit;
    }


  }



  // [任务模块] 




  // [好友模块]

  // 好友推荐
  /*
    业务逻辑：根据登录者的地域（市）来推荐好友，没填或者查不到的话，推荐新注册的好友
    $_POST["userId"]    登录者id
    返回参数 result=>0             缺少请求参数
    返回参数 result=>1             请求成功
    返回参数 result=>2             唯有符合条件的推荐
  */
  public function recommend_firends(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少请求参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $m_m = M("member");
    $user = $m_m->where(array("id"=>$userid,"isdel"=>0,"status"=>0))->field("id,country,sex")->find();
    $sex = $user["sex"]==1?2:1;
    $country = explode(",",$user["country"]);
    $country = $country[1];
    if($country){
      $map = array(
          "id"     => array("neq",$userid),
          "sex"    => $sex,
          "country"=>array("like","%$country%"),
          "isdel"  => 0,
          "status" => 0
        );
      $newfriends = $m_m->where($map)->field("id as friendid,person_name,person_img,signature")->limit(10)->select();
    }
    if(!$country || !$newfriends){
      // 如果为空
      // 推荐最近注册的三人
      // 得到用户的好友列表的id
      $mf_m = M("memberFriend");
      $list1 = $mf_m->where(array("userid2"=>$userid,"isdel"=>0))->field("userid1 as id")->select();
      $list2 = $mf_m->where(array("userid1"=>$userid,"isdel"=>0))->field("userid2 as id")->select();
      $list = array_merge($list1,$list2);
      foreach($list as $k=>$v){
        $arr[] = $v["id"];
      }
      $str = implode(",",$arr);
      $str = $str?$str:"";
      $map = array(
          "id"    => array(array("neq",$userid),array("not in",$str),"and"),
          "sex"   => $sex,
          "isdel" => 0,
          "status"=> 0
        );
      $newfriends = $m_m->where($map)->field("id as friendid,person_name,person_img,signature")->limit(10)->select();
    }
    foreach($newfriends as $k=>$v){
      $newfriends[$k]["person_img"] = $this->deal_img($v["person_img"]);
    }
    if($newfriends){
      $result = array(
          "result" => "1",
          "info"   => $newfriends
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result" => "2",
          "info"   => "没有符合条件的推荐"
        );
      echo json_encode($result);exit;
    }
  }



  // 融云 获取token
  /*
    $_POST["userId"]    登录用户的id
    返回参数 result=>0             缺少请求参数
    返回参数 result=>2             请求失败
  */
  public function get_rongyun_token(){
    // $_POST["userId"] = 56;
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少请求参数"
        );
      echo json_encode($result);exit;
    }
    $map["id"] = $_POST["userId"];
    $map["status"] = 0;
    $map["isdel"] = 0;
    $member = M("member")->where($map)->field("id,person_name,person_img")->find();
    $member["person_img"] = $this->deal_img($member["person_img"]);
    $res = $this->rongyun_token($member["id"],$member["person_name"],$member["person_img"]);
    if($res){
      echo $res;exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"请求失败"
        );
      echo json_encode($result);exit;
    }
  }




  // 好友列表 接口
  /*
    $_POST["userId"]      登陆者的id
    返回参数 result=>0             缺少请求参数
    返回参数 result=>1             请求成功
    返回参数 result=>2             数据库查找出错
  */
  public function friends_list(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      // 缺少参数
      $result = array(
          "result"=>"0",
          "info"  =>"缺少请求参数"
        );
      echo json_encode($result);exit;
    }
    $m_f_m = M("memberFriend");
    $userid = $_POST["userId"];
    $map['userid1'] = $map2["userid2"] = $userid;
    $map['mf.isdel'] = $map2['mf.isdel'] = 0;
    $DB_PREFIX = C("DB_PREFIX");
    $str1 = "left join {$DB_PREFIX}member as m on mf.userid2 = m.id and m.isdel=0 and m.status = 0";
    $friends1 = $m_f_m->alias("mf")->where($map)->
        join($str1)->
        field("m.id,m.person_img,m.person_name")->select();
    $str2 = "left join {$DB_PREFIX}member as m on mf.userid1 = m.id and m.isdel=0 and m.status = 0";
    $friends2 = $m_f_m->alias("mf")->where($map2)->
        join($str2)->
        field("m.id,m.person_img,m.person_name")->select();
    if($friends1 ===false || $friends2 ===false){
      $result = array(
          "result" => "2",
          "info"   => "数据库查找出错"
        );
      echo json_encode($result);exit;
    }
    if($friends1 && $friends2){
      $friends = array_merge($friends1,$friends2);
    }elseif($friends1){
      $friends = $friends1;
    }elseif($friends2){
      $friends = $friends2;
    }else{
      $friends = array();
      $result = array(
          "result" => "1",
          "info"   => $friends
        );
      echo json_encode($result);exit;
    }
    $friends = array_merge($friends1,$friends2);
    foreach($friends as $k=>$v){
      $friends[$k]["person_img"] = $this->deal_img($v["person_img"]);
    }
    $result = array(
        "result" => "1",
        "info"   => $friends
      );
    echo json_encode($result);exit;
  }


  // 新的朋友 接口
  /*
    描述：这个接口展示
          自己添加别人为好友的情况
          自己添加别人为好友的情况
    $_POST["userId"]      登陆者的id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  没有数据
  */
  public function msg_of_newfriends(){
     // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $m = M("addFriendLog");
    // 表前缀
    $DB_PREFIX = C("DB_PREFIX");
    $lists1 = $m->alias("al")->field("al.id as add_log_id,fromid,al.toid as friendid,al.status,al.msg,al.addtime,m.person_img,m.person_name")->
        join("left join {$DB_PREFIX}member as m on al.toid=m.id and m.isdel = 0 and m.status = 0")->
        where(array("fromid"=>$userid,"al.isdel"=>0))->select();
    $lists2 = $m->alias("al")->field("al.id as add_log_id,fromid,al.fromid as friendid,al.status,al.msg,al.addtime,m.person_img,m.person_name")->
        join("left join {$DB_PREFIX}member as m on al.fromid=m.id and m.isdel = 0 and m.status = 0")->
        where(array("toid"=>$userid,"al.isdel"=>0))->select();
    if($lists1 && $lists2){
      $lists = array_merge($lists1,$lists2);
    }elseif($lists1){
      $lists = $lists1;
    }elseif($lists2){
      $lists = $lists2;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"没有数据"
        );
      echo json_encode($result);exit;
    }
    // 处理头像
    foreach($lists as $k=>$v){
      $lists[$k]["person_img"] = $this->deal_img($v["person_img"]);
    }

    $arrSort = array();  
    foreach($lists AS $uniqid => $row){  
        foreach($row AS $key=>$value){  
            $arrSort[$key][$uniqid] = $value;  
        }  
    }  
    // 对二维数组进行排序
    $sort = array(  
        'direction' => 'SORT_DESC', //排序顺序标志 SORT_DESC 降序；SORT_ASC 升序  
        'field'     => 'addtime',       //排序字段  
    );  
    array_multisort($arrSort[$sort['field']], constant($sort['direction']), $lists);
    // 0：申请添加对方为好友 1：同意添加为好友  2：拒绝
    foreach($lists as $k => $v){
      switch($v["status"]){
        case 0:
          if($v["fromid"]==$userid){
            $lists[$k]["btn"] = "等待验证";
          }else{
            $lists[$k]["btn"] = "同意";
          }
          break;
        case 1:
          $lists[$k]["btn"] = "已添加";
          break;
        case 2:
          if($v["fromid"]==$userid){
            $lists[$k]["btn"] = "被拒绝";
          }else{
            $lists[$k]["btn"] = "已拒绝";
          }
          break;
        default:
          unset($lists[$k]);
      }
    }
    $lists = $this->remove_null($lists);
    $data['info']=$lists;
    $data['result']='1';
    echo json_encode($data);
    exit;
  }

  // 新的朋友——点击同意 接口
  /*
    jpush=>1
    $_POST["add_log_id"]  
    $_POST["userId"]            登陆者的id
    $_POST["friendId"]          发来好友请求的id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  更改日志失败
    返回参数 result=>3  查找数据库失败
    返回参数 result=>4  已经是好友
    返回参数 result=>5  添加好友失败
  */
  public function agree_add_friend(){
    // $_POST["add_log_id"] = 17;
    // $_POST["userId"]     = 74;
    // $_POST["friendId"]   = 67;
    if(!isset($_POST["userId"]) || !isset($_POST["add_log_id"]) || !isset($_POST["friendId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid   = $_POST["userId"];
    $addlogid = $_POST["add_log_id"];
    $friendid = $_POST["friendId"];
    // 判断是否已经是好友
    $res1 = M("memberFriend")->where(array("userid1"=>$userid,"userid2"=>$friendid,"isdel"=>0))->find();
    if($res1 === false){
      $result = array(
          "result"=>"3",
          "info"  =>"查找数据库失败"
        );
      echo json_encode($result);exit;      
    }elseif($res1){
      // 有好友
      $result = array(
          "result"=>"4",
          "info"  =>"已经是好友"
        );
      echo json_encode($result);exit; 
    }else{
      // 没有好友
      $res2 = M("memberFriend")->where(array("userid2"=>$userid,"userid1"=>$friendid,"isdel"=>0))->find();
      if($res2===false){
        $result = array(
            "result"=>"3",
            "info"  =>"查找数据库失败"
          );
        echo json_encode($result);exit;   
      }elseif($res2){
        M("addFriendLog")->where(array("id"=>$addlogid,"status"=>0,"isdel"=>0))->save(array("status"=>1));
        $result = array(
            "result"=>"4",
            "info"  =>"已经是好友"
          );
        echo json_encode($result);exit; 
      }
    }
    $addlog_map = array(
        "id"     =>$addlogid,
        "fromid" =>$friendid,
        "toid"   =>$userid,
        "status" =>0,
        "isdel"  =>0
      );
    $addlog_data = array(
        "status" =>1,
      );
    $add_res = M("addFriendLog")->where($addlog_map)->save($addlog_data);
    if($add_res!==false){
      // 日志保存成功
      $m_f_data = array(
          "userid1"  => $userid,
          "userid2"  => $friendid,
          "datetime" => date("Y-m-d H:i:s",time())
        );
      $m_f_res = M("memberFriend")->add($m_f_data);
      if($m_f_res){
        // jpush同意好友
        $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
        $jres = $this->jpush_msg($friendid,"{$jname}同意的您的好友申请","1");
        $result = array(
            "result"  =>"1",
            "info"    =>"添加好友成功",
            "jpushinfo" => $jres
          );
        echo json_encode($result);exit;
      }else{
        M("addFriendLog")->where(array("id"=>$addlogid,"isdel"=>0))->save(array("status"=>0));
          $result = array(
            "result"=>"5",
            "info"  =>"添加好友失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"更改日志失败"
        );
      echo json_encode($result);exit;
    }
  }







  // 需要验证是否已经是好友
  // 详细资料 接口
  /*
    $_POST["memberId"]      用户id
    $_POST["userId"]        登陆者id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  操作失败
  */
  public function member_detail(){
    // $_POST["userId"] = 67;
    // $_POST["memberId"] = 56;
    if(!isset($_POST["memberId"]) || !isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $memberid = $_POST["memberId"];
    $map["id"] = $memberid;
    $map["status"] = 0;
    $map["isdel"] = 0;
    $res = M("member")->where($map)->field("id as memberid,person_name,person_img,realname,evaluate,country,signature")->find();
    $isfriend = $this->is_friend($userid,$memberid);
    if($res){
      $res["person_img"] = $this->deal_img($res["person_img"]);
      $result = array(
          "result"=>"1",
          "info"  => $res
        );
      $result["isfriend"] = $isfriend;
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"操作失败"
        );
      echo json_encode($result);exit;
    }
  }



  // 需要验证是否已经是好友
  // 请求添加——验证信息——提交 接口
  /*
    jpush=>0
    $_POST["userId"]        登陆者的id
    $_POST["memberId"]      请求添加好友的人的id
    $_POST["msg"]           验证信息
    返回参数 result=>0  缺少参数
    返回参数 result=>1  申请添加好友成功
    返回参数 result=>2  获取数据失败
    返回参数 result=>3  申请添加好友失败
    返回参数 result=>4  已经是好友
    返回参数 result=>5  已经申请过添加好友
    返回参数 result=>6  验证是否已经申请失败
    返回参数 result=>7  自己不能添加自己为好友
  */
  public function apply_add_friend(){
    // $_POST["userId"] =67;
    // $_POST["memberId"] =56;
    // $_POST["msg"] = "";
    if(!isset($_POST["memberId"]) || !isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $memberid = $_POST["memberId"];
    // 防止自己加自己好友
    if($userid == $memberid){
      $result = array(
          "result"=>"7",
          "info"  =>"自己不能添加自己为好友"
        );
      echo json_encode($result);exit;
    }
    $data["fromid"] = $userid;
    $data["toid"] = $memberid;
    $map["id"] = $userid;
    $map2["id"] = $memberid;
    $map["status"] = $map2["status"] = 0;
    $map["isdel"]  = $map2["isdel"]  = 0;
    // 判断是否已经是好友
    $isfriend = $this->is_friend($userid,$memberid);
    if($isfriend){
      $result = array(
          "result"=>"4",
          "info"  =>"已经是好友"
        );
      echo json_encode($result);exit;
    }
    $m = M("member");
    $username = $m->where($map)->getField("person_name");
    $isexists = $m->where($map2)->getField("id"); // 验证请求添加的好友是否还存在
    if(!$username || !$isexists){
      $result = array(
          "result"=>"2",
          "info"  =>"获取数据失败"
        );
      echo json_encode($result);exit;
    }
    $data["msg"] = $_POST["msg"]?$_POST["msg"]:"我是{$username}，请求添加你为好友";
    $data["addtime"] = date("Y-m-d H:i:s",time());
    $a_f_l_m = M("addFriendLog");
    // 在添加之前判断是否已经申请添加
    $map3["fromid"] = $userid;
    $map3["toid"] = $memberid;
    $map3["status"] = 0;
    $map3["isdel"] = 0;
    $has_add = $a_f_l_m->where($map3)->getField("id");
    if($has_add){
      $result = array(
          "result"=>"5",
          "info"  =>"已经申请过添加好友"
        );
      echo json_encode($result);exit;
    }elseif($has_add===false){
      $result = array(
          "result"=>"6",
          "info"  =>"验证是否已经申请失败"
        );
      echo json_encode($result);exit;
    }
    $res = $a_f_l_m->add($data);
    if($res){
      // jpush请求添加好友
      $jname = M("member")->where(array("id"=>$userid))->getField("person_name");
      $jres = $this->jpush_msg($memberid,"{$jname}申请添加您为好友","0");
      $result = array(
          "result"=>"1",
          "info"  =>"申请添加好友成功",
          "jpushinfo" => $jres
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"3",
          "info"  =>"申请添加好友失败"
        );
      echo json_encode($result);exit;
    }
  }


  // 通知 ：公司面试邀请通知
  /*
    $_POST["userId"]   登陆者的id
    返回参数 result=>0  缺少参数
    返回参数 result=>1  操作成功
    返回参数 result=>2  数据库无数据
    返回参数 result=>3  数据库操作失败
  */
  public function interview_notice(){
    // $_POST["userId"] = 67;
    if(!isset($_POST["userId"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $map["cil.userid"] = $userid;
    $map["cil.isdel"]  = 0;
    $map["c.isdel"]  = 0;
    $DB_PREFIX = C("DB_PREFIX");
    $join_str = "inner join {$DB_PREFIX}company as c on cil.companyid=c.id";
    $lists = M("companyInterviewLog")->
        alias("cil")->where($map)->join($join_str)->
        field("cil.id,cil.status,cil.addtime,cil.msg,c.company_name,c.logo_img")->
        order("addtime desc")->select();
    foreach($lists as $k=>$v){
      $lists[$k]["addtime"]  = date("m-d H:i",strtotime($v["addtime"]));
      $lists[$k]["logo_img"] = $this->deal_img($v["logo_img"]);
    }
    if($lists===false){
      $result = array(
          "result"=>"3",
          "info"  =>"数据库操作失败"
        );
      echo json_encode($result);exit;
    }elseif($lists){
      $result = array(
          "result"=> "1",
          "info"  => $lists
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=> "2",
          "info"  => "数据库无数据"
        );
      echo json_encode($result);exit;
    }
  }

  // 评价的接口
  /*
    $_POST["userId"]        登录者的id
    $_POST["orderId"]       订单id
    $_POST["comment"]       评论内容
    返回参数 result=>0   缺少参数/参数为空
    返回参数 result=>1   评论成功
    返回参数 result=>2   没有数据
    返回参数 result=>3   数据库操作失败
    返回参数 result=>4   修改订单状态失败
    返回参数 result=>5   评论失败
    返回参数 result=>6   查找接单数据失败
    返回参数 result=>7   非法操作
    返回参数 result=>8   评论失败
    返回参数 result=>9   订单不为可评论状态
    返回参数 result=>10  评论失败
  */
  public function evaluate(){
    // $_POST["userId"]  = 56;
    // $_POST["orderId"] = 38;
    // $_POST["comment"] = "qqq奥奥奥奥q";
    if(!isset($_POST["userId"]) || !isset($_POST["orderId"]) || !isset($_POST["comment"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $orderid = $_POST["orderId"];
    $comment = $_POST["comment"];
    if(empty($userid)||empty($orderid)||empty($comment)){
      $result = array(
          "result"=>"0",
          "info"  =>"参数为空"
        );
      echo json_encode($result);exit;
    }
    $o_map = array(
        "id"  => $orderid
      );
    $o_m = M("orderlist");
    $res = $o_m->where($o_map)->field("userid,orderstate,isdel,receive_order_id")->find();
    if($res===false){
      $result = array(
          "result"=>"3",
          "info"  =>"数据库操作失败"
        );
      echo json_encode($result);exit;
    }elseif($res){
      if($res["orderstate"] != 5 && $res["orderstate"] != 9 && $res["orderstate"] != 6 && $res["orderstate"] != 13){
        $result = array(
            "result"=>"9",
            "info"  =>"订单不为可评论状态"
          );
        echo json_encode($result);exit;
      }
      if($res["userid"]==$userid){
        // 是发单者  判断订单状态
        switch($res["orderstate"]){
          case 5:
              $o_data["orderstate"] = 6;
            break;
          case 9:
              $o_data["orderstate"] = 13;
            break;
          default:
            break;
        }
        $o_m->startTrans();
        // 修改订单状态
        $o_res = $o_m->where($o_map)->save($o_data);
        if($o_res){
          $r_res = M("receiveOrder")->where(array("id"=>$res["receive_order_id"],"isdel"=>0))->
            save(array("comment"=>$comment,"assesstime"=>date("Y-m-d H:i:s",time())));
          if($r_res){
            $o_m->commit();
            // 添加到日志
            $log_date = array(
                "title" => "已评价",
                "msg"   => "发单人已评价",
                "userid"=> $userid,
                "orderid"=> $orderid,
                "orderstate"=>$o_data["orderstate"],
                "pay_status"=>1,
                "addtime"=>date("Y-m-d H:i:s",time())
              );
            $log_res = M("orderLog")->add($log_date);
            $result = array(
                "result"=>"1",
                "info"  =>"评论成功"
              );
            echo json_encode($result);exit;
          }else{
            $o_m->rollback();
            $result = array(
                "result"=>"5",
                "info"  =>"评论失败"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"4",
              "info"  =>"修改订单状态失败"
            );
          echo json_encode($result);exit;
        }
      }else{  
        // 不是发单者
        $r_o_m = M("receiveOrder");
        $r_res = $r_o_m->where(array("id"=>$res["receive_order_id"],"isdel"=>0))->field("userid,status,orderid")->find();
        if($r_res){
          if($r_res["userid"]==$userid && $r_res["orderid"]==$orderid && $r_res["status"]==0){
            // 验证接单人成功
            $o_m->startTrans();
            $o_res = $o_m->where($o_map)->save(array("comment"=>$comment,"assesstime"=>date("Y-m-d H:i:s",time())));
            if($o_m){
              // 评论成功
              $r_o_res = $r_o_m->where(array("id"=>$res["receive_order_id"],"isdel"=>0))->save(array("status"=>1));
              if($r_o_res){
                $o_m->commit();
                // 添加到日志
                $log_date = array(
                    "title" => "已评价",
                    "msg"   => "id{$userid}的接单人已评价",
                    "userid"=> $userid,
                    "orderid"=> $orderid,
                    "orderstate"=> 14,
                    "pay_status"=> 1,
                    "addtime"=>date("Y-m-d H:i:s",time())
                  );
                $log_res = M("orderLog")->add($log_date);
                $result = array(
                    "result"=>"1",
                    "info"  =>"评论成功"
                  );
                echo json_encode($result);exit;
              }else{
                $o_m->rollback();
                $result = array(
                    "result"=>"10",
                    "info"  =>"评论失败"
                  );
                echo json_encode($result);exit;
              }
            }else{
              $result = array(
                  "result"=>"8",
                  "info"  =>"评论失败"
                );
              echo json_encode($result);exit;
            }
          }else{
            $result = array(
                "result"=>"7",
                "info"  =>"非法操作"
              );
            echo json_encode($result);exit;
          }
        }else{
          $result = array(
              "result"=>"6",
              "info"  =>"查找接单数据失败"
            );
          echo json_encode($result);exit;
        }
      }
    }else{
      $result = array(
          "result"=>"2",
          "info"  =>"没有数据"
        );
      echo json_encode($result);exit;
    }
  }


  // 明星企业接口
  /*
    返回参数 result=>1  操作成功
    返回参数 result=>2  数据库无数据
  */
  public function star_company_list(){
    # 公司招聘
    $company=D("Company")->where("recruitment_nums>0 and isdel=0 and company_type = 1")->select();
    if ($company) {
      # 构建公司招聘数组
      foreach($company as $c){
        # 公司类别
        $companyClass=D("Company_class")->where(array("id"=>$c['type'],"isdel"=>0))->find();
        switch ($c['list']) {
          case '0':
            $listed="未上市";
            break;
          case '1':
            $listed="已上市";
            break;
          default:
            # code...
            break;
        }
        # 招聘职务
        $recruitment=D("Recruitment")->where(array("company_id"=>$c['id'],"isdel"=>0,"status"=>1))->find();
        $oneCellArr[]=array(
          "logoImg"=>IMG_URL.$c['logo_img'],
          "infoImg"=>IMG_URL.$c['pic'],
          "ompanyName"=>$c['company_name'],
          "introduce"=>$companyClass['classname']."|".$listed."|".$c['people'],
          "position"=>$recruitment['position'],
          "positionID"=>$recruitment['position_id'],
          );
      }
      if($oneCellArr){
        $result = array(
            "result" => "1",
            "info"   => $oneCellArr
          );
        $result = $this->remove_null($result);
        echo json_encode($result);exit;
      }else{
        $result = array(
            "result" => "2",
            "info"   => "暂无数据"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "2",
          "info"   => "暂无数据"
        );
        echo json_encode($result);exit;
    }
  }

  /* 一下的接口是上线后的接口 */

  // 记录设备jpush所需id的接口
  /*
    $_POST["userId"]          登录者的id
    $_POST["token"]           设备专属id
    返回参数 result=>0   缺少参数
    返回参数 result=>1   操作成功
    返回参数 result=>2   参数为空
    返回参数 result=>3   保存token失败
  */
  public function set_jpush_token(){
    // $_POST["userId"] = 84;
    // $_POST["token"]  = "13165ffa4e00bc3b419";
    if(!isset($_POST["userId"]) || !isset($_POST["token"])){
      $result = array(
          "result"=>"0",
          "info"  =>"缺少参数"
        );
      echo json_encode($result);exit;
    }
    $userid = $_POST["userId"];
    $token  = $_POST["token"];
    if(!$userid || !$token){
      $result = array(
          "result"=>"2",
          "info"  =>"参数为空"
        );
      echo json_encode($result);exit;
    }
    $res = M("member")->where(array("id"=>$userid))->setField(array("jPushToken"=>$token));
    if($res!==false){
      $result = array(
          "result"=>"1",
          "info"  =>"操作成功"
        );
      echo json_encode($result);exit;
    }else{
      $result = array(
          "result"=>"3",
          "info"  =>"保存token失败"
        );
      echo json_encode($result);exit;
    }
  }


  // 好友模块

  // 支付宝支付接口
  /*
    $_POST["orderId"]     传来订单的id
    $_POST["userId"]      传来用户id
    返回参数 result=>0   缺少参数
    返回参数 result=>1   操作成功
    返回参数 result=>2   此订单不符合支付条件
  */
  public function alipay_api(){
    $orderid = I("post.orderId");
    $userid  = I("post.userId");
    // $orderid = 160;
    // $userid  = 3;
    if(empty($orderid)||empty($userid)){
      $result["result"] = 0;
      $result["info"]   = "缺少必要参数";
      $this->ajaxReturn($result);
    }
    $map["id"]         = $orderid;
    $map["userid"]     = $userid;
    $map["orderstate"] = 0;     // 为没人接单的状态
    $map["status"]     = 0;     // 为未支付状态
    $map["isdel"]      = 0;     // 为未删除状态
    $res_o = M("orderlist")->where($map)->find();

    if(!$res_o){
      $result["result"] = 2;
      $result["info"]   = "此订单不符合支付条件";
      $this->ajaxReturn($result);
    }
    vendor("Alipay.alipay_rsa");
    vendor("Alipay.alipay_core");
    $alipay_config = $this->alipay_config();



    //商户订单号，商户网站订单系统中唯一订单号，必填
    $out_trade_no = $res_o["order_no"];

    //订单名称，必填
    $subject      = "活来了支付宝支付";

    //付款金额，必填
    $total_fee    = $res_o["prepay"];

    //商品描述，可空
    $body         = $res_o["title"];

    //构造要请求的参数数组，无需改动
    $parameter = array(
        "service"       => $alipay_config['service'],
        "partner"       => $alipay_config['partner'],
        "seller_id"  => $alipay_config['seller_id'],
        "payment_type"  => $alipay_config['payment_type'],
        "notify_url"  => "http://{$_SERVER["SERVER_NAME"]}/admin/interface/alipay_notify_url",
        // "return_url"  => $alipay_config['return_url'],
        
        "anti_phishing_key"=>$alipay_config['anti_phishing_key'],
        "exter_invoke_ip"=>$alipay_config['exter_invoke_ip'],
        "out_trade_no"  => $out_trade_no,
        "subject" => $subject,
        "total_fee" => $total_fee,
        "body"  => $body,
        "_input_charset"  => trim(strtolower($alipay_config['input_charset']))
        //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.kiX33I&treeId=62&articleId=103740&docType=1
            //如"参数名"=>"参数值"
    );
    //① 除去待签名参数数组中的空值和签名参数,排序
    $para_sort = paraFilter($parameter);

    $para_sort=argSort($para_sort);
  
    // ② 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
    $data=\createLinkstring1($para_sort);
    //③ 生成签名结果
    $sign=rsaSign($data,$alipay_config['private_key']);

    $sign=urlencode($sign);
    
    //④签名结果与签名方式加入请求提交参数组中
    $para_sort['sign'] = $sign;
    $para_sort['sign_type'] =trim($alipay_config['sign_type']);


    $result["result"] = 1;
    $result["info"]   = $para_sort;
    $this->ajaxReturn($result);
  }

  // 补差价alipay
  /*
    $out_trade_no         订单编号
    $total_fee            支付价格
    $param                传递的参数
    $body                 订单描述
  */
  protected function alipay_diff_api($out_trade_no,$total_fee,$param,$body=""){
    vendor("Alipay.alipay_rsa");
    vendor("Alipay.alipay_core");
    $alipay_config = $this->alipay_config();
    //订单名称，必填
    $subject      = "活来了差价支付";
    //构造要请求的参数数组，无需改动
    $parameter = array(
        "service"       => $alipay_config['service'],
        "partner"       => $alipay_config['partner'],
        "seller_id"  => $alipay_config['seller_id'],
        "payment_type"  => $alipay_config['payment_type'],
        "notify_url"  => "http://{$_SERVER["SERVER_NAME"]}/admin/interface/alipay_diffpay_notify_url/receiveid/{$param[receiveid]}/charge/{$param[charge]}/dif/{$param[dif]}",
        // "return_url"  => $alipay_config['return_url'],
        
        "anti_phishing_key"=>$alipay_config['anti_phishing_key'],
        "exter_invoke_ip"=>$alipay_config['exter_invoke_ip'],
        "out_trade_no"  => $out_trade_no,
        "subject" => $subject,
        "total_fee" => $total_fee,
        "body"  => $body,
        "_input_charset"  => trim(strtolower($alipay_config['input_charset']))
        //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.kiX33I&treeId=62&articleId=103740&docType=1
            //如"参数名"=>"参数值"
    );
    //① 除去待签名参数数组中的空值和签名参数,排序
    $para_sort = paraFilter($parameter);

    $para_sort=argSort($para_sort);
  
    // ② 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
    $data=\createLinkstring1($para_sort);
    //③ 生成签名结果
    $sign=rsaSign($data,$alipay_config['private_key']);

    $sign=urlencode($sign);
    
    //④签名结果与签名方式加入请求提交参数组中
    $para_sort['sign'] = $sign;
    $para_sort['sign_type'] =trim($alipay_config['sign_type']);


    $result["result"] = 1;
    $result["info"]   = $para_sort;
    $this->ajaxReturn($result);
  }


  // 支付宝支付异步回调接口
  public function alipay_notify_url(){
    $alipay_config = $this->alipay_config();
    vendor("Alipay.alipay_rsa");
    vendor("Alipay.alipay_notify");
    vendor("Alipay.alipay_core");
    $alipayNotify = new \AlipayNotify($alipay_config);
    $verify_result = $alipayNotify->verifyNotify();
    if($verify_result) {//验证成功
      //商户订单号
      $out_trade_no = $_POST['out_trade_no'];
      //支付宝交易号
      $trade_no = $_POST['trade_no'];
      //交易状态
      $trade_status = $_POST['trade_status'];
      if($_POST['trade_status'] == 'TRADE_FINISHED') {
        //查找订单
        $map = array(
              "order_no"   => $out_trade_no
            );
        $m = M("orderlist");
        $order = $m->where($map)->field("status,orderstate,prepay")->find();
        // 判断订单支付状态
        if($order){
          if($order["status"] != 0){
            $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：改订单已支付过";
          }else{
            $data = array(
                "status" => 1,
                "pay_type" => 1,
                "orderstate" => 0,
                "real_pay"   => $order["prepay"],
                "pay_time" =>date("Y-m-d H:i:s",time())
              );
            $res = $m->where($map)->save($data);
            if($res){
              $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED";
            }else{
              $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：修改订单状态失败";
            }
          }
          //调试用，写文本函数记录程序运行情况是否正常
        }else{
          $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：改订单不存在";
        }
      }else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
        //查找订单
        $map = array(
              "order_no"     => $out_trade_no
            );
        $m = M("orderlist");
        $order = $m->where($map)->field("status,orderstate,prepay")->find();
        // 判断订单支付状态
        if($order){
          if($order["status"] != 0){
            $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS，交易异常：改订单已支付过";
          }else{
            $data = array(
                "status" => 1,
                "pay_type" => 1,
                "orderstate" => 0,
                "real_pay"   => $order["prepay"],
                "pay_time" =>date("Y-m-d H:i:s",time())
              );
            $res = $m->where($map)->save($data);
            if($res){
              $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS";
            }else{
              $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS，交易异常：修改订单状态失败";
            }
          }
          //调试用，写文本函数记录程序运行情况是否正常
        }else{
          $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS，交易异常：改订单不存在";
        }
      }
      $this->logResult($text);
      echo "success";   //请不要修改或删除
    }else {
      //验证失败
      echo "fail";
      //调试用，写文本函数记录程序运行情况是否正常
      $this->logResult("支付宝交易失败，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}");
    }
  }

  // 支付宝差价支付异步回调接口
  public function alipay_diffpay_notify_url(){
    $alipay_config = $this->alipay_config();
    vendor("Alipay.alipay_rsa");
    vendor("Alipay.alipay_core");
    vendor("Alipay.alipay_notify");
    $alipayNotify = new \AlipayNotify($alipay_config);
    $verify_result = $alipayNotify->verifyNotify();
    if($verify_result) {//验证成功
      //商户订单号
      $out_trade_no = $_POST['out_trade_no'];
      //支付宝交易号
      $trade_no = $_POST['trade_no'];
      //交易状态
      $trade_status = $_POST['trade_status'];
      if($_POST['trade_status'] == 'TRADE_FINISHED') {
        //查找订单
        $map = array(
              "order_no"   => substr($out_trade_no,3),
              "orderstate" => 1,
            );
        $m = M("orderlist");
        $order = $m->where($map)->field("real_pay")->find();
        // 判断订单支付状态
        if($order){
          $receiveid = $_GET["receiveid"];
          $charge = $_GET["charge"];
          $dif = $_GET["dif"];
          $data = array(
              "status"            => 1,
              "orderstate"        => 2,
              "receive_order_id"  => $receiveid,
              "pay_msg"           => 2,
              "remuneration"      => $charge,
              "diff_money"        => $dif,
              "diff_pay_type"     => 1,     // 表示余额支付
              "real_pay"          => $order["real_pay"] + $dif,
              "pay_diff_time"     => date("Y-m-d H:i:s",time())
            );
          $res = $m->where($map)->save($data);
          if($res){
            $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED";
          }else{
            $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：修改订单失败";
          }
        }else{
          $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：没有这个订单";
        }
        $this->logResult($text,"alipay_diffpay_notify.txt");
      }else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
        //查找订单
        $map = array(
              "order_no"   => substr($out_trade_no,3),
              "orderstate" => 1,
            );
        $m = M("orderlist");
        $order = $m->where($map)->field("real_pay")->find();
        // 判断订单支付状态
        if($order){
          $receiveid = $_GET["receiveid"];
          $charge = $_GET["charge"];
          $dif = $_GET["dif"];
          $data = array(
              "status"            => 1,
              "orderstate"        => 2,
              "receive_order_id"  => $receiveid,
              "pay_msg"           => 2,
              "remuneration"      => $charge,
              "diff_money"        => $dif,
              "diff_pay_type"     => 1,     // 表示余额支付
              "real_pay"          => $order["real_pay"] + $dif,
              "pay_diff_time"     => date("Y-m-d H:i:s",time())
            );
          $res = $m->where($map)->save($data);
          if($res){
            $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS";
          }else{
            $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS，交易异常：修改订单失败";
          }
        }else{
          $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_SUCCESS，交易异常：没有这个订单";
        }
        $this->logResult($text,"alipay_diffpay_notify.txt");
      }
      echo "success";   //请不要修改或删除
    }else {
      //验证失败
      echo "fail";
      //调试用，写文本函数记录程序运行情况是否正常
      $this->logResult("支付宝补差价交易失败，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}","alipay_diffpay_notify.txt");
    }
  }



  // 微信支付
  /*
    微信统一下单
    url：https://api.mch.weixin.qq.com/pay/unifiedorder
    $_POST["orderId"]     传来订单的id
    $_POST["userId"]      传来用户id
    返回参数 result=>0   缺少参数
    返回参数 result=>1   操作成功
    返回参数 result=>2   此订单不符合支付条件
  */
  public function Wxpay_api(){
    // echo md5("qunqiao2016");die;



    $orderid = I("post.orderId");
    $userid  = I("post.userId");
    // $orderid = 160;
    // $userid  = 3;
    if(empty($orderid)||empty($userid)){
      $result["result"] = 0;
      $result["info"]   = "缺少必要参数";
      $this->ajaxReturn($result);
    }
    $map["id"]         = $orderid;
    $map["userid"]     = $userid;
    $map["orderstate"] = 0;     // 为没人接单的状态
    $map["status"]     = 0;     // 为未支付状态
    $map["isdel"]      = 0;     // 为未删除状态
    $res_o = M("orderlist")->where($map)->find();
    if(!$res_o){
      $result["result"] = 2;
      $result["info"]   = "此订单不符合支付条件";
      exit(json_encode($result));
    }

    vendor("Wxpay.WxPayPubHelper.WxPay#Api");



    $input = new \WxPayUnifiedOrder();
    $input->SetBody($res_o["title"]);
    $input->SetOut_trade_no($res_o["order_no"]);
    $input->SetTotal_fee($res_o["prepay"]*100);
    $input->SetNotify_url("http://{$_SERVER["SERVER_NAME"]}/admin/interface/wxpay_notify_url");
    $input->SetTrade_type("APP");
      
    $order = \WxPayApi::unifiedOrder($input);
    $arr = new \WxPayGetOrde();
    $arr->SetPrepay_id($order['prepay_id']);
  
    $array = \WxPayApi::getOrder($arr);
    echo json_encode($array);
    exit();
    
  }


 /*
  微信补差价api
 */
  protected function wxpay_diff_api($out_trade_no,$total_fee,$param){


    vendor("Wxpay.WxPayPubHelper.WxPay#Api");


    $input = new \WxPayUnifiedOrder();
    $input->SetBody("微信订单补差价");
    $input->SetOut_trade_no($out_trade_no);
    $input->SetTotal_fee($total_fee*100);
    $input->SetNotify_url("http://{$_SERVER["SERVER_NAME"]}/admin/interface/wxpay_diffpay_notify_url/receiveid/{$param[receiveid]}/charge/{$param[charge]}/dif/{$param[dif]}");
    $input->SetTrade_type("APP");
      
    $order = \WxPayApi::unifiedOrder($input);
    $arr = new \WxPayGetOrde();
    $arr->SetPrepay_id($order['prepay_id']);
  
    $array = \WxPayApi::getOrder($arr);
    echo json_encode($array);
    exit();

  }


  // 微信支付异步回调接口
  public function wxpay_notify_url(){
    vendor('Wxpay.WxPayPubHelper.WxPayPubHelper');  
    vendor ('Wxpay.demo.log_');
    //使用通用通知接口
    $notify = new \Notify_pub();
    //存储微信的回调
    $xml = $GLOBALS['HTTP_RAW_POST_DATA'];  
    $notify->saveData($xml);
    $log_ = new \Log_();
    $log_name="./wxpay_notify_url.log";//log文件路径
    //验证签名，并回应微信。
    //对后台通知交互时，如果微信收到商户的应答不是成功或超时，微信认为通知失败，
    //微信会通过一定的策略（如30分钟共8次）定期重新发起通知，
    //尽可能提高通知的成功率，但微信不保证通知最终能成功。
    if($notify->checkSign() == FALSE){

        $notify->setReturnParameter("return_code","FAIL");//返回状态码

        $notify->setReturnParameter("return_msg","签名失败");//返回信息

    }else{

        $notify->setReturnParameter("return_code","SUCCESS");//设置返回码

    }

    $returnXml = $notify->returnXml();

    echo $returnXml;
    


    //==商户根据实际情况设置相应的处理流程，此处仅作举例=======
    //以log文件形式记录回调信息
    
    $log_->log_result($log_name,"【接收到的notify通知】:\n".$xml."\n");

    if($notify->checkSign() == TRUE){
        if ($notify->data["return_code"] == "FAIL") {
            //此处应该更新一下订单状态，商户自行增删操作
            //$log_->log_result($log_name,"【通信出错】:\n".$xml."\n");
        }
        elseif($notify->data["result_code"] == "FAIL"){
            //此处应该更新一下订单状态，商户自行增删操作
            //$log_->log_result($log_name,"【业务出错】:\n".$xml."\n");
        }else{

            //此处应该更新一下订单状态，商户自行增删操作
            $a=$notify->data["result_code"];
            if($a=='SUCCESS'){
                
                $out_trade_no = $notify->data["out_trade_no"];
                //查找订单
                $map = array(
                      "order_no"   => $out_trade_no
                    );
                $m = M("orderlist");
                $order = $m->where($map)->field("status,orderstate,prepay")->find();
                // 判断订单支付状态
                if($order){
                  if($order["status"] != 0){
                    $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：改订单已支付过";
                  }else{
                    $data = array(
                        "status" => 1,
                        "pay_type" => 1,
                        "orderstate" => 0,
                        "real_pay"   => $order["prepay"],
                        "pay_time" =>date("Y-m-d H:i:s",time())
                      );
                    $res = $m->where($map)->save($data);
                    if($res){
                      $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED";
                    }else{
                      $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：修改订单状态失败";
                    }
                  }
                  //调试用，写文本函数记录程序运行情况是否正常
                }else{
                  $text = "支付宝交易成功，订单号：{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：改订单不存在";
                }
            }
            $log_->log_result($log_name,$text);
        }
        //商户自行增加处理流程,
        //例如：更新订单状态
        //例如：数据库操作
        //例如：推送支付完成信息
    }
  }


  // 微信支付补差价异步回调接口
  public function wxpay_diffpay_notify_url(){
    vendor('Wxpay.WxPayPubHelper.WxPayPubHelper');  
    vendor ('Wxpay.demo.log_');
    //使用通用通知接口
    $notify = new \Notify_pub();
    //存储微信的回调
    $xml = $GLOBALS['HTTP_RAW_POST_DATA'];  
    $notify->saveData($xml);
    $log_ = new \Log_();
    $log_name="./wxpay_notify_url.log";//log文件路径
    //验证签名，并回应微信。
    //对后台通知交互时，如果微信收到商户的应答不是成功或超时，微信认为通知失败，
    //微信会通过一定的策略（如30分钟共8次）定期重新发起通知，
    //尽可能提高通知的成功率，但微信不保证通知最终能成功。
    if($notify->checkSign() == FALSE){

        $notify->setReturnParameter("return_code","FAIL");//返回状态码

        $notify->setReturnParameter("return_msg","签名失败");//返回信息

    }else{

        $notify->setReturnParameter("return_code","SUCCESS");//设置返回码

    }

    $returnXml = $notify->returnXml();

    echo $returnXml;
    


    //==商户根据实际情况设置相应的处理流程，此处仅作举例=======
    //以log文件形式记录回调信息
    
    $log_->log_result($log_name,"【接收到的notify通知】:\n".$xml."\n");

    if($notify->checkSign() == TRUE){
        if ($notify->data["return_code"] == "FAIL") {
            //此处应该更新一下订单状态，商户自行增删操作
            //$log_->log_result($log_name,"【通信出错】:\n".$xml."\n");
        }
        elseif($notify->data["result_code"] == "FAIL"){
            //此处应该更新一下订单状态，商户自行增删操作
            //$log_->log_result($log_name,"【业务出错】:\n".$xml."\n");
        }else{

            //此处应该更新一下订单状态，商户自行增删操作
            $a=$notify->data["result_code"];
            if($a=='SUCCESS'){
                
                $out_trade_no = $notify->data["out_trade_no"];
                $map = array(
                      "order_no"   => substr($out_trade_no,3),
                      "orderstate" => 1,
                    );
                $m = M("orderlist");
                $order = $m->where($map)->field("real_pay")->find();
                // 判断订单支付状态
                if($order){
                  $receiveid = $_GET["receiveid"];
                  $charge = $_GET["charge"];
                  $dif = $_GET["dif"];
                  $data = array(
                      "status"            => 1,
                      "orderstate"        => 2,
                      "receive_order_id"  => $receiveid,
                      "pay_msg"           => 2,
                      "remuneration"      => $charge,
                      "diff_money"        => $dif,
                      "diff_pay_type"     => 1,     // 表示余额支付
                      "real_pay"          => $order["real_pay"] + $dif,
                      "pay_diff_time"     => date("Y-m-d H:i:s",time())
                    );
                  $res = $m->where($map)->save($data);
                  if($res){
                    $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED";
                  }else{
                    $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：修改订单失败";
                  }
                }else{
                  $text = "支付宝补差价交易成功，订单号：BCJ{$out_trade_no}，支付宝交易号：{$trade_no}，trade_status：TRADE_FINISHED，交易异常：没有这个订单";
                }
            }
            $log_->log_result($log_name,$text);
        }
    }
  }

  // 返回h5页面
//   public function h5View(){
//     $str = "分 成 提 现 规 则
// 每单收入 = 业务费用*100%-0.5元+订单奖励*100%+附加费用*100%+其他费用*100
// 每笔进账会收取1.77%的公司管理费。此费用发用于支付公司的管理费
// 仅支持提现到储蓄卡。
// 注册姓名与提现银行卡姓名必须一致。
// 提现时间：每周二 9：00-22：00
// 可提收入 本周一00：00前所有收入
// 单日提现限额：15000元
// 到账时间：2小时内
// 提现次数：当日最多3次
// 订单奖励：100%";
//     $arr = explode("\n",$str);
//     $newstr = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
// <html xmlns="http://www.w3.org/1999/xhtml">
// <head>
//     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
// <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
// <meta name="renderer" content="webkit">   
// <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">   
// <meta name="format-detection" content="telephone=no" /> 
// <link rel="shortcut icon" href="images/dzlogo.ico" /> 
// <title>活来了</title>
// <meta name="keywords" content="活来了" />
// <meta name="description" content="活来了" /> ';
//     foreach($arr as $v){
//       $newstr .= "<section style='text-indent:2em;'>";
//       $newstr .= $v;
//       $newstr .= "</section>";
//     }
//     $newstr = str_replace("", "*", $newstr);
//     $newstr .= "</head>
//               </html>";
//     echo $newstr;
//     $this->display();
//   }
  public function reg_rule(){
    $this->display();
  }
  public function tixian_rule(){
    $this->display();
  }
  public function yinsi(){
    $this->display();
  }


  //业绩管理
  public function version_info(){
    # 获取最新的一条记录返回
    $id = I("version");
    $newData = array();
    $newData=D('Version')->find($id);
    if($newDate){
      $result = array(
                "result"  => "1",
                "info"  => $newData,
            );
    }else{
      $result = array(
                "result"  => "0",
                "info"  => "获取数据失败",
            );
    }
    echo json_encode($result);exit;
  }

  // 返回融云key
  public function getRongYun(){
    $data = array("rongyun_appKey"=>$this->rongyun_appKey);
    exit(json_encode($data));
  }

  // 版本更新
  /*
    $_POST["version"]     版本号
    {
    result: "1",
      info: {
      id: "3",
      version_code: "3",
      version_name: "1.3",
      android_link: "",
      ios_link: "",
      update_msg: null,
      isforce: 1,
      addtime: null
      }
    }
  */
  public function update_version(){
    $version = I("post.version");
    // $version = "1.1";
    if(empty($version)){
      $result = array(
              "result" => "0",
              "info" => "缺少参数",
        );
      exit(json_encode($result));
    }
    $m = M("version")->where(array("version_name"=>$version))->getField("version_code");
    $res = M("version")->where(array("version_code"=>array("gt",$version),"status"=>1))->order("version_code asc")->select();
    if($res){
      $is_update = "0";
      foreach($res as $k=>$v){
        if($v["isforce"] == 1){
          $is_update = "1";
          break;
        }
      }
      $info = array_pop($res);
      $info['isforce'] = $is_update;
      $result = array(
              "result" => "1",
              "info" => $info,
        );
      $result = $this->remove_null($result);
      exit(json_encode($result));
    }else{
      $result = array(
              "result" => "2",
              "info" => "此版本为最新版本，不需要更新",
        );
      exit(json_encode($result));
    }
  }

  /*
    新得好友请求列表,请求添加好友的数量
    $_POST["userId"]          登陆者id
    返回参数 result=>0   缺少参数，或错误的参数
    返回参数 result=>1   操作成功,info为返回的申请数量，前端自己判断
    返回参数 result=>2   查询数据库失败
  */
  public function apply_add_friend_nums(){
    $userid = I("post.userId");
    // $userid = 34;
    if(!($userid>0)){
      $result = array(
                "result" => "0",
                "info"   => "缺少参数，或错误的参数",
            );
      exit(json_encode($result));
    }
    $count = M("addFriendLog")->where(array("toid"=>$userid,"status"=>0,"isdel"=>0))->count();
    if($count === false){
      $result = array(
                "result" => "2",
                "info"   => "查询数据库失败",
            );
      exit(json_encode($result));
    }else{
      $result = array(
                "result" => "1",
                "info"   => "$count",
            );
      exit(json_encode($result));
    }
  }


  //  消息回复的列表
  /*
      $_POST["userId"]    登陆者的id
      返回参数 result=>0   缺少参数，或错误的参数
      返回参数 result=>1   comment1:别人对我的评论;comment2:我对别人的评论
      返回参数 result=>2   操作数据库失败
      返回参数 result=>3   操作数据库失败
  */
  public function get_comment_list(){
    $userid = I("post.userId");
    // $userid = 2;
    if(!($userid>0)){
      $result = array(
                "result" => "0",
                "info"   => "缺少参数，或者参数不正确",
            );
      exit(json_encode($result));
    }
    $data = array(
            // 别人对我的评论
            "comment1" => array(),
            // 我对别人的评论
            "comment2" => array(),
        );
    $DB_PREFIX = C("DB_PREFIX");
    $join_str1 = "inner join {$DB_PREFIX}receive_order as r on o.receive_order_id = r.id and r.status = 1";
    $join_str2 = "inner join {$DB_PREFIX}member as m on r.userid = m.id";
    $res1 = M("orderlist")->alias("o")->where(array("o.userid"=>$userid,"o.isdel"=>0))->
        join($join_str1)->join($join_str2)->
        // o.comment 对我的评价 
        field("o.id as orderid,o.comment,m.person_img,m.person_name,r.assesstime")->select();
    if($res1){
      foreach ($res1 as $k=>$v){
        $res1[$k]["assesstime"] = date("m-d H:i",strtotime($v["assesstime"]));
        $res1[$k]["person_img"] = $this->deal_img($v["person_img"]);
      }
      $data["comment1"] = $res1;
    }elseif($res1 === false){
      $result = array(
                "result" => "2",
                "info"   => "操作数据库失败",
            );
      exit(json_encode($result));
    }
    $join_str1 = "inner join {$DB_PREFIX}receive_order as r on o.receive_order_id = r.id";
    $join_str2 = "inner join {$DB_PREFIX}member as m on r.userid = m.id";
    $res1 = M("orderlist")->alias("o")->where(array("orderstate"=>6,"o.userid"=>$userid,"o.isdel"=>0))->
        join($join_str1)->join($join_str2)->
        // o.comment 对我的评价 
        field("o.id as orderid,r.comment,m.person_img,m.person_name,o.assesstime")->select();
    if($res1){
      foreach ($res1 as $k=>$v){
        $res1[$k]["assesstime"] = date("m-d H:i",strtotime($v["assesstime"]));
        $res1[$k]["person_img"] = $this->deal_img($v["person_img"]);
      }
      $data["comment2"] = $res1;
    }elseif($res1 === false){
      $result = array(
                "result" => "3",
                "info"   => "操作数据库失败",
            );
      exit(json_encode($result));
    }
    $result = array(
              "result" => "1",
              "info"   => $data,
            );
    exit(json_encode($result));
  }

  #######################################################################################################



  protected function logResult($word='',$fileName="alipay_notify.txt") {
      $fp = fopen($fileName,"a");
      flock($fp, LOCK_EX) ;
      fwrite($fp,"执行日期：".strftime("%Y%m%d%H%M%S",time())."
".$word."
");
      flock($fp, LOCK_UN);
      fclose($fp);
    }


  protected function wxpay_config(){
    $wxconfig["appid"]            = "wx114679c904bb3b39"; // 应用ID
    $wxconfig["mch_id"]           = "1399041702";         // 商户号
    $wxconfig["nonce_str"]        = "";         // 随机数
    $wxconfig["sign"]             = "";         // 签名
    $wxconfig["body"]             = "";         // 商品描述
    $wxconfig["out_trade_no"]     = "";         // 商户订单号
    $wxconfig["total_fee"]        = "";         // 支付金额
    $wxconfig["spbill_create_ip"] = "";         // 用户ip
    $wxconfig["notify_url"]       = "";         // 回调地址
    $wxconfig["trade_type"]       = "APP";         // 交易类型

    return $wxconfig;

  }


  // 支付宝配置信息
  protected function alipay_config(){
    //合作身份者ID
    $alipay_config['partner'] = "2088421945749456";
    //收款支付宝账号，以2088开头由16位纯数字组成的字符串，一般情况下收款账号就是签约账号
    $alipay_config['seller_id'] = $alipay_config['partner'];
    //商户的私钥
//     $alipay_config['private_key'] = 'MIICWwIBAAKBgQC8ZmyYTXMClBiB6xuahi1wVXDWl+aUOWVOSgut+W5OR8eTUteR
// sm6vbeb2NMQZklSb13AGPuBaSMJIMgFAvdnpWYYeGKLZh2kQ56HlQHPHyyaAE2xm
// LjvltTpfwZhzAFwAAYa6NSFTXsfrgoBM99LG+cf/FSp9XW+yFCZGrgBXTwIDAQAB
// AoGAYuhKvrJ6XLIvI5WwijFDDaRtdtuMW+i9/Jn3A8DdXg9lAT0OmxjX7xV9mWge
// Q2aFMMOrtjuwQPXNuWU3Lyv8iBNWpXxgLi1xVbwlAYzzWWtmx97Wj3Z6emR4RrTP
// /RrJ4jW6lEqhwCdKer7b3+/VlThWD/UDz9D/ojU1xJsJzoECQQD07KlNBN3CJun7
// BVz6ItnmvdiviZ3lFkReLF8UBMwIGPIHgPQC8EA56Ch5kTq8wRXNuGUjqjWGT1ol
// nbjWwWEhAkEAxOtqU4s22fYwpUA96fynmmN7DBlRx5PVV7CKWaCOBfH5jDlHEo3a
// TiZMUXW5fysww3O0WW6+le+sWJszlK36bwJAeJtRgyuyR7kB3yp07nfa9VTnLwmF
// Rxn/8J/I8gKqthISnL9TaV8FQX6g77wkQG6UXgk/RKC8WrcYnQ1dx+LSAQJAOrWB
// LsU7pkIbALmle+Rix8nO/q1xz1HI8mrk5JHUpfsdjmvpP6PhKRmL+WFi24Ix+KO/
// akZ1NdiOBqDHARXZqwJAf8tv8ti1yTXk+PJ/8RCNE0qSEELQhpyOjguVpkb1QA/0
// 3yIYf/kc2toBg2c2S+UT6PmsL+m9lcgaJo2HZc/BUg==';
/*    $alipay_config['private_key'] = 'MIICXQIBAAKBgQC5qlGvfPCdYduh5SU8EinVq1iM6BUIKscLXlfLZEHE4jIBRSne
sjq7WnDmgaJaX54iAu21NxoOXrBjQeKjlsBM9BGzfVPGS5f64qre8RncRq/JwSfH
qxoIIbc6wIiApxDMOQ8FK1y8q6zXpOv0DH2D5R0RkniKGe2dv0/5nFyAGQIDAQAB
AoGARQ0ZMEExY/cfLkkA3iSLNpJxboZqPA1c1deSo2x4IXdWza4hclerDD8IulIA
RchGEbQxIDKMGEgTJfc9CUZp4hJiLV3Rke2lJgIzY8MwlMQ5+dlaRv4l/77NY8wQ
A6rhhI21Q4n1vetawVrKXDfv+o601Buh2t9DwXnOTV58dPkCQQDpRubS1WCbexEn
X94oFN83KK7yZ6xPHYzMAnfMo8+CFKnhgKDnqWzUnoBpg5336LWWzaOEVFVbhURj
hBzmmOyHAkEAy8Am7cQeZt/vruJ/p8Nt5XdJUmolkFKg4pTTfXwK/6pyopIN+uFW
VyS5xqNk/dRoJYXpMADjwQF5lhx95tX2XwJAOt68w7o7niFJq/EipGTYDBiFRgFp
17FyZc29o/Q3GvHSCWmnsa7tGx9A8t/XTsf4g60zteJ+hBE2uBKQJJW1IwJBAIpq
jYe1Vhn5Q7EBOkvUHhJnSS5t4fr7x0Rmao6y+B3bw2jh5BFth+RHlNV3JyKxa9ch
89qioBb8U4dA798jt+0CQQDgLxHblXqbjqjQrbozX9JFRNRz4hYin8i+A6CzGaMu
vI0uUyux17ILwCjtMvm0xBNBWtcOjIKXPAYL+PeytLgP';*/

    $alipay_config['private_key'] = "MIICXQIBAAKBgQC5qlGvfPCdYduh5SU8EinVq1iM6BUIKscLXlfLZEHE4jIBRSne
sjq7WnDmgaJaX54iAu21NxoOXrBjQeKjlsBM9BGzfVPGS5f64qre8RncRq/JwSfH
qxoIIbc6wIiApxDMOQ8FK1y8q6zXpOv0DH2D5R0RkniKGe2dv0/5nFyAGQIDAQAB
AoGARQ0ZMEExY/cfLkkA3iSLNpJxboZqPA1c1deSo2x4IXdWza4hclerDD8IulIA
RchGEbQxIDKMGEgTJfc9CUZp4hJiLV3Rke2lJgIzY8MwlMQ5+dlaRv4l/77NY8wQ
A6rhhI21Q4n1vetawVrKXDfv+o601Buh2t9DwXnOTV58dPkCQQDpRubS1WCbexEn
X94oFN83KK7yZ6xPHYzMAnfMo8+CFKnhgKDnqWzUnoBpg5336LWWzaOEVFVbhURj
hBzmmOyHAkEAy8Am7cQeZt/vruJ/p8Nt5XdJUmolkFKg4pTTfXwK/6pyopIN+uFW
VyS5xqNk/dRoJYXpMADjwQF5lhx95tX2XwJAOt68w7o7niFJq/EipGTYDBiFRgFp
17FyZc29o/Q3GvHSCWmnsa7tGx9A8t/XTsf4g60zteJ+hBE2uBKQJJW1IwJBAIpq
jYe1Vhn5Q7EBOkvUHhJnSS5t4fr7x0Rmao6y+B3bw2jh5BFth+RHlNV3JyKxa9ch
89qioBb8U4dA798jt+0CQQDgLxHblXqbjqjQrbozX9JFRNRz4hYin8i+A6CzGaMu
vI0uUyux17ILwCjtMvm0xBNBWtcOjIKXPAYL+PeytLgP";

    //支付宝的公钥
    $alipay_config['alipay_public_key']= 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB';

    // 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    $alipay_config['notify_url'] = "http://{$_SERVER["SERVER_NAME"]}/admin/interface/alipay_notify_url";

    // 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    $alipay_config['return_url'] = "http://{$_SERVER["SERVER_NAME"]}/admin/interface/alipay_notify_url";

    //签名方式
    $alipay_config['sign_type']    = strtoupper('RSA');
    //字符编码格式 目前支持 gbk 或 utf-8
    $alipay_config['input_charset']= strtolower('utf-8');
    //ca证书路径地址，用于curl中ssl校验
    //请保证cacert.pem文件在当前文件夹目录中
    $alipay_config['cacert']    = getcwd().'\\cacert.pem';
    //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
    $alipay_config['transport']    = 'http';
    // 支付类型 ，无需修改
    $alipay_config['payment_type'] = "1";
    // 产品类型，无需修改
    $alipay_config['service'] = "mobile.securitypay.pay";
    //↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


    //↓↓↓↓↓↓↓↓↓↓ 请在这里配置防钓鱼信息，如果没开通防钓鱼功能，为空即可 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
      
    // 防钓鱼时间戳  若要使用请调用类文件submit中的query_timestamp函数
    $alipay_config['anti_phishing_key'] = "";
      
    // 客户端的IP地址 非局域网的外网IP地址，如：221.0.0.1
    $alipay_config['exter_invoke_ip'] = "";
        
    //↑↑↑↑↑↑↑↑↑↑请在这里配置防钓鱼信息，如果没开通防钓鱼功能，为空即可 ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
    return $alipay_config;
  }


  // jpush接口
  /*
    调用jpush推送消息
    $token    需要被推送消息的用户设备id
    $msg      需要被推送给用户的信息
  */
  public function jpush_msg($userid="",$msg="您有一条未读信息，请及时查看",$value=""){
  // public function jpush_msg($userid="98",$msg="哦"){
    if(!$userid){
      $result = array(
          "result" => "2",
          "info"   => "缺少用户id参数"
        );
      return $result;
    }
    $msg = $msg?$msg:"您有一条未读信息，请及时查看";
    $token = M("member")->where(array("id"=>$userid))->getField("jPushToken");
    if(!token){
      $result = array(
          "result" => "3",
          "info"   => "缺少token参数"
        );
      return $result;
    }
    include_once("./Jpush/examples/conf.php");
    $client = new JPush($this->jpush_appkey, $this->jpush_appsecret);
    $push = $client->push();
    // 表示要推送的设备
    $platform = "all";
    // 这里展示推送内容
    $alert = $msg;
    // $tag = array('tag1', 'tag2');
    // 这里设置要推送的设备token
    $regId = $token; 
    $ios_notification = array(
        //表示通知提示声音
        'sound' => '活来了', 
        // 表示应用角标，把角标数字改为指定的数字；
        // 为 0 表示清除，支持 '+1','-1' 这样的字符串，
        // 表示在原有的 badge 基础上进行增减，默认填充为 '+1'
        'badge' => "+1",
        // 表示推送唤醒，仅接受 true 表示为 Background Remote Notification
        // 若不填默认表示普通的 Remote Notification
        'content-available' => "true",
        // 'category' => 'jiguang',
        'extras' => array(
            'key' => $value,
        ),
    );
    $android_notification = array(
        //  表示通知标题，会替换通知里原来展示 App 名称的地方
        'title' => '活来了',
        // 表示通知栏样式ID
        'build_id' => 1,
        'extras' => array(
            'key' => $value,
        ),
    );
    // 这个是软件开启时的推送
    $content = $msg;
    $message = array(
        'title' => '活来了',
        'content_type' => 'text',
        'extras' => array(
            'key' => $value,
        ),
    );
    $options = array(
        // 'sendno' => 100,
        // 表示离线消息保留时长(秒)
        // 'time_to_live' => 100,
        // 表示要覆盖的消息ID
        // 'override_msg_id' => 100,
        // 表示APNs是否生产环境，True 表示推送生产环境，False 表示要推送开发环境
        'apns_production' => True,
        // 表示定速推送时长(分钟)
        // 'big_push_duration' => 20
    );
    try{
      $response = $push->setPlatform($platform)
          // ->addTag($tag)  // 推送给特定标签的用户群体
          // ->addRegistrationId()  // 这里是用户设备的id，由前段提供
          ->addRegistrationId($regId)  // 这里是用户设备的id，由前段提供
          ->iosNotification($alert, $ios_notification)
          ->androidNotification($alert, $android_notification)
          // ->setNotificationAlert($alert)
          ->message($content, $message)
          // ->options($options)
          ->send();
      // 测试发送成功返回数据
      // dump($response);
      return "发送成功";
    } catch (\JPush\Exceptions\APIConnectionException $e) {
      // try something here
      $result = array(
          "result"  => 1,
          "info"    => $e->__toString()
        );
      // dump($result);
      return $result;
    } catch (\JPush\Exceptions\APIRequestException $e) {
      // try something here
      $result = array(
          "result"  => 2,
          "info"    => $e->__toString()
        );
      // dump($result);
      return $result;
    }
  }
  // jpush接口
  /*
    检测用户是否更换手机后登陆
    调用jpush推送message消息
    $token    需要被推送消息的用户设备id
    $msg      需要被推送给用户的信息
    @ return true 为是本机登录  false 为更换设备后登陆
  */
  protected function check_if_change_phone($userid="",$token="",$msg="您的账号被异地登录，您已被迫下线"){
    // $userid = 84;
    // $token = "13165ffa4e00bc3b418";
    if(!$userid || !$token){
      $result = array(
          "result" => "2",
          "info"   => "缺少用户id参数，或token"
        );
      echo json_encode($result);exit;
    }
    $msg = $msg?$msg:"您的账号被异地登录，您已被迫下线";
    $oldtoken = M("member")->where(array("id"=>$userid))->getField("jPushToken");
    if(!$oldtoken){
      return ;
    }

    if($oldtoken == $token){
      // echo "true";
      return true;
    }

    include_once("./Jpush/examples/conf.php");
    $client = new JPush($this->jpush_appkey, $this->jpush_appsecret);
    $push = $client->push();
    // 表示要推送的设备
    $platform = "all";
    // 这里展示推送内容
    $alert = $msg;
    // 这里设置要推送的设备token
    $regId = $oldtoken;
    $value = '15';
    $ios_notification = array(
        //表示通知提示声音
        'sound' => '活来了', 
        // 表示应用角标，把角标数字改为指定的数字；
        // 为 0 表示清除，支持 '+1','-1' 这样的字符串，
        // 表示在原有的 badge 基础上进行增减，默认填充为 '+1'
        'badge' => "+1",
        // 表示推送唤醒，仅接受 true 表示为 Background Remote Notification
        // 若不填默认表示普通的 Remote Notification
        'content-available' => "true",
        // 'category' => 'jiguang',
        'extras' => array(
            'key' => $value,
        ),
    );
    $android_notification = array(
        //  表示通知标题，会替换通知里原来展示 App 名称的地方
        'title' => '活来了',
        // 表示通知栏样式ID
        'build_id' => 1,
        'extras' => array(
            'key' => $value,
        ),
    );
    $options = array(
        // 表示APNs是否生产环境，True 表示推送生产环境，False 表示要推送开发环境
        'apns_production' => True,
    );
    // 这个是软件开启时的推送
    $content = $msg;
    $message = array(
        'title' => '活来了',
        'content_type' => 'text',
        'extras' => array(
            'key' => $value,
        ),
    );
    try{
      $response = $push->setPlatform($platform)
          ->addRegistrationId($regId)  // 这里是用户设备的id，由前段提供
          ->iosNotification($alert, $ios_notification)
          ->androidNotification($alert, $android_notification)
          ->message($content, $message)
          // ->options($options)
          ->send();
      // 测试发送成功返回数据
      // 表示更换手机登录
      // echo "true";
      return false;
    } catch (\JPush\Exceptions\APIConnectionException $e) {
      // try something here
      $result = array(
          "result"  => "2",
          "info"    => $e->__toString()
        );
      echo json_encode($result);exit;
    } catch (\JPush\Exceptions\APIRequestException $e) {
      // try something here
      $result = array(
          "result"  => "2",
          "info"    => $e->__toString()
        );
      echo json_encode($result);exit;
    }
  }





  // 判断是否为好友
  /*
    $userid1、$userid2为不同的用户id，用来判断用户是否已经是好友
  */
  public function is_friend($userid1="",$userid2=""){
    $ispost = false;
    if(!$userid1 || !$userid2){
      $userid1 = I("post.userid1");
      $userid2 = I("post.userid2");
      if(!($userid1>0) || !($userid2>0)){
        $result = array(
                  "result"  => "0",
                  "info"    => "缺少必要参数",
              );
        exit(json_encode($result));
      }
      $ispost = true;
    }
    $m = M("memberFriend");
    $result1 = $m->where(array("userid1"=>$userid1,"userid2"=>$userid2,"isdel"=>0))->find();
    $result2 = $m->where(array("userid2"=>$userid1,"userid1"=>$userid2,"isdel"=>0))->find();
    if($result1 || $result2){
      if($ispost){
        $result = array(
                  "result"  => "1",
                  "info"    => "1",
              );
        exit(json_encode($result));
      }
      return "1";
    }else{
      if($ispost){
        $result = array(
                  "result"  => "1",
                  "info"    => "0",
              );
        exit(json_encode($result));
      }
      return "0";
    }
  }



  /*
    功能：处理订单改变订单状态，并记录日志
    $orderid    =>订单id   
    $userid     =>操作者id  
    $orderstate =>状态变化后的值   
    $msg        =>订单日志里的信息
  */
  protected function do_disagree($orderid,$userid,$orderstate,$msg){
    $o_m = M("orderlist");
    $o_data = array(
        "id"         =>$orderid,
        "orderstate" =>$orderstate
      );
    $o_m->startTrans();
    $o_res = $o_m->save($o_data);
    if($o_res){
      // 保存日志
      $log_data = array(
          "title"      => "拒绝取消",
          "orderid"    => $orderid,
          "userid"     => $userid,
          "orderstate" => $orderstate,
          "msg"        => $msg,
          "addtime"    => date("Y-m-d H:i:s",time())
        );
      $log_res = M("orderLog")->add($log_data);
      if($log_res){
        $o_m->commit();
        $result = array(
            "result" => "1",
            "info"   => "操作成功"
          );
        echo json_encode($result);exit;
      }else{
        $o_m->rollback();
        $result = array(
            "result" => "7",
            "info"   => "申请失败"
          );
        echo json_encode($result);exit;
      }
    }else{
      $result = array(
          "result" => "6",
          "info"   => "申请失败"
        );
      echo json_encode($result);exit;
    }
  }




  // 私有的退款方法  退酬金  酬金肯定是退到发单者手里的
  /*
    $map=>是用来查找orderlist（任务）的条件
    $data=>是用来改变orderlist的内容的参数
    $userid=>是操作这个接口的用户id
  */
  protected function refund($map,$data,$userid,$type="0"){
    $o_m = M("orderlist");
    // 获得酬金,用户id
    $order = $o_m->where($map)->field("id,userid,remuneration,orderstate")->find();
    if(!$order){
      $result = array(
          "result" => "2",
          "info"   => "获取订单数据失败"
        );
      echo json_encode($result);exit;
    }else{
      // 改变订单状态
      $o_m->startTrans();
      $data["refund_fee"] = $order["remuneration"];
      $o_res = $o_m->where($map)->save($data);
      if($o_res === false){
        $result = array(
            "result" => "2",
            "info"   => "改变订单状态失败"
          );
        echo json_encode($result);exit;
      }else{
        // 退款
        $m_res = M("member")->where(array("id"=>$order["userid"],"isdel"=>0,"status"=>0))->setInc("wallet",$order["remuneration"]);
        if($m_res===false){
          $o_m->rollback();
          $result = array(
              "result" => "2",
              "info"   => "退款失败"
            );
          echo json_encode($result);exit;
        }else{
          // 记录日志
          $o_m->commit();
          switch($data["orderstate"]){
            case 13:
              if($order["orderstate"] == 0 || $order["orderstate"] == 1){
                $log_data = array(
                    "title"      => "取消成功",
                    "orderid"    => $order["id"],
                    "orderstate" => $data["orderstate"],
                    "userid"     => $userid,
                    "msg"        => "在同意别人接单前，用户取消任务",
                    "pay_status" => 3,   // 退还酬金
                    "addtime"    => date("Y-m-d H:i:s",time())
                  );
              }else{
                $result = array(
                    "result" => "2"
                  );
                echo json_encode($result);exit;
              }
              break;
            case 9:
              if($order["orderstate"] == 8 || $order["orderstate"] == 7){
                $log_data = array(
                    "title"      => "同意取消",
                    "orderid"    => $order["id"],
                    "orderstate" => $data["orderstate"],
                    "userid"     => $userid,
                    "msg"        => "在同意别人接单后，用户请求取消任务成功",
                    "pay_status" => 3,   // 退还酬金
                    "addtime"    => date("Y-m-d H:i:s",time())
                  );
              }else{
                $result = array(
                    "result" => "2"
                  );
                echo json_encode($result);exit;
              }
              break;
          }
          $log_res = M("orderLog")->add($log_data);
          if($log_res === false){
            $result = array(
                "result" => "1",
                "info"   => "退款成功，记录日志失败"
              );
            if($type){
              return ;
            }
            echo json_encode($result);exit;
          }else{
            $result = array(
                "result" => "1",
                "info"   => "退款成功"
              );
            if($type){
              return ;
            }
            echo json_encode($result);exit;
          }
        }
      }
    }
  }



  /*
    ios 去null操作
  */
  protected function remove_null($res){
    if(is_array($res)){
      foreach($res as $k=>$v){
        if(is_array($v)){
          $res[$k] = $this->remove_null($v);
        }else{
          if(is_null($v)){
            $res[$k] = "";
          }
        }
      }
    }
    return $res;
  }

  // 获取融云token的方法
  protected function rongyun_token($userid,$name,$img){
    $appKey = $this->rongyun_appKey;
    $appSecret = $this->rongyun_appSecret;
    $RongCloud = new \Org\Rongyun\Rongcloud($appKey,$appSecret);
    if (empty($userid)||empty($name)||empty($img)){
      return false;
    }
    $result = $RongCloud->user()->getToken($userid, $name, $img);
    $res = json_decode($result);
    if($res->code == 200){
      return $result;
    }else{
      return false;exit;
    }
  }

  // 更新获取融云token
  private function update_rongyun_token(){
    set_time_limit(0);
    $m   = M("member");
    $res = $m->select();
    foreach($res as $v){
      $res = $this->rongyun_token($v["id"],$v["person_name"],$this->deal_img($v["person_img"]));
      $res = json_decode($res,true);
      $token = $res["token"];
      echo "获取融云token：$token";
      $res = $m->where(array("id"=>$v["id"]))->save(array("chat_id"=>$token));
      if($res){
        echo "用户id ".$v["id"]." 保存token成功";
      }else{
        echo "用户id ".$v["id"]." 保存token失败";
      }
    }
  }


  protected function deal_img($img){
    $newimg = $img?trim($img,"."):'Public/Admin/Upload_pic/header.png';
    return IMG_URL.$newimg;
  }

  /* 
  * 时间间隔 
  */
  public function time_tran($the_time) {
    $now_time = date("Y-m-d H:i:s", time());
    $now_time = strtotime($now_time);
    $show_time = strtotime($the_time);
    //$show_time=$the_time;
    $dur = $now_time - $show_time;
    if ($dur < 0) {
      return $the_time;
    } else {
      if ($dur < 60) {
        return $dur . '秒前';
      } else {
        if ($dur < 3600) {
          return floor($dur / 60) . '分钟前';
        } else {
          if ($dur < 86400) {
            return floor($dur / 3600) . '小时前';
          } else {
            if ($dur < 259200) {//3天内
              return floor($dur / 86400) . '天前';
            } else {
              return $the_time;
            }
          }
        }
      }
    }
  }

  /**
  * 发起一个post请求到指定接口
  * 
  * @param string $api 请求的接口
  * @param array $params post参数
  * @param int $timeout 超时时间
  * @return string 请求结果
  */
  function postRequest( $api, array $params = array(), $timeout = 30 ) {
    $ch = curl_init();
    curl_setopt( $ch, CURLOPT_URL, $api );
    // 以返回的形式接收信息
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    // 设置为POST方式
    curl_setopt( $ch, CURLOPT_POST, 1 );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query( $params ) );
    // 不验证https证书
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
    curl_setopt( $ch, CURLOPT_TIMEOUT, $timeout );
    curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-www-form-urlencoded;charset=UTF-8',
      'Accept: application/json',
    ) ); 
    // 发送数据
    $response = curl_exec( $ch );
    // 不要忘记释放资源
    curl_close( $ch );
    return $response;
  }
  // 获取ip
  function getIP(){
    global $ip;

    if (getenv("HTTP_CLIENT_IP"))
    $ip = getenv("HTTP_CLIENT_IP");
    else if(getenv("HTTP_X_FORWARDED_FOR"))
    $ip = getenv("HTTP_X_FORWARDED_FOR");
    else if(getenv("REMOTE_ADDR"))
    $ip = getenv("REMOTE_ADDR");
    else
    $ip = "Unknow";
    return $ip;
  } 



  #######################################################################################################

  /*----------------------------------------------------End--------------------------------*/

  // public function add(){
  //   $str = file_get_contents("aaa.txt");
  //   $arr = explode("|", $str);
  //   $m = M("sensitive_words");
  //   foreach($arr as $v){
  //     $res = $m->add(array("word"=>$v));
  //     if($res){
  //       echo "添加 $v <span style='color:green'>成功</span>";
  //     }else{
  //       echo "添加 $v <span style='color:red'>失败</span>";
  //     }
  //   }
  // }

  // public function test(){
  //   $str = "我草你妈";

  //   $words = M("sensitive_words")->where(array("status"=>1))->select();

  //   foreach($words as $v){
  //     $str = str_replace($v["word"], "*", $str);
  //   }
  //   echo $str;
  // }

}