<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class WebController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $news = M('news')->order('list desc')->field('id,title')->select();
        $this->assign('news',$news);
        $this->assign("munetype",11);
    }

    /* // 公司列表
    public function index(){
         $M = M('home_content');
        $info = $M->select();

        $this->assign("info",$info);
        $this->assign("comptype",'0');
        $this->display();
    
  
    } */
    //招聘审核

    public function changeStatus(){
        if(IS_POST){
            $id = intval(I('id'));
            $where['id'] = $id;
            $m = D("news");
            $data["status"] = 1;
            $res = $m->where($where)->save($data);
            if($res){
                $arrys = array('status'=>1);
            }else{
                $arrys = array('status'=>0);
            }

            echo json_encode($arrys);exit;
        }


    }



    public function edit(){
        $id = intval(I('get.id'));
        $M = M('home_content');
        $cache = $M->find($id);
        $det=str_ireplace('\"','"',htmlspecialchars_decode($cache['content']));

        if(IS_POST){
            $oid = intval(I('post.id'));
            $data['title'] = I('post.title');
            $data['list'] = I('post.list');
            $data['is_tui'] = I('post.is_tui');
            $data['content'] = I('post.content');
            $img = I('post.pic');
            $oldimg = I('post.spic');
            if($img!=$oldimg&&$img!=""){
                $data['pic'] = $img;
            }

            $rs=$M->where('id='.$oid)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Web/index'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }

        $this->assign("cache",$cache);
        $this->assign("comptype",'0');
        $this->display();

    }


    public function alldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('news')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }



     public function gonggaoalldel(){

        if(IS_POST){
            $id = intval(I('post.id'));
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('gonggao')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }



    
    //上传附件文档
    public function uploaddoc(){
        $m = M("news");
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('docx', 'doc');// 设置附件上传类型
        $upload->savePath =  '../Uploads/upfiles/';// 设置附件上传目录
        $res = $upload->upload();
        if(!res) {// 上传错误提示错误信息
            echo '上传失败';
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
    
            $path = $res['file']['savepath'].$res['file']['savename'];
    
            $data['fujian'] = $path;
            $result = $m->add($data);
            echo $result;
          
        }
    
    }
    
    
    /**
     * 修改附件
     */
    public function eidtuploaddoc(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('docx', 'doc','pdf');// 设置附件上传类型
        $upload->savePath =  '../Uploads/upfiles/';// 设置附件上传目录
        $res = $upload->upload();
        if(!res) {// 上传错误提示错误信息
            echo '上传失败';
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
    
            $path = $res['file']['savepath'].$res['file']['savename'];
            echo $path;
        }
    
    }



    public function news(){
       $info = M('news')->order('addtime desc,id desc')->select();
       $this->assign("info",$info);
       $this->assign("comptype",'1');
       $this->display();

    }
	
	//公告列表
    
    public function gonggao(){
        $title = I('get.title');
        $type = I('get.type');
        if($title!=''){
            $keyword = array('like','%'.$title.'%');
            $where['title'] = $keyword;
        }

        if($type!=''){
           $where['type'] = $type;
        }

        $info = M('gonggao')->where($where)->order('type asc,list asc')->select();
        $this->assign("info",$info);
        $this->assign("comptype",'12');
        $this->assign("gonggao",'1');
        $this->assign("title",$title);
        $this->display();
    
    }
    

   public function addnews(){
        $id = intval(I('id'));
        $time = date('Y-m-d',time());
        if(!empty($id)){
            $where['id'] = $id;
            if(IS_POST){
                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('news')->where($where)->save($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Web/news'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }else{
            if(IS_POST){
                $file = I('post.file');
                $fujian = '';
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }
                $fujian = substr($fujian,0,-1);
                $data['fujian'] =  $fujian;


                $filename = '';
                $fujianname = I('post.filename');
                if($fujianname){

                    foreach ($fujianname as $key => $val) {
                        $filename .= $val.',';
                    }
                }


                $filename = substr($filename,0,-1);
                $data['filename'] =  $filename;



                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['pic1']=implode(",",I('post.pic1'));
                $data['addtime'] = I('post.addtime');
                $data['gaiyao'] = I('post.gaiyao');
                $rs=M('news')->add($data);
                if($rs){
                    $this->success('添加成功',U('/Admin/Web/news'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            
            }
        }

        $this->assign("time",$time);
        $this->assign("comptype",'1');
        $this->display();


    }
    
    public function addgonggao(){

            $time = date('Y-m-d',time());

            if(IS_POST){
                $data['title'] = I('post.title');
                $data['is_tui'] = I('post.is_tui');
                $data['list'] = I('post.list');
                $data['is_url'] = I('post.is_url');
                $data['news_id'] = I('post.news_id');
                $data['content'] = I('post.content');
                $data['pic'] = I('post.pic');
                $data['type'] = I('type');
                $data['addtime'] = I('post.addtime');
                $rs=M('gonggao')->add($data);
                if($rs){
                    $this->success('添加成功',U('Admin/Web/gonggao'));exit;
                }else{
                    $this->error('添加失败');exit;
                }
            }
        $this->assign("time",$time);
     
        $this->assign("gonggao",'1');
        $this->display();
    
    
    }
    
    
    public function editgonggao(){
        $M = M('gonggao');
        $where['id'] = intval(I('get.id'));
        $info = $M->where($where)->find();
        $info['content']=str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
    
        if(IS_POST){
            $id = I('post.id');
            $data['title'] = I('post.title');
            $data['is_tui'] = I('post.is_tui');
            $data['list'] = I('post.list');
            $data['is_url'] = I('post.is_url');
            $data['news_id'] = I('post.news_id');
            $data['content'] = I('post.content');
            $data['gaiyao'] = I('post.gaiyao');
            $pic = I('post.pic');
            if(!empty($pic)){
                $data['pic'] = $pic;
            }
            $data['addtime'] = I('post.addtime');
            $rs=M('gonggao')->where(array('id'=>$id))->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Web/gonggao'));exit;
            }else{
                $this->success('修改成功');exit;
            }
    
        }
    
        $this->assign("info",$info);
        $this->assign("gonggao",'1');
        $this->display();
    
    
    }



   
    public function editnews(){
        $M = M('news');
        $where['id'] = intval(I('get.id'));
        $info = $M->where($where)->find();
        $piclist = '';
        if($info['pic1']){
            $piclist=explode(',', $info['pic1']);
        }


        if($info['fujian']!=''){
            $file = explode(',',$info['fujian']);
            $file = array_filter($file);

            $filename = explode(',',$info['filename']);
            $filename = array_filter($filename);


            foreach ($file as $key => $val) {

                $fujian = $val;
                $path=parse_url($fujian);

                $str=explode('/',$path['path']);

                $length = sizeof($str);

                $fujianlist[$key]['file'] = $str[$length-1];
                $fujianlist[$key]['fujian'] = $val;

            } 

            foreach ($filename as $key => $vo) {
                $fujianlist[$key]['filename'] = $vo;
            } 

        }

        $this->assign("fujianlist",$fujianlist);
       
   
        $info['content']=str_ireplace('\"','"',htmlspecialchars_decode($info['content']));
        if(IS_POST){
            $where['id']     = intval(I('post.id'));
            $data['title']   = I('post.title');
            $data['is_tui']  = I('post.is_tui');
            $data['content'] = I('post.content');
            $data['gaiyao']  = I('post.gaiyao');
            $data["list"]    = I("post.list");
            $data["is_slide"]= I("post.is_slide");

            $fujian = '';
            $file = I('post.file');
                if($file){
                    foreach ($file as $key => $val) {
                        $fujian .= $val.',';
                    }
                }

            $fujian = substr($fujian,0,-1);
            $data['fujian'] =  $fujian;

            $filename = '';
            $fujianname = I('post.filename');
            if($fujianname){

                foreach ($fujianname as $key => $val) {
                    $filename .= $val.',';
                }
            }


            $filename = substr($filename,0,-1);
            $data['filename'] =  $filename;



            $data['pic1']=implode(",",I('post.pic1'));
            $pic = I('post.pic');
            if(!empty($pic)){
                $data['pic'] = $pic;
            }
            $data['addtime'] = I('post.addtime');
            $rs=M('news')->where($where)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Web/news'));exit;
            }else{
                $this->success('修改成功');exit;
            }

        }

        $this->assign("info",$info);
        $this->assign("piclist",$piclist);
        
        $this->assign("comptype",'1');
        $this->display();


    }



    public function qcimg(){
        $id = intval(I('id'));
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/News/index",array('id'=>$id));
        qrcode($qcurl, false);
    }


    public function qcimg1(){
        $id = intval(I('id'));
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Home/News/testView",array('id'=>$id));
        qrcode($qcurl, false);
    }





    public function delnews(){
        $where['id'] = intval(I('get.id'));
        $rs=M('news')->where($where)->delete();
        if($rs){
             $this->success('删除成功',U('/Admin/Web/news'));exit;
        }else{
            $this->error('删除失败');exit;
        }


    }

    public function delgonggao(){
        $where['id'] = intval(I('get.id'));
        $rs=M('gonggao')->where($where)->delete();
        if($rs){
             $this->success('删除成功',U('/Admin/Web/gonggao'));exit;
        }else{
            $this->error('删除失败');exit;
        }
    }







    // app功能介绍
    public function app(){
        $M = M('app_content');
        $info = $M->select();

        $this->assign("info",$info);
        $this->assign("comptype",'4');
        $this->display();
    }


    public function editapp(){
        $id = intval(I('get.id'));
        $M = M('app_content');
        $cache = $M->find($id);
        $det=str_ireplace('\"','"',htmlspecialchars_decode($cache['content']));

        if(IS_POST){
            $oid = intval(I('post.id'));
            $data['title'] = I('post.title');
            $data['list'] = I('post.list');
            $data['is_tui'] = I('post.is_tui');
            $data['content'] = I('post.content');
            $img = I('post.pic');
            $oldimg = I('post.spic');
            if($img!=$oldimg&&$img!=""){
                $data['pic'] = $img;
            }

            $rs=$M->where('id='.$oid)->save($data);
            if($rs){
                $this->success('修改成功',U('/Admin/Web/app'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }


        $this->assign("cache",$cache);
        $this->assign("comptype",'4');
        $this->display();

    }


    public function law(){
        $M = M('law');
        $info = $M->find();

        if(IS_POST){
            $where['id'] = intval(I('post.oid'));
            $data['title'] = I('post.title');
            $data['content'] = I('post.content');
            $res = $M->where($where)->save($data);
            if($res){
                $this->success('修改成功',U('/Admin/Web/law'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }


        $this->assign("comptype",'10');
        $this->assign("cache",$info);
        $this->display();


    }

    public function secret(){
        $M = M('secret');
        $info = $M->find();

        if(IS_POST){
            $where['id'] = intval(I('post.oid'));
            $data['title'] = I('post.title');
            $data['content'] = I('post.content');
            $res = $M->where($where)->save($data);
            if($res){
                $this->success('修改成功',U('/Admin/Web/secret'));exit;
            }else{
                $this->error('修改失败');exit;
            }

        }


        $this->assign("comptype",'11');
        $this->assign("cache",$info);
        $this->display();




    }









}