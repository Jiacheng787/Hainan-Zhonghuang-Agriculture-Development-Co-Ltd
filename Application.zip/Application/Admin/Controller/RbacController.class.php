<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class RbacController extends CommonController {
	public function _initialize(){
        parent::_initialize();

        $role = M('auth_group')->where(array('status'=>1))->order('sort asc,id asc')->select();

        $this->assign("role",$role);
        $this->assign("munetype",4);
	
		
		
    }


    //管理员列表
    public function index(){
        $map = array();
        $user = M('user');
        $users = $user->where($map)
               -> join("left join uha_auth_group_access  ON uha_auth_group_access.uid = uha_user.id")
               -> join("left join uha_auth_group ON uha_auth_group.id = uha_auth_group_access.group_id")
               ->field('uha_user.*,uha_auth_group.title') -> limit($p->firstRow, $p->listRows)->select();

        $count    = $user->where($map)->count();
        $p        = getpage($count,10);
        $page   = $p->show();// 赋值分页输出
        $this->assign('users',$users);
        $this->assign('page',$page);
        $this->assign('count',$count);
    	$this->display();
    }



    //添加管理员

    public function adduser(){
        $user = M('user');
        $access = M('auth_group_access');
        if(IS_POST){
            $data['username']= I('post.username');
            $data['password']= md5(I('post.password'));
            $data['sort']= I('post.sort');
            $data['status']= I('post.status');
            $group_id = I('post.group_id');
            $result = $user->add($data);
            if($result){
                $arr['uid'] = $result;
                $arr['group_id'] = $group_id;
                $res = $access->add($arr);
                if($res){
                    $this->success('添加成功！',U('Admin/Rbac/index'));exit;

                }else{
                    $this->success('添加失败！');exit;
                }
            }
        }


        $this->display();
    }
	
	
	
	public function mima(){
		$id = I('post.id');
		$data['password'] = md5('123456');
		$save = M('user')->where(array('id'=>$id))->save($data);
		if($save){
			$return  = array(
			   'status'=>1,
			   'info'=>'密码已初始化为123456'
			);
			echo json_encode($return);exit;
			
		}else{
			$return  = array(
			   'status'=>0,
			   'info'=>'密码已初始化为123456'
			);
			echo json_encode($return);exit;
			
			
		}
	
	}
	
	


    public function edituser(){

        $userid = I('get.id');
        $info = M('user')->find($userid);
        $info['group_id'] = M('auth_group_access')->where(array('uid'=>$info['id']))->getField('group_id');
      //dump($info['group_id']);
        if(IS_POST){
            $id = I('post.id');
            $password = I('post.password');
            if($password!=''){
                $data['password'] = md5($password);
            }

            $data['is_open'] = I('post.is_open');
            $data['sort'] = I('post.sort');
            $group_id = I('post.group_id');
			$map['group_id'] = $group_id;
            $result = M('user')->where(array('id'=>$id))->save($data);
              M('auth_group_access')->where(array('uid'=>$id))->save($map);
            if($result){
             
               $this->success('修改成功！',U('Admin/Rbac/index'));exit;
            }else{
                $this->success('修改成功！');exit;

            }

        }
     
        $this->assign('user',$info);
        $this->display();

    }





    //管理员删除

    public function deluser(){
        $userid = I('get.id');
        if(!empty($userid)){
            $deluser = M('user')->where(array('id'=>$userid))->delete();
            if($deluser){
                $this->success('删除成功！',U('Admin/Rbac/index'));exit;
            }else{
                $this->success('删除成功！');exit;

            }
        }

    }





   //角色列表 
    public function role(){
        $role = M('auth_group')->select();
        $this->assign('role',$role);
        $this->display();

    }


    //角色添加
    public function addrole(){
        if(IS_POST){
            if(M('auth_group')->add($_POST)){
                $this->success('添加成功！',U('Admin/Rbac/role'));exit;
            }else{
                $this->success('添加失败！');exit;
            }
        }
       
        $this->display();
    }

    //角色修改

    public function editrole(){
        $id = I('get.id');
        $role = M('auth_group')->find($id);
        $this->assign('role',$role);
        if(IS_POST){
            if(M('auth_group')->save($_POST)){
                $this->success('修改成功！',U('Admin/Rbac/role'));exit;
            }else{
                $this->success('修改成功！');exit;
            }
        }
       
        $this->display();
    }



    //角色删除

    public function delrole(){
        $id = intval(I('get.id'));
        if(!empty($id)){
            $del =  M('auth_group')->where(array('id'=>$id))->delete();
            if($del){
                $this->success('删除成功！',U('Admin/Rbac/role'));exit;
            }else{
                $this->success('修改失败！',U('Admin/Rbac/role'));exit;
            }

        }
    }


    //节点列表
    public function node(){
        $field=array('id','name','title','pid');
        $node = M('node')->field($field)->order('id asc,sort asc')->select();
        $node=node_merge($node);
        $this->assign('node',$node);
        $this->display();
    }


    //配置权限
    public function access(){
        $rid=$_GET['rid'];
        //读取有用字段
        $field=array('id','name','title','pid');
        $node=M('node')->order('id asc,sort asc')->field($field)->select();
        
        //读取用户原有权限
        $access=M('access')->where(array('role_id'=>$rid))->getField('node_id',true);
        $node=node_merge($node,$access);

        $this->assign('rid',$rid);
        $this->assign('node',$node);
        $this->display();
    
    }

    //配置权限接受表单
    public function setaccess(){
        $rid=$_POST['id'];

        $db=M('access');
        //删除原权限
        $db->where(array('role_id' => $rid))->delete();
        $name = M('role')->where(array('id' => $rid))->getField('name');
        //组合新权限
        $data=array();
        foreach($_POST['access'] as $v){
            $tmp=explode('_',$v);
            $data[]=array(
                'role_id'=>$rid,
                'node_id'=>$tmp[0],
                'level'=>$tmp[1]
            );
        }
        //插入新权限
        if($db->addAll($data)){
            $this->success('修改成功！',U('Admin/Rbac/role'));
        }else{
             $this->success('修改成功！',U('Admin/Rbac/role'));
        }
    }



    //添加节点
    public function addNode(){
        $pid=isset($_GET['pid'])?$_GET['pid']:0;
        $level=isset($_GET['level'])?$_GET['level']:1;
        $this->assign('pid',$pid);
        $this->assign('level',$level);
        switch($level){
            case 1:
                $this->type='应用';
                break;
            case 2:
                $this->type='控制器';
                break;
            case 3:
                $this->type='动作方法';
                break;
        }

        if(IS_POST){
            if(M('Node')->add($_POST)){
                $this->success('添加成功！',U('Admin/Rbac/node'));exit;
            }else{
                $this->error('添加失败！');exit;
            }
        }

        $this->display();
    }




    public function editNode(){
        $id=I('get.id');
        $nrs=M('node')->find($id);
      
        if(IS_POST){
            if(M('Node')->save($_POST)){
                $this->success('修改成功！',U('Admin/Rbac/node'));exit;
            }else{
                $this->error('修改失败！');exit;
            }

        }


        $this->assign('nrs',$nrs);
        switch($nrs['level']){
            case 1:
                $this->type='应用';
                break;
            case 2:
                $this->type='控制器';
                break;
            case 3:
                $this->type='动作方法';
                break;
        }
        $this->display();
    } 





    //删除节点
    public function delNode(){
        $nid=I('get.id');
        if(M('node')->delete($nid)){
           
            $this->success('删除节点成功',U('Admin/Rbac/node'));exit;
        }else{
            $this->success('删除节点失败',U('Admin/Rbac/node'));exit;
        }       
    }


    //开关模块
    public function moduleList(){

		$rs = M('auth_module')->select();
		$this->assign('list',$rs);
		$this->display();  
		
    }


    //改状态
    public function c_module_status(){

		$data['id'] 	 = I('post.id');
		$data['is_show'] = I('post.able');
		$rs				 = M('auth_module')->save($data);
		
		if($rs)
		{
			$data['info']   =   '修改成功'; // 提示信息内容
			$data['status'] =   1;  // 状态 如果是success是1 error 是0
		}
		else
		{
			$data['info']   =   '修改失败'; // 提示信息内容
			$data['status'] =   0;  // 状态 如果是success是1 error 是0
		}
        $this->ajaxReturn($data);
        return;
		
		
    }
  

    
    
    

    



   






}