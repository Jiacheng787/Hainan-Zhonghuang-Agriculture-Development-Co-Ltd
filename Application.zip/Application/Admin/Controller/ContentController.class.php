<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class ContentController extends CommonController {
    public function _initialize(){
        parent::_initialize();
        $this->assign("urlname", ACTION_NAME);
    }

    public function index(){
		
		$m     = M("Introdution");
		$cache = $m->where(array("classid"=>2))->select();
		
        $this->assign("cache" ,$cache);
        $this->display();
    }


    /**
     * 新增信息
     */
    public function add(){
        if(IS_POST){
			$data 			 = I("post.");
			$data['classid'] = 2;
			//print_r($data);die;
            $m    = M("Introdution");
            $res  = $m->add($data);
            if($res){
				$this->success("添加成功！", U('Admin/Content/index'));die;
            }else{
                $this->error("添加失败！");
            }
        }
        $this->display();
    }

    /**
     * 编辑信息
     */
    public function edit(){
        $m = M("Introdution");
        if(IS_POST){
            $data 			 = I("post.");
			$data['classid'] = 2;
            $id   			 = $data['id'];
            unset($data['id']);
            if($id){
                $res = $m->where(array('id'=>$id))->save($data);
            }else{
                $res = $m->add($data);
            }
            if($res){
                //$url = $id?U('Admin/Pc/edit',array('id'=>$id)):U('Admin/Pc/edit',array('id'=>$res));
                //$this->ajaxReturn(array("status"=>1, "info"=>"修改成功！", "url"=>$url));
				$this->success("修改成功！",  U('Admin/Content/index'));die;
            }else{
                //$this->ajaxReturn(array("status"=>0, "info"=>"修改失败！"));
				$this->success("修改失败！",  U('Admin/Content/index'));die;
            }
        }
		
        $id 			  	 = I("id");
        $cache			  	 = $m->find($id);
		$cache['content'] 	 = html_entity_decode($cache['content']);
		$cache['en_content'] = html_entity_decode($cache['en_content']);
        $this->assign("cache", $cache);
        $this->display();
    }


    /**
     * 删除信息
     */
    public function del(){
        $id  = I("id");
        $res = M("Introdution")->where(array("id"=>$id))->delete();
        if($res!==false){
            $this->success("删除成功！");die;
        }
        $this->error("删除失败！");die;
    }


	


	

}