<?php
namespace Admin\Controller;
//use Think\Controller;
use Common\Controller\CommonController;
class IndexController extends CommonController {
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype","1");
    }
  



    /*
        获取城市
    */
    public function getCity($lat,$lng){
        $token="BrjEewDYNNlNvBS9WmPhPVCXyu88NtGd";
        $url="http://api.map.baidu.com/geocoder/v2/?ak=".$token."&location=".$lat.",".$lng."&output=json&pois=0";
        $result=file_get_contents($url);
        return $result;
    }

    /**
     * 首页轮换图
     *
     * @author yjh 
     */
    public function pic(){
		
		$typeid = intval(I('get.typeid'));
		//查询所有经销商
		$special_type=M('pic_type')->select();   //专区分类
		
		$this->assign('deal',$special_type);
		
		$where = '';
		if($typeid!=""){
			$where = 'typeid='.$typeid;
		}

		$action=M('pic');
		
		$result=$action->where($where)->field('id,title,pic,dealer_id,is_urls_type,typeid,is_show,sequence')->order('typeid asc,sequence desc')->select();

		$count=count($result);
		foreach($result as $key => $v){
			if($v['dealer_id']){
				
				$result[$key]['dealername'] = M('pic_type')->where(array('id'=>$v['dealer_id']))->getField('classname');
			}
			
		}

		$this->assign('piclist', $result);
		$this->assign('count', $count);
		$this->assign('urlname',"indexpic");
        $this->display();

    }
   
    /**
     * 添加首页图片
     *
     * @author  yjh
     */
    public function addpic(){
    
    	$special_type=M('pic_type')->select();   //专区分类
    	$action=M('pic');
    	$title=I('post.title');
    	if(!empty($title)){
    		$data['title']=$title;
    		$data['dealer_id'] = I('post.dealer_id');
    		$data['typeid'] = I('post.type_id');
    		
    		$data['pic']=I('post.pic');
    		$data['sequence']=I('post.sequence');
    		$data['is_show']=I('post.is_show');
    		
    		$data['is_urls_type']=I('post.is_urls_type');
    			
    		if($data['is_urls_type']==4){
    			$data['activitys_id']=I('post.activitys_id');
    		}else{
    			$data['goodsid']=I('post.goodsid');
    		}
    		
    			
    		if($data['is_urls_type']==1){
    			$data['is_urls_title']='优惠券链接';
    		}elseif($data['is_urls_type']==2){
    			$data['is_urls_title']='产品列表';
    		}elseif($data['is_urls_type']==3){
    			$data['is_urls_title']='单个产品';
    		}elseif($data['is_urls_type']==4){
    			$data['is_urls_title']='活动产品';
    		}else{
    			$data['is_urls_title']='';
    		}
    		$data['addtime']=Gettime();
    			
    		$result=$action->add($data);
    			
    		if($result){
    			
    			$this->success('添加成功',U('/Admin/Index/pic'));exit;

    		}else{
    			$this->error('添加失败');
    		}
    	}

    	foreach($special_type as $k=>$value){
    		$goodsRecord[$k]['id']=$value['id'];
    		$goodsRecord[$k]['list'] = M('goods')->where('is_show=1 and is_special =1 and special_type='.$value['id'])->field('id,pic,good_name')->order('id desc')->select();

    	}
    	
    	$rank=M('pic')->order('sequence desc')->getField('sequence');
    	$max_sequence=$rank+1;
    	$this->assign('max_sequence',$max_sequence);

    	$this->assign('goods', $goodsRecord);
    	$this->assign('urlname',"addpic");
    	$this->assign('deal',$special_type);
    	$this->display();
    
    }
    
    

    /**
     * 修改首页轮换图
     *
     * @author yjh 
     */
    public function editpic(){
    	$picid=I('get.id');
		$special_type=M('pic_type')->select();   //专区分类
    	$action=M('pic');
    	$title=I('post.title');
    		if(!empty($title)){
			
			$data['title']=$title;
			$data['pic']=I('post.pic');
			$data['sequence']=I('post.sequence');
			$data['is_show']=I('post.is_show');
			
			$data['is_urls_type']=I('post.is_urls_type');
			$data['dealer_id'] = I('post.dealer_id');
			$data['typeid'] = I('post.type_id');
			if($data['is_urls_type']==4){
				
				$data['goodsid']=0;
				
			}else{
				
				$data['goodsid']=I('post.goodsid');
				
			}

			if($data['is_urls_type']==1){
			$data['is_urls_title']='优惠券链接';
			}elseif($data['is_urls_type']==2){
				$data['is_urls_title']='产品列表';
				}elseif($data['is_urls_type']==3){
					$data['is_urls_title']='单个产品';
					}elseif($data['is_urls_type']==4){
						$data['is_urls_title']='活动产品';
					}else{
						$data['is_urls_title']='';
						}
			
			$result=$action->where('id='.$picid)->save($data);
			
			if($result){
				
					$this->success('修改成功',U("/Admin/Index/pic"));exit;
				
			}else{
				
					$this->error('添加失败');
					exit();
				
			}
		}
		
		foreach($special_type as $k=>$value){
			$goodsRecord[$k]['id']=$value['id'];
			$goodsRecord[$k]['list'] = M('goods')->where('is_show=1 and is_special =1 and special_type='.$value['id'])->field('id,pic,good_name')->order('id desc')->select();
		
		}
		 

		$result=$action->where('id='.$picid)->find();
		if($result['goodsid']!="")
		{
			$goodsone=M('goods')->where('id='.$result['goodsid'])->find();
		}
		$result['goodsname'] = $goodsone['good_name'];

		$this->assign('editpic', $result);

		$this->assign('goods', $goodsRecord);
		$this->assign('urlname',"addpic");
		$this->assign('deal',$special_type);
		
        $this->display();

    }

    /**
     * 删除轮换图
     *
     * @author Chandler_qjw  ^_^
     */
    public function delpic(){
        $picid=intval(I('get.id'));
        $action=M('pic');
        if(!empty($picid)){
            
           // $arr=$action->where('id='.$picid)->find();
            $result=$action->where('id='.$picid)->delete();
            
            if($result){
                $this->success('删除成功',U('/Admin/Index/pic'));exit;
            }else{
                $this->error('删除失败');
            }
        }
    }
}

