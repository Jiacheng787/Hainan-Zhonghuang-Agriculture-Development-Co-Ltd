<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class GoodsController extends CommonController {
    public function index(){
		
		$is_show=I('get.is_show');
		
        $action=D('Goods');
        $rsdate=$action->getgoodslist();
        $rs=$rsdate['list'];
		$count=count($rs);
        $action=A('Category');      //调用Category控制器中的方法,获取类列表
        for($i=0;$i<$count;$i++){
            $rs[$i]['pics'] = explode(',',$rs[$i]['pic']);
            $retuenclassname=$action->get_category_name($rs[$i]['classid']);
            $rs[$i]['classname']=$retuenclassname;
        }
        $categorylist=$action->categorylist();
		$action=D('Goods');
		
		
		
		$counts=$action->where('1=1'.$goodsWhere)->count();
		$count1=$action->where('is_show=1'.$goodsWhere)->count();
		$count2=$action->where('is_show=0'.$goodsWhere)->count();
		
        $img_url = C('IMG_URL1');
		$this->assign('img_url',$img_url);
		$this->assign('categorylist',$categorylist);
        $this->assign('goodslist',$rs);
		$this->assign('is_show',$is_show);
		$this->assign('count',$count);
		$this->assign('counts',$counts);
		$this->assign('count1',$count1);
		$this->assign('count2',$count2);
        $this->assign('page',$rsdate['page']);
		$this->assign('urlname', "goodsindex"); // 赋值数据集
        $this->assign('munetype','2');
        $this->display();
    }


    public function alldel(){

        if(IS_POST){
            $id = I('post.id');
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('Goods')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }
    


    
    public function jifenalldel(){

        if(IS_POST){
            $id = I('post.id');
            $arr = explode('_',$id);
            $newsid = array_filter($arr);
            foreach ($newsid as $key => $vo) {
                $del = M('jifen_goods')->where(array('id'=>$vo))->delete();  
            }

            if($del){
                $result = array(
                    'status'=>1,
                    'info'=>'删除成功'
                    );
                echo json_encode($result);exit; 

            }

        }
    }





	
    public function add(){
    	
		$special_type=M('pic_type')->select();   //专区分类
    
        //调用Category控制器中的方法,获取类列表
		$action=A('Category');      
        $rs=$action->categorylist();	//产品分类	
		
        $goodsname=I('post.good_name');

        if(!empty($goodsname)){
         
            $date['classid']=I('post.class_id');
			$date['othercid']=I('post.othercid');
			$pid_arr=M('category')->where('id='.$date['classid'])->find();
			$date['parid']=$pid_arr['fid'];
            $date['good_name']=$goodsname;
			$date['des']=I('post.des');
			$date['resource']=I('post.resource');
			$date['address']=I('post.address');
			$date['is_limit']=I('post.is_limit');
			$date['num_limit']=I('post.num_limit');
			$date['kucun']=I('post.kucun');
			$date['virtual']=I('post.virtual');
            $date['pic']=I('post.pic');
            $date['pic2']=I('post.pic2');
			$date['pic1']=implode(",",I('post.pic1'));
            $date['sku']=I('post.goods_no');
            $date['detail']=$_POST['detail'];
            $date['is_show']=I('post.is_show');
            $date['addtime']=Gettime();
            $date['rank']=I('post.rank');
			$date['is_special']=I('post.is_special');
			
			if($date['is_special']==1){
				$date['special_type']=I('post.special_type');
			}

			$starttime = I('post.starttime');
			$endtime = I('post.endtime');

			if($starttime>0){
				$date['starttime']=$starttime;
			}

			if($endtime>0){
               $date['endtime']=$endtime;
			}


			
			$date['old_price']=I('post.old_price');
			$date['price']=I('post.price');
			$date['vip_price']=I('post.vip_price');
			$date['employee_price']=I('post.employee_price');
			
            $m=M('goods');
			
            $rs=$m->add($date);
            
			//插入goods_store
/* 			$storeids = I('post.storeid');
			$goods_store_model = M('goods_store');
			$stocks = I('post.stock');
			for($i=0;$i<count($storeids);$i++){
				$data = array('goods_id'=>$rs,'store_id'=>$storeids[$i],'stock'=>$stocks[$i]);
				$goods_store_id = $goods_store_model->add($data);
			} */
			
			// 存入对应规格
			$goods_guige = M('Goods_guige');
			$guige_num=I('post.nums');
				if($guige_num!=0){
					$j=1;
					for($i=0; $i < $guige_num; $i++){
							$guiges[$i]['guige']=I('post.guige'.$j);
							$guiges[$i]['weight']=I('post.weight'.$j);
							$guiges[$i]['price']=I('post.guige_price'.$j);
							$guiges[$i]['old_price']=I('post.guige_old_price'.$j);
							$guiges[$i]['vip_price']=I('post.guige_vip_price'.$j);
							$guiges[$i]['employee_price']=I('post.employee_price'.$j);
							$guiges[$i]['nums']=I('post.guige_nums'.$j);
							$guiges[$i]['num_limit']=I('post.num_limit'.$j);
							$j++;
						}

					for ($i=0; $i < $guige_num; $i++) {
						$datas = array(
							'goodsid'=>$rs,
							'guige'=>$guiges[$i]['guige'],
							'weight'=>$guiges[$i]['weight'],
							'price'=>$guiges[$i]['price'],
							'old_price'=>$guiges[$i]['old_price'],
							'vip_price'=>$guiges[$i]['vip_price'],
							'employee_price'=>$guiges[$i]['employee_price'],
							'nums'=>$guiges[$i]['nums'],  //库存
							'num_limit'=>$guiges[$i]['num_limit'] , //库存
						);
					$goods_guige->add($datas);
				}
			}
			
			
            if($rs){
                $this->success('添加成功',U('/Admin/Goods/index'));
            }else{
                $this->error('添加失败');
            }

        }else{

        	//查询最大的排序值
        	$rank=M('goods')->order('rank desc')->getField('rank');
        	$max_rank=$rank+1;
        	$this->assign('max_rank',$max_rank);
        	
			//$dealerIds = M('Dealer')->field('id,username')->select();
			$this->assign('categorylist',$rs);
			$this->assign('special_type',$special_type);
			$this->assign('urlname',"goodsindex");
            $this->assign('munetype',2);
            $this->display();
        }

    }
	

	
	
    public function delgoods(){
        $goosid=I('get.id');
        $m = M("goods"); // 实例化User对象
        $rs=$m->where("id=$goosid")->delete(); // 删除id为5的用户数据
		
		$ms = M("goods_guige");
		$rss=$ms->where('goodsid='.$goosid)->delete();
		
        if($rs){
            $this->success('删除成功',U('/Admin/Goods/index'));
        }else{
            $this->error('删除失败');
        }
    }
	
	
   

    public function edit(){
		header("Content-Type:text/html; charset=utf-8");
        $action=A('Category');      //调用Category控制器中的方法,获取类列表
        $rs=$action->categorylist();
        
        $special_type=M('pic_type')->select();   //专区分类

        $goodid=I('get.id');
        $act=D('Goods');
        $goodsdetail=$act->getonegoodsdetail($goodid);
		
		//获得分类名
		$cid=M('Category');
		$cids=$cid->where('id='.$goodsdetail['classid'])->select();
		$cids=$cids[0];
		
		//编辑器内容html实体转换
		$det=str_ireplace('\"','"',htmlspecialchars_decode($goodsdetail['detail']));
		//获取规格内容
		$guige=M('Goods_guige');
		$guigelist=$guige->where('goodsid='.$goodid)->select();
		$guige_count=count($guigelist);
		if($goodsdetail['pic1']){
			$pic1list = explode(",",$goodsdetail['pic1']);
		}
		$this->assign('pic1list',$pic1list);
        $this->assign('goodsdetail',$goodsdetail);
		$this->assign('cids',$cids);
		$this->assign('guigelist',$guigelist);
		$this->assign('guige_count',$guige_count);
		$this->assign('det',$det);
		$orderlistModel = M("Orderlist");
        $goodsname=I('post.good_name');
        if(!empty($goodsname)){
		
			if(I('post.class_id')!=''){
	            $date['classid']=I('post.class_id');
				$date['othercid']=I('post.othercid');
				$pid_arr=M('category')->where('id='.$date['classid'])->find();
				$date['parid']=$pid_arr['fid'];
				}
	            $date['good_name']=$goodsname;
				$date['good_name1']=I('post.good_name1');
				$date['des']=I('post.des');

				$date['address']=I('post.address');
				$date['kucun']=I('post.kucun');
				$date['virtual']=I('post.virtual');
				$date['pic']=I('post.pic');
				$date['pic2']=I('post.pic2');
	            $date['pic1']=implode(",",I('post.pic1'));
	            $date['sku']=I('post.goods_no');
	            $date['detail']=I('post.detail');
	            $date['is_show']=I('post.is_show');
	            $date['addtime']=Gettime();
	            $date['rank']=I('post.rank');
	            $date['is_new']=I('post.is_new');
	            $date['is_limit']=I('post.is_limit');
	            $date['num_limit']=I('post.num_limit');
				$date['is_new']=I('post.is_new');
				$date['is_special']=I('post.is_special');
				if($date['is_special']==1){
					$date['special_type']=I('post.special_type');
				}
			
				$date['old_price']=I('post.old_price');
				$date['price']=I('post.price');
				$date['vip_price']=I('post.vip_price');
				$date['employee_price']=I('post.employee_price');
	            $starttime = I('post.starttime');
				$endtime = I('post.endtime');

				if($starttime>0){
					$date['starttime']=$starttime;
				}

				if($endtime>0){
	               $date['endtime']=$endtime;
				}



            $date['id']=I('get.id');
			
            $m=M('goods');
            $rs=$m->save($date);
            
			
			$goodsid=I('get.id');
			$stocks = I('post.stock');
			$storeids = I('post.storeid');
		
			// 存入对应规格
			
			$goods_guige = M('Goods_guige');
			$guige_num=I('post.nums');
			
			if($guige_num!=0){
				$j=1;
				for($i=0; $i < $guige_num; $i++){
					$guiges[$i]['guigeid']=I('post.guigeid'.$j);
					$guiges[$i]['guige']=I('post.guige'.$j);
					$guiges[$i]['weight']=I('post.weight'.$j);
					$guiges[$i]['old_price']=I('post.guige_old_price'.$j);
					$guiges[$i]['vip_price']=I('post.vip_price'.$j);
					$guiges[$i]['employee_price']=I('post.employee_price'.$j);
					$guiges[$i]['price']=I('post.guige_price'.$j);
					$guiges[$i]['nums']=I('post.guige_nums'.$j);
					$guiges[$i]['num_limit']=I('post.num_limit'.$j);
					$j++;
					}

				for ($i=0; $i < $guige_num; $i++) {

                    $M_guigeinfo_id = $goods_guige->where(array('goodsid'=>$goodsid,'id'=>$guiges[$i]['guigeid']))->getField('id');
					$datas = array(
						'goodsid'=>$goodsid,
						'guige'=>$guiges[$i]['guige'],
						'weight'=>$guiges[$i]['weight'],
						'old_price'=>$guiges[$i]['old_price'],
						'vip_price'=>$guiges[$i]['vip_price'],
						'employee_price'=>$guiges[$i]['employee_price'],
						'nums'=>$guiges[$i]['nums'],
						'price'=>$guiges[$i]['price'],
						'num_limit'=>$guiges[$i]['num_limit'],
					);

					if($M_guigeinfo_id){
						$datas['id'] =  $M_guigeinfo_id ;
						$goods_guige->save($datas);

					}else{
						$goods_guige->add($datas);
					}
				}
			}
			
			if($rs){
                $this->success('添加成功',U('/Admin/Goods'));
            }else{
                $this->error('添加失败');
            }
			

        }else{
		
			$img_url = C('IMG_URL');
			$this->assign('img_url',$img_url);
            $this->assign('categorylist',$rs);
			$this->assign('urlname',"goodsindex");
			$this->assign('special_type',$special_type);
            $this->assign('munetype',2);
            $this->display();
        }

    }



    // 商品预览
    public function qcimg(){
        $id = I('id');
        $qcurl = "http://".$_SERVER['HTTP_HOST'].U("Weixin/Goods/detail",array('id'=>$id));
        qrcode($qcurl, false);
    }


    

	public function is_new(){
		
        $goosid=I('post.goodsid');
        $m = D("goods"); // 实例化User对象
		
        $rs=$m->is_new($goosid); 
		
        $this->ajaxReturn($rs);
		return;
    }
    public function recommend_g(){
		
        $goosid=I('post.goodsid');
        $m = D("goods"); // 实例化User对象
		
        $rs=$m->recommend_g($goosid); 
		
        $this->ajaxReturn($rs);
		return;
    }
	
	

	
	



    
    public function jifen_goods(){
    	
    	$m=M('jifen_goods');
        $where = array();
    	$title = I('get.title');
    	$is_show = I('get.is_show');

    	if($is_show){
    		$where['is_show'] = $is_show;
    	}
    	if($title){
    		$where['title'] = array('like','%'.$title.'%');
    	}
    	$list=$m->where($where)->select();
          

    	$counts = $m->count();
        $count1 = $m->where(array('is_show'=>1))->count();
        $count2 = $m->where(array('is_show'=>2))->count();
    	$this->assign('list',$list);
    	$this->assign('counts',$counts);
    	$this->assign('count1',$count1);
    	$this->assign('count2',$count2);
        $this->assign('is_show',$is_show);
    	$this->assign('urlname',"jifengoods");
    	$this->display();
    }
    
    public function add1(){
    
    	$title=I('post.title');
    
    	if(!empty($title)){
    	
    		$date['title']=$title;
    		$date['en_title']=I('post.en_title');
    		$date['price']=I('post.price');
    		$date['integral']=I('post.integral');
    		$date['is_show']=I('post.is_show');
    		$date['detail']=I('post.detail');
    		$date['sequence']=I('post.sequence');
    		$date['pic']=I('post.pic');
	
    		$m=M('jifen_goods');
    			
    		$rs=$m->add($date);
	
    		if($rs){
    			$this->success('添加成功',U('/Admin/Goods/jifen_goods'));
    		}else{
    			$this->error('添加失败');
    		}
    
    	}else{
    		//查询最大的排序值
    		$list=M('jifen_goods')->order('sequence desc')->getField('sequence');
    		$max_list=$list+1;

    		//$dealerIds = M('Dealer')->field('id,username')->select();
    		$this->assign('categorylist',$rs);
    		$this->assign('urlname',"jifengoods");
    		$this->assign('sequence',$max_list);
    		
    		$this->display();
    	}
    
    }
    
    public function edit1(){
    	header("Content-Type:text/html; charset=utf-8");
    	
    	$goodid=intval(I('get.id'));
    	$m=M('jifen_goods');
    	$goodsdetail=$m->where('id='.$goodid)->find();
		$det=str_ireplace('\"','"',htmlspecialchars_decode($goodsdetail['detail']));
		//print_r($goodsdetail);
    	$title=I('post.title');
		
    	if(!empty($title)){
    			
    		
    		$date['title']=$title;
    		$date['en_title']=I('post.en_title');
    		$date['price']=I('post.price');
    		$date['integral']=I('post.integral');
    		$date['is_show']=I('post.is_show');
			$date['detail']=I('post.detail');
    		$date['sequence']=I('post.sequence');
    		$date['pic']=I('post.pic');
    
    		$date['id']=intval(I('get.id'));

    		$rs=$m->save($date);

    		if($rs){
    			$this->success('添加成功',U('/Admin/Goods/jifen_goods'));
    		}else{
    			$this->error('添加失败');
    		}
    			
    
    	}else{
    		
    		$this->assign('goodsdetail',$goodsdetail);
			$this->assign('det',$det);
    		$this->assign('urlname',"jifengoods");
    		$this->assign('munetype',2);
    		$this->display();
    	}
    
    }

}