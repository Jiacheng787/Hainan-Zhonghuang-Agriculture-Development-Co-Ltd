<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class StaticsController extends CommonController {
    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",11);
    }

    // 公司列表
    public function index(){
        $cache  = M('statics')->find();
        if(IS_POST){
            $id = I('post.id');
            $data['usernum'] = I('post.usernum');
            $data['moneynum'] = I('post.moneynum');
            $data['tasknum'] = I('post.tasknum');
            $data['point'] = I('post.point');
            $res = M('statics')->where(array('id'=>$id))->save($data);
           
            if($res){
                $this->success('修改成功',U('/Admin/statics/index'));exit;
            }else{
                $this->error('修改失败');exit;
            }


        }

        $this->assign('cache',$cache);
        $this->assign("comptype",'3');
        $this->display();
    }





 
    
  
}