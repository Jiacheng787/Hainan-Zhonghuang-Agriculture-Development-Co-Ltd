<?php
namespace Admin\Controller;
use Common\Controller\CommonController;
class MoneyController extends CommonController {    
    public function _initialize(){
        parent::_initialize();
        $this->assign("munetype",8);
    }
    public function index(){
        $m = D("withdrawal");
        $cache = $m->getWithdrawalList();
        $this->assign("urlname","withdrawal");
        $this->assign("cache",$cache["cache"]);
        $this->assign("page",$cache["page"]);
        $this->display();
    }

    public function detail(){
        $id = I("id");
        $m  = D("withdrawal");
        $w_res = $m->where(array("isdel"=>0))->find();
        $user  = M("member")->where(array("id"=>$w_res["userid"],"isdel"=>0))->field("person_name,person_img,telephone,wallet,withdraw_nums")->find();
        $w_res["person_name"]   = $user["person_name"];
        $w_res["person_img"]    = $user["person_img"];
        $w_res["telephone"]     = $user["telephone"];
        $w_res["wallet"]        = $user["wallet"];
        $w_res["withdraw_nums"] = $user["withdraw_nums"];
        $this->assign("urlname","integral");
        $this->assign("cache",$w_res);
        $this->display();
    }

    public function tixian(){
        if(IS_AJAX){
            $id = I("id");
            $res = M("withdrawal")->where(array("id"=>$id,"status"=>0))->setField("status","1");
            if($res){
                $this->ajaxReturn(array("status"=>1,"info"=>"提现成功"));
            }else{
                $this->ajaxReturn(array("status"=>0,"info"=>"提现失败"));
            }
        }
    }
    public function jujue(){
        if(IS_AJAX){
            $id = I("id");
            $res = M("withdrawal")->where(array("id"=>$id,"status"=>0))->setField("status","2");
            if($res){
                $this->ajaxReturn(array("status"=>1,"info"=>"拒绝成功"));
            }else{
                $this->ajaxReturn(array("status"=>0,"info"=>"拒绝失败"));
            }
        }
    }
}